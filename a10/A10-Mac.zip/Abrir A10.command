#!/bin/bash
# No abras el ícono A10. Este archivo sí se puede abrir.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
xattr -dr com.apple.quarantine "$HERE" 2>/dev/null || true
CAJA="$HERE/A10.app/Contents/Resources/caja"
if [[ ! -f "$CAJA/Abrir A10.command" ]]; then
  echo "Falta la caja. Descomprime de nuevo el zip."
  read -r -p "Enter para cerrar. " _
  exit 1
fi
chmod +x "$CAJA/Abrir A10.command"
exec "$CAJA/Abrir A10.command"
