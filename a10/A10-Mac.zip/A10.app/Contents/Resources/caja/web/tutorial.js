(() => {
  const STEPS = [
    { view: "hoy", sel: "#view-hoy h1", title: "t1_t", text: "t1_x" },
    { view: "hoy", sel: '.rail-btn[data-view="hoy"]', title: "t2_t", text: "t2_x" },
    { view: "vender", sel: '.rail-btn[data-view="vender"]', title: "t3_t", text: "t3_x" },
    { view: "vender", sel: "#q", title: "t4_t", text: "t4_x" },
    { view: "vender", sel: "#btnCobrar", title: "t5_t", text: "t5_x" },
    { view: "inventario", sel: '.rail-btn[data-view="inventario"]', title: "t6_t", text: "t6_x" },
    { view: "taller", sel: '.rail-btn[data-view="taller"]', title: "t7_t", text: "t7_x" },
    { view: "ajustes", sel: "#btnAjustes", title: "t8_t", text: "t8_x" },
    { view: "ajustes", sel: "#paisPick", cfg: "tienda", title: "t9_t", text: "t9_x" },
    { view: "ajustes", sel: "#btnTutorial", title: "t10_t", text: "t10_x" },
  ];

  let i = 0;
  let opts = {};
  let on = false;

  function $(sel) {
    return document.querySelector(sel);
  }

  function box() {
    return $("#coach");
  }

  function place() {
    const step = STEPS[i];
    if (!step) return;
    const spot = $("#coachSpot");
    const nube = $("#coachNube");
    const kicker = $("#coachStep");
    const tit = $("#coachTit");
    const txt = $("#coachTxt");
    const next = $("#coachNext");
    const skip = $("#coachSkip");
    const t = window.A10t || ((k) => k);
    const n = STEPS.length;
    if (kicker) kicker.textContent = `${t("step")} ${i + 1} / ${n}`;
    if (tit) tit.textContent = t(step.title);
    if (txt) txt.textContent = t(step.text);
    if (skip) skip.textContent = t("skip");
    if (next) next.textContent = i === n - 1 ? t("done") : t("next");
    if (nube) nube.setAttribute("dir", window.A10lang === "ar" ? "rtl" : "ltr");
    const el = document.querySelector(step.sel);
    const pad = 8;
    let r = { left: 24, top: 24, width: 72, height: 48 };
    if (el && el.getClientRects().length) {
      const b = el.getBoundingClientRect();
      r = { left: b.left - pad, top: b.top - pad, width: b.width + pad * 2, height: b.height + pad * 2 };
    }
    if (spot) {
      spot.style.left = Math.max(8, r.left) + "px";
      spot.style.top = Math.max(8, r.top) + "px";
      spot.style.width = Math.max(36, r.width) + "px";
      spot.style.height = Math.max(36, r.height) + "px";
    }
    if (nube) {
      const nw = Math.min(360, window.innerWidth - 24);
      const nh = nube.offsetHeight || 180;
      let left = r.left + r.width + 16;
      let top = r.top;
      if (left + nw > window.innerWidth - 12) left = r.left - nw - 16;
      if (left < 12) left = 12;
      if (top + nh > window.innerHeight - 12) top = Math.max(12, window.innerHeight - nh - 12);
      if (top < 12) top = 12;
      nube.style.width = nw + "px";
      nube.style.left = left + "px";
      nube.style.top = top + "px";
    }
  }

  function go(n) {
    i = n;
    const step = STEPS[i];
    if (!step) {
      stop(true);
      return;
    }
    try {
      if (opts.showView) opts.showView(step.view);
    } catch (_) {}
    try {
      if (step.cfg && opts.showCfg) opts.showCfg(step.cfg);
    } catch (_) {}
    place();
    requestAnimationFrame(() => {
      try {
        const el = document.querySelector(step.sel);
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", inline: "nearest" });
      } catch (_) {}
      place();
      requestAnimationFrame(place);
    });
  }

  function start(more) {
    opts = more || {};
    const root = box();
    if (!root) return;
    on = true;
    i = 0;
    root.hidden = false;
    document.body.classList.add("coach-on");
    place();
    go(0);
  }

  async function stop(seen) {
    const root = box();
    if (root) root.hidden = true;
    document.body.classList.remove("coach-on");
    on = false;
    if (seen && opts.markSeen) {
      try {
        await opts.markSeen();
      } catch (_) {}
    }
  }

  function bind() {
    $("#coachNext")?.addEventListener("click", () => {
      if (i >= STEPS.length - 1) stop(true);
      else go(i + 1);
    });
    $("#coachSkip")?.addEventListener("click", () => stop(true));
    window.addEventListener("resize", () => {
      if (on) place();
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind);
  else bind();

  window.A10Tour = { start, stop };
})();
