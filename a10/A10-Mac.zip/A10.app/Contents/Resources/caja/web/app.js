(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

  const state = {
    view: "hoy",
    local: { name: "Mi local" },
    catalog: [],
    q: "",
    kind: "",
    cart: [],
    pay: "efectivo",
    taller: { llego: [], en_mesa: [], listo: [], entregado: [] },
    piso: { benches: [], techs: [], cola: [], lights: {}, n_benches: 0, n_techs: 0 },
    hoy: null,
    cifras: null,
    cifrasDias: 1,
    invQ: "",
    invKind: "",
    invBrand: "",
    invFlag: "",
    invSort: "name",
    listaDraft: [],
    listaKind: "lista",
    factura: { proveedor: "", folio: "", fecha: "" },
    mercado: { items: [], shops: [], fee_clp: 0, pedidos_abiertos: 0 },
    pedidos: [],
    mktQ: "",
    mktFf: "",
    scanMode: "vender",
    conteo: {},
    lastScan: "",
    lastScanAt: 0,
    lastSaleId: 0,
    tapa: null,
    fotoId: "",
    fotoTimer: 0,
    yo: null,
    impresoras: [],
    cfg: "tienda",
  };

  const ROLE_LBL = { dueno: "Dueño", mostrador: "Mostrador", tecnico: "Técnico" };
  const VISTAS = {
    mostrador: ["hoy", "vender", "inventario", "ventas", "clientes", "compras", "taller"],
    tecnico: ["hoy", "taller", "inventario"],
  };

  const COLS = [
    ["llego", "Llegó"],
    ["en_mesa", "En mesa"],
    ["listo", "Listo"],
    ["entregado", "Entregado"],
  ];
  const NEXT = { llego: "en_mesa", en_mesa: "listo", listo: "entregado" };
  const PAY_LBL = {
    efectivo: "Efectivo",
    debito: "Débito",
    credito: "Crédito",
    transferencia: "Transferencia",
  };
  const KIND_LBL = {
    celular: "Celular",
    accesorio: "Accesorio",
    repuesto: "Repuesto",
  };
  const FF_LBL = { retiro: "retiro", envio: "envío", ambos: "retiro o envío" };
  const LIGHT_LBL = {
    verde: "libre",
    amarillo: "en mesa",
    cyan: "listo",
    rojo: "atada",
    apagado: "apagada",
  };
  const RED_NEXT = {
    pedida: ["aceptada", "Aceptar"],
    aceptada: null,
    en_camino: ["lista", "Marcar lista"],
    lista: ["recibida", "Recibida"],
  };

  function clp(n) {
    const v = Math.round(Number(n) || 0);
    const signo = (state.local && state.local.simbolo) || "$";
    const cuerpo = String(Math.abs(v)).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return (v < 0 ? "-" : "") + signo + cuerpo;
  }
  function digits(raw) {
    return Number(String(raw ?? "").replace(/\D/g, "") || 0);
  }
  function marginPct(cost, price) {
    const c = Number(cost) || 0;
    const p = Number(price) || 0;
    if (c <= 0) return null;
    return Math.round(((p - c) / c) * 1000) / 10;
  }
  function marginLbl(cost, price) {
    const m = marginPct(cost, price);
    if (m == null) return "—";
    return (m % 1 ? m.toFixed(1) : String(m)) + "%";
  }
  function priceFromMargin(cost, pct) {
    const c = Number(cost) || 0;
    return Math.round(c * (1 + (Number(pct) || 0) / 100));
  }
  function imeiGroups(s) {
    const d = String(s || "").replace(/\D/g, "");
    return d.replace(/(\d{4})(?=\d)/g, "$1 ").trim();
  }
  function clock() {
    const d = new Date();
    const t = d.toLocaleTimeString("es-CL", {
      hour: "2-digit",
      minute: "2-digit",
    });
    const el = $("#clock");
    if (el) el.textContent = t;
  }

  let netState = { piloto: false, internet: true, expired: false, quedan_s: null };
  let pagoState = { url: "", hasta: "", quedan_d: null, vencido: false, mostrar: false };

  function fmtQuedan(s) {
    s = Math.max(0, Number(s) || 0);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    if (d > 0) return `${d}d ${h}h`;
    const ss = Math.floor(s % 60);
    const hh = String(h).padStart(2, "0");
    const mm = String(m).padStart(2, "0");
    const zz = String(ss).padStart(2, "0");
    return `${hh}:${mm}:${zz}`;
  }

  function cobrarBloqueado() {
    return !!(netState.piloto && netState.expired);
  }

  function syncCobrar() {
    const btn = $("#btnCobrar");
    if (!btn) return;
    btn.disabled = !state.cart.length || cobrarBloqueado();
  }

  function paintNet(data) {
    netState = data || netState;
    if (data && data.pago) {
      pagoState = data.pago;
      paintPago();
    }
    const bar = $("#netBar");
    const txt = $("#netTxt");
    const tiempo = $("#netTiempo");
    if (!bar) return;
    if (!netState.piloto) {
      bar.hidden = true;
      syncCobrar();
      return;
    }
    if (netState.expired) {
      bar.hidden = false;
      bar.classList.remove("on");
      if (txt) txt.textContent = "Conecta a internet para seguir cobrando.";
      if (tiempo) tiempo.textContent = "00:00:00";
      syncCobrar();
      return;
    }
    if (netState.internet) {
      bar.hidden = true;
      syncCobrar();
      return;
    }
    bar.hidden = false;
    bar.classList.remove("on");
    if (txt) txt.textContent = "Sin internet. El cobro sigue. Conecta antes de que se acabe el tiempo.";
    if (tiempo) tiempo.textContent = fmtQuedan(netState.quedan_s);
    syncCobrar();
  }

  async function pulsoRed() {
    try {
      const r = await fetch("/api/pulso", { cache: "no-store" });
      const data = await r.json().catch(() => ({}));
      paintNet(data);
    } catch (e) {
      paintNet({
        piloto: netState.piloto,
        internet: false,
        expired: netState.expired,
        quedan_s: netState.quedan_s,
      });
    }
  }
  function stockAlert() {
    const n = Number(state.local && state.local.stock_alert);
    return Number.isFinite(n) ? n : 2;
  }
  function defaultMargin() {
    const n = Number(state.local && state.local.margin_pct);
    return Number.isFinite(n) ? n : 100;
  }
  function renderPulse() {
    const name = (state.local && state.local.name) || "Mi local";
    const who = $("#pulseName");
    if (who) who.textContent = name;
    const loc = $("#localName");
    if (loc) loc.textContent = name;
    const hoy = state.hoy || {};
    const venta = $("#pulseVenta");
    const tickets = $("#pulseTickets");
    if (venta) venta.textContent = clp(hoy.ventas_clp || (hoy.hoy && hoy.hoy.ventas_clp) || 0);
    if (tickets) tickets.textContent = String(hoy.ventas_n || (hoy.hoy && hoy.hoy.ventas_n) || 0);
    const alert = stockAlert();
    const bajos = state.catalog.filter((p) => p.stock <= alert).length;
    const bajosEl = $("#pulseBajos");
    if (bajosEl) bajosEl.textContent = String(bajos);
    const listos = (state.taller.listo || []).length;
    const listosEl = $("#pulseListos");
    if (listosEl) listosEl.textContent = String(listos);
  }
  async function loadPulse() {
    try {
      state.hoy = await api("/api/cifras?dias=1");
    } catch {
      state.hoy = state.hoy || {};
    }
    renderPulse();
  }
  function toast(msg) {
    const el = $("#toast");
    el.textContent = msg;
    el.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => {
      el.hidden = true;
    }, 2800);
    if (/no |falta|error|pude|vi un|no está/i.test(String(msg || ""))) {
      reportaVida("aviso", msg);
    }
  }
  function reportaVida(tipo, texto) {
    fetch("/api/vida", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ tipo, texto: String(texto || "").slice(0, 180) }),
    }).catch(() => {});
  }
  async function api(path, opt) {
    const res = await fetch(path, {
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      ...opt,
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && path !== "/api/yo" && path !== "/api/login" && path !== "/api/primero") {
      try {
        const yo = await fetch("/api/yo", { cache: "no-store", credentials: "same-origin" }).then((r) => r.json());
        await gateReady(yo);
      } catch {
        showGate(false);
      }
    }
    if (!res.ok) throw new Error(data.detail || "no se pudo");
    return data;
  }

  function puedeVer(name) {
    const role = state.yo && state.yo.role;
    if (!role || role === "dueno") return true;
    return (VISTAS[role] || []).includes(name);
  }

  function paintWho() {
    const box = $("#railWho");
    const name = $("#railUser");
    const rol = $("#railRol");
    const yo = state.yo;
    if (!box) return;
    if (!yo) {
      box.hidden = true;
      return;
    }
    box.hidden = false;
    if (name) name.textContent = yo.name || "";
    if (rol) rol.textContent = ROLE_LBL[yo.role] || yo.role || "";
    $$(".rail-btn").forEach((b) => {
      const view = b.dataset.view;
      if (!view) return;
      b.hidden = !puedeVer(view);
    });
  }

  function showGate(primero, yo) {
    const gate = $("#gate");
    if (!gate) return;
    gate.hidden = false;
    const tit = $("#gateTitulo");
    const sub = $("#gateSub");
    const go = $("#gateGo");
    const names = (yo && yo.nombres) || [];
    const lista = $("#gateNombres");
    const olvido = $("#btnOlvido");
    if (tit) tit.textContent = primero ? "Crea el dueño de esta caja" : "Entra a esta caja";
    if (sub) {
      sub.textContent = primero
        ? "Primera persona. Dueño. Elige un nombre y una clave de 4 caracteres o más."
        : "Tu nombre y tu clave. El cobro queda en este PC.";
    }
    if (lista) {
      lista.hidden = primero || !names.length;
      lista.textContent = names.length ? "En esta caja entra: " + names.join(", ") + "." : "";
    }
    if (olvido) olvido.hidden = !!primero;
    if (go) go.textContent = primero ? "Abrir esta caja" : "Entrar";
    gate.dataset.primero = primero ? "1" : "0";
    const err = $("#gateErr");
    if (err) {
      if (yo && yo.recupero && yo.recupero.hecho) {
        err.hidden = false;
        err.textContent = "clave nueva lista. Entra con " + (yo.recupero.nombre || "tu nombre") + ".";
      } else {
        err.hidden = true;
      }
    }
    $("#fGate")?.elements?.name?.focus();
  }

  function hideGate() {
    const gate = $("#gate");
    if (gate) gate.hidden = true;
  }

  async function gateReady(yo) {
    if (yo && yo.user) {
      state.yo = yo.user;
      hideGate();
      paintWho();
      return true;
    }
    state.yo = null;
    if (yo && !yo.locked && !yo.primero) {
      hideGate();
      paintWho();
      return true;
    }
    showGate(!!(yo && yo.primero), yo);
    paintWho();
    return false;
  }

  function cartTotal() {
    return state.cart.reduce((s, l) => s + l.price_clp * l.qty, 0);
  }
  function findLine(id) {
    return state.cart.find((l) => l.product_id === id);
  }

  function addToCart(p) {
    if (p.stock <= 0) {
      toast("sin stock");
      return;
    }
    const existing = findLine(p.id);
    if (p.imei_required) {
      const ya = state.cart.filter((l) => l.product_id === p.id).length;
      if (ya >= p.stock) {
        toast("no alcanza el stock");
        return;
      }
      state.cart.push({
        product_id: p.id,
        name: p.name,
        qty: 1,
        price_clp: p.price_clp,
        imei_required: 1,
        imei: "",
        stock: p.stock,
      });
    } else if (existing) {
      if (existing.qty >= p.stock) {
        toast("no alcanza el stock");
        return;
      }
      existing.qty += 1;
    } else {
      state.cart.push({
        product_id: p.id,
        name: p.name,
        qty: 1,
        price_clp: p.price_clp,
        imei_required: 0,
        imei: "",
        stock: p.stock,
      });
    }
    const card = document.querySelector(`.pcard[data-pid="${p.id}"], .sale-row[data-pid="${p.id}"], .card[data-pid="${p.id}"]`);
    if (card) {
      card.classList.add("flash");
      setTimeout(() => card.classList.remove("flash"), 280);
    }
    renderCart();
  }

  function filtered() {
    const q = state.q.trim().toLowerCase();
    return state.catalog
      .filter((p) => {
        if (state.kind && p.kind !== state.kind) return false;
        if (!q) return true;
        return `${p.sku} ${p.name} ${p.brand} ${p.barcode || ""} ${p.ref_code || ""} ${p.ubicacion || ""}`.toLowerCase().includes(q);
      })
      .slice()
      .sort((a, b) => {
        const as = a.stock > 0 ? 0 : 1;
        const bs = b.stock > 0 ? 0 : 1;
        if (as !== bs) return as - bs;
        return String(a.name || "").localeCompare(String(b.name || ""), "es");
      });
  }

  function renderGrid() {
    const grid = $("#grid");
    const count = $("#sellCount");
    const chips = $("#chips");
    const landing = !state.q.trim() && !state.kind;
    if (chips) chips.hidden = landing;
    $$("#chips .chip").forEach((x) => x.classList.toggle("on", x.dataset.kind === (state.kind || "")));
    if (landing) {
      const alert = stockAlert();
      const n = (k) => state.catalog.filter((p) => !k || p.kind === k).length;
      const bajos = state.catalog.filter((p) => p.stock <= alert).length;
      if (count) count.textContent = "Toca lo que busca. Cobra aquí. Si no está, Inventario o Market10.";
      grid.classList.remove("hud");
      fillCentros();
      grid.innerHTML = `
        <div class="caja-deck">
          <button type="button" class="dest" data-kind="celular"><b>Celular</b><small>${n("celular")} listos para llevar</small></button>
          <button type="button" class="dest" data-kind="accesorio"><b>Funda, vidrio, cable</b><small>${n("accesorio")} al paso</small></button>
          <button type="button" class="dest" data-kind="repuesto"><b>Repuesto</b><small>${n("repuesto")} para el taller</small></button>
          <button type="button" class="dest dest-scan" data-scan="precio"><b>Consultar precio</b><small>escanea la etiqueta, no cobra</small></button>
          <button type="button" class="dest dest-go ${bajos ? "warn" : ""}" data-go="inventario" data-flag="bajos"><b>Se acaba</b><small>${bajos} para reponer</small></button>
        </div>`;
      $$(".dest[data-kind]", grid).forEach((el) => {
        el.addEventListener("click", () => {
          state.kind = el.dataset.kind;
          renderGrid();
        });
      });
      $$(".dest[data-scan]", grid).forEach((el) => {
        el.addEventListener("click", () => openScan(el.dataset.scan));
      });
      $$(".dest[data-go]", grid).forEach((el) => {
        el.addEventListener("click", () => {
          if (el.dataset.flag) {
            state.invFlag = el.dataset.flag;
            $$("#invFlags .chip").forEach((x) => x.classList.toggle("on", x.dataset.flag === el.dataset.flag));
          }
          showView(el.dataset.go);
        });
      });
      return;
    }
    const items = filtered();
    if (count) {
      count.textContent = items.length
        ? `${items.length} · toca la tarjeta para cobrar · la ficha abre Inventario`
        : "Nada con esa búsqueda";
    }
    if (!items.length) {
      grid.innerHTML = `<p class="cart-empty">Nada con esa búsqueda.</p>`;
      return;
    }
    const alert = stockAlert();
    grid.innerHTML = `<div class="pcard-deck">${items
      .map((p) => {
        const bajo = p.stock > 0 && p.stock <= alert;
        const thumb = p.photo
          ? `<img src="/fotos/${esc(p.photo)}" alt="">`
          : `<span>${esc((p.brand || p.name || "?").slice(0, 1))}</span>`;
        return `<article class="pcard ${bajo ? "bajo" : ""} ${p.stock <= 0 ? "out" : ""}" data-pid="${p.id}">
          <button type="button" class="pcard-buy" data-pid="${p.id}" ${p.stock <= 0 ? "disabled" : ""}>
            <span class="pcard-shot">${thumb}</span>
            <b>${esc(p.name)}</b>
            <small>${esc(p.brand || KIND_LBL[p.kind] || "")} · ${p.stock <= 0 ? "sin stock" : p.stock + " u."}</small>
            <strong>${clp(p.price_clp)}</strong>
          </button>
          <button type="button" class="pcard-inv" data-pid="${p.id}">Ficha</button>
        </article>`;
      })
      .join("")}</div>`;
    $$(".pcard-buy", grid).forEach((btn) => {
      btn.addEventListener("click", () => {
        const p = state.catalog.find((x) => x.id === Number(btn.dataset.pid));
        if (p) addToCart(p);
      });
    });
    $$(".pcard-inv", grid).forEach((btn) => {
      btn.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const p = state.catalog.find((x) => x.id === Number(btn.dataset.pid));
        if (!p) return;
        showView("inventario");
        formFicha(p);
      });
    });
  }

  function stockItems() {
    const q = state.invQ.trim().toLowerCase();
    const alert = stockAlert();
    let items = state.catalog.filter((p) => {
      if (state.invKind && p.kind !== state.invKind) return false;
      if (state.invBrand && (p.brand || "") !== state.invBrand) return false;
      if (state.invFlag === "bajos" && p.stock > alert) return false;
      if (state.invFlag === "sitio" && (p.ubicacion || "").trim()) return false;
      if (state.invFlag === "m10" && !p.market_on) return false;
      if (!q) return true;
      return `${p.sku} ${p.name} ${p.brand} ${p.barcode || ""} ${p.ref_code || ""} ${p.ubicacion || ""}`.toLowerCase().includes(q);
    });
    const sort = state.invSort;
    items = items.slice().sort((a, b) => {
      if (sort === "stock") return (a.stock || 0) - (b.stock || 0);
      if (sort === "sitio") return String(a.ubicacion || "ÿ").localeCompare(String(b.ubicacion || "ÿ"), "es");
      return String(a.name || "").localeCompare(String(b.name || ""), "es");
    });
    return items;
  }

  function renderStock() {
    const body = $("#stockBody");
    const sub = $("#invSub");
    if (!body) return;
    const alert = stockAlert();
    const items = stockItems();
    const n = state.catalog.length;
    const unidades = state.catalog.reduce((s, p) => s + (p.stock || 0), 0);
    const valor = state.catalog.reduce((s, p) => s + (p.stock || 0) * (p.price_clp || 0), 0);
    const bajos = state.catalog.filter((p) => p.stock <= alert).length;
    const sinSitio = state.catalog.filter((p) => !(p.ubicacion || "").trim()).length;
    if (sub) sub.textContent = `${items.length} en esta vista · ${n} en el local. Toca una fila para editarla.`;
    fillCentros();
    const stats = $("#invStats");
    if (stats) {
      stats.innerHTML = `
        <div class="inv-stat"><span>Productos</span><b>${n}</b></div>
        <div class="inv-stat"><span>Unidades</span><b>${unidades}</b></div>
        <div class="inv-stat"><span>Valor stock</span><b>${clp(valor)}</b></div>
        <div class="inv-stat ${bajos ? "warn" : ""}"><span>Bajos</span><b>${bajos}</b></div>
        <div class="inv-stat ${sinSitio ? "warn" : ""}"><span>Sin ubicación</span><b>${sinSitio}</b></div>`;
    }
    const brandSel = $("#invBrand");
    if (brandSel) {
      const brands = [...new Set(state.catalog.map((p) => p.brand).filter(Boolean))].sort((a, b) => a.localeCompare(b, "es"));
      const keep = state.invBrand;
      brandSel.innerHTML = `<option value="">Todas las marcas</option>` + brands.map((b) => `<option value="${esc(b)}" ${b === keep ? "selected" : ""}>${esc(b)}</option>`).join("");
    }
    if (!items.length) {
      body.innerHTML = `<tr><td colspan="11" class="col-empty">Nada en el inventario con esa búsqueda.</td></tr>`;
      return;
    }
    body.innerHTML = items
      .map(
        (p) => `<tr class="${p.stock <= alert ? "bajo" : ""}" data-pid="${p.id}">
          <td class="stock-shot">${
            p.photo
              ? `<img src="/fotos/${esc(p.photo)}" alt="">`
              : `<span>${esc((p.brand || p.name || "?").slice(0, 1))}</span>`
          }</td>
          <td><b>${esc(p.name)}</b><small class="kind">${esc(KIND_LBL[p.kind] || p.kind)}</small></td>
          <td>${esc(p.brand || "—")}</td>
          <td class="refs">${esc(p.sku || "—")}</td>
          <td class="refs">${esc(p.ref_code || p.barcode || "—")}</td>
          <td class="sitio">${esc(p.ubicacion || "—")}</td>
          <td class="num ${p.stock <= alert ? "warn" : ""}">${p.stock}</td>
          <td class="m10-cell">
            <button type="button" class="m10-sw ${p.market_on ? "on" : ""}" data-m10="${p.id}" title="Subir a Market10">
              ${p.market_on ? "En red" : "Subir"}
            </button>
          </td>
          <td class="num">${p.cost_clp ? clp(p.cost_clp) : "—"}</td>
          <td class="num">${marginLbl(p.cost_clp, p.price_clp)}</td>
          <td class="num money">${clp(p.price_clp)}</td>
        </tr>`
      )
      .join("");
    $$("#stockBody tr[data-pid]").forEach((row) => {
      row.addEventListener("click", () => {
        const p = state.catalog.find((x) => x.id === Number(row.dataset.pid));
        if (p) formFicha(p);
      });
    });
    $$("#stockBody [data-m10]").forEach((btn) => {
      btn.addEventListener("click", async (ev) => {
        ev.stopPropagation();
        const p = state.catalog.find((x) => x.id === Number(btn.dataset.m10));
        if (!p) return;
        try {
          await publicarMarket(p, !p.market_on);
        } catch (e) {
          toast(e.message);
        }
      });
    });
    renderPulse();
  }

  function renderCart() {
    const box = $("#cartLines");
    const empty = !state.cart.length;
    $("#btnVaciar").hidden = empty;
    syncCobrar();
    $("#cartTotal").textContent = clp(cartTotal());
    const row = $(".total-row");
    row.classList.add("pulse");
    setTimeout(() => row.classList.remove("pulse"), 320);
    if (empty) {
      box.innerHTML = `<p class="cart-empty"><b>Ticket vacío</b>Busca a la izquierda y toca un producto para cobrarlo.</p>`;
      return;
    }
    box.innerHTML = state.cart
      .map(
        (l, i) => `
      <div class="line" data-i="${i}">
        <div>
          <div class="line-name">${esc(l.name)}</div>
          <div class="line-meta">${clp(l.price_clp)} c/u</div>
        </div>
        <div>
          <div class="line-sum">${clp(l.price_clp * l.qty)}</div>
          <div class="qty">
            <button type="button" data-act="minus" aria-label="Quitar">−</button>
            <b>${l.qty}</b>
            <button type="button" data-act="plus" aria-label="Sumar">+</button>
            <button type="button" class="drop-line" data-act="drop" aria-label="Sacar">×</button>
          </div>
        </div>
        ${
          l.imei_required
            ? `<input class="imei" inputmode="numeric" maxlength="19" placeholder="IMEI · 15 dígitos" value="${esc(imeiGroups(l.imei))}">`
            : ""
        }
      </div>`
      )
      .join("");
    $$(".line", box).forEach((el) => {
      const i = Number(el.dataset.i);
      el.addEventListener("click", (ev) => {
        const act = ev.target.dataset.act;
        if (act === "drop") {
          state.cart.splice(i, 1);
          renderCart();
        }
        if (act === "minus") {
          state.cart[i].qty -= 1;
          if (state.cart[i].qty <= 0) state.cart.splice(i, 1);
          renderCart();
        }
        if (act === "plus") {
          const line = state.cart[i];
          if (line.imei_required) {
            const p = (state.catalog || []).find((x) => x.id === line.product_id);
            if (p) addToCart(p);
            else toast("ese celular pide su propio IMEI");
            return;
          }
          if (line.qty >= line.stock) {
            toast("no alcanza el stock");
            return;
          }
          line.qty += 1;
          renderCart();
        }
      });
      const imei = $(".imei", el);
      if (imei) {
        imei.addEventListener("input", () => {
          const d = imei.value.replace(/\D/g, "").slice(0, 15);
          state.cart[i].imei = d;
          imei.value = imeiGroups(d);
        });
      }
    });
  }

  function jobWhere(j) {
    const bits = [];
    if (j.bench_name || j.bench_n) bits.push(j.bench_name || `Mesa ${j.bench_n}`);
    if (j.tech_name) bits.push(j.tech_name);
    return bits.length ? `<div class="job-where">${esc(bits.join(" · "))}</div>` : "";
  }

  function renderTaller() {
    const nOpen =
      (state.taller.llego || []).length +
      (state.taller.en_mesa || []).length +
      (state.taller.listo || []).length;
    const badge = $("#badgeTaller");
    badge.hidden = nOpen === 0;
    badge.textContent = String(nOpen);
    const sub = $("#pisoSub");
    if (sub) {
      sub.textContent = "Recibe el equipo, avanza el estado, cobra al entregar.";
    }
    fillCentros();
    const benchSel = $("#fConstancia [name=bench_id]");
    const techSel = $("#fConstancia [name=tech_id]");
    if (benchSel) benchSel.innerHTML = benchOptions(benchSel.value);
    if (techSel) techSel.innerHTML = techOptions(techSel.value);
    renderFloor();
    renderEquipo();
    renderPulse();
    $("#board").innerHTML = COLS.map(([key, label]) => {
      const jobs = state.taller[key] || [];
      const body = jobs.length
        ? jobs
            .map(
              (j) => `
          <button type="button" class="job" data-oid="${j.id}">
            <div class="job-dev">${esc(j.device)}</div>
            <div class="job-who">${esc(j.customer_name)}</div>
            <div class="job-issue">${esc(j.issue)}</div>
            ${jobWhere(j)}
            ${j.imei ? `<div class="job-imei">${esc(imeiGroups(j.imei))}</div>` : ""}
          </button>`
            )
            .join("")
        : `<p class="col-empty">Vacío</p>`;
      return `<section class="col ${key}">
        <header class="col-h"><b>${label}</b><span>${jobs.length}</span></header>
        <div class="col-body">${body}</div>
      </section>`;
    }).join("");
    $$("#board .job").forEach((btn) => {
      btn.addEventListener("click", () => openJob(Number(btn.dataset.oid)));
    });
  }

  function renderFloor() {
    const floor = $("#floor");
    const legend = $("#lights");
    if (!floor) return;
    const benches = (state.piso.benches || []).filter((b) => b.active);
    const lights = state.piso.lights || {};
    floor.innerHTML = benches
      .map(
        (b) => `
      <button type="button" class="bench ${esc(b.light)}" data-bid="${b.id}"
        style="left:${(b.x * 100).toFixed(1)}%;top:${(b.y * 100).toFixed(1)}%">
        <i class="sema" aria-hidden="true"></i>
        <b>${esc(b.label || b.name || "Mesa " + b.n)}</b>
        <small>${esc(LIGHT_LBL[b.light] || b.light)}${b.jobs && b.jobs.length ? " · " + b.jobs.length : ""}</small>
        <span class="bench-drag" data-drag="${b.id}" aria-label="Mover mesa">↕</span>
      </button>`
      )
      .join("");
    if (legend) {
      legend.innerHTML = ["verde", "amarillo", "cyan", "rojo"]
        .map(
          (k) =>
            `<li class="${k}"><i></i>${LIGHT_LBL[k]} <b>${lights[k] || 0}</b></li>`
        )
        .join("");
    }
    $$(".bench", floor).forEach((el) => {
      el.addEventListener("click", (ev) => {
        if (ev.target.closest("[data-drag]")) return;
        openBench(Number(el.dataset.bid));
      });
    });
    bindFloorDrag(floor);
  }

  function bindFloorDrag(floor) {
    floor.addEventListener("pointerdown", (ev) => {
      const handle = ev.target.closest("[data-drag]");
      if (!handle) return;
      ev.preventDefault();
      ev.stopPropagation();
      const bench = handle.closest(".bench");
      const rect = floor.getBoundingClientRect();
      const drag = {
        id: Number(handle.dataset.drag),
        el: bench,
        ox: ev.clientX - bench.getBoundingClientRect().left,
        oy: ev.clientY - bench.getBoundingClientRect().top,
        rect,
        x: null,
        y: null,
      };
      bench.classList.add("dragging");
      const move = (e) => {
        const x = (e.clientX - drag.rect.left - drag.ox) / drag.rect.width;
        const y = (e.clientY - drag.rect.top - drag.oy) / drag.rect.height;
        const cx = Math.min(0.84, Math.max(0, x));
        const cy = Math.min(0.82, Math.max(0, y));
        drag.el.style.left = (cx * 100).toFixed(1) + "%";
        drag.el.style.top = (cy * 100).toFixed(1) + "%";
        drag.x = cx;
        drag.y = cy;
      };
      const end = async () => {
        handle.removeEventListener("pointermove", move);
        handle.removeEventListener("pointerup", end);
        handle.removeEventListener("pointercancel", end);
        bench.classList.remove("dragging");
        if (drag.x == null) return;
        try {
          state.piso = await api(`/api/taller/mesas/${drag.id}`, {
            method: "POST",
            body: JSON.stringify({ x: drag.x, y: drag.y }),
          });
          renderFloor();
        } catch (e) {
          toast(e.message);
        }
      };
      handle.addEventListener("pointermove", move);
      handle.addEventListener("pointerup", end);
      handle.addEventListener("pointercancel", end);
      handle.setPointerCapture?.(ev.pointerId);
    });
  }

  function renderEquipo() {
    const box = $("#equipoTaller");
    if (!box) return;
    const benches = (state.piso.benches || []).filter((b) => b.active);
    const techs = (state.piso.techs || []).filter((t) => t.active);
    const partes = state.catalog.filter((p) => p.kind === "repuesto" || p.kind === "accesorio");
    box.innerHTML = `
      <div class="eq-head">
        <h2>Personal y mesas</h2>
        <p>Asigna el técnico. Carga piezas a la mesa: salen del inventario. Cuando las usa, queda la cuenta.</p>
      </div>
      <div class="eq-grid">
        ${benches
          .map(
            (b) => `<article class="eq-mesa" data-bid="${b.id}">
          <header>
            <b>${esc(b.label)}</b>
            <select data-asig="${b.id}" aria-label="Técnico de ${esc(b.label)}">
              <option value="">Sin técnico</option>
              ${techs
                .map(
                  (t) =>
                    `<option value="${t.id}" ${Number(b.tech_id) === t.id ? "selected" : ""}>${esc(t.name)}</option>`
                )
                .join("")}
            </select>
          </header>
          <ul>
            ${
              (b.stock || []).length
                ? (b.stock || [])
                    .map(
                      (s) => `<li>
                  <span>${esc(s.name)} <b>${s.qty}</b></span>
                  <button type="button" data-uso="${b.id}" data-pid="${s.product_id}">Usó 1</button>
                </li>`
                    )
                    .join("")
                : `<li class="mute">Sin piezas en esta mesa</li>`
            }
          </ul>
          <p class="eq-cost">${b.stock_n ? `${b.stock_n} u. · costo ${clp(b.stock_cost)}` : "—"}</p>
          <div class="eq-add">
            <select data-addp="${b.id}">
              <option value="">Pieza del inventario…</option>
              ${partes
                .map((p) => `<option value="${p.id}">${esc(p.name)} (${p.stock})</option>`)
                .join("")}
            </select>
            <button type="button" class="key ghost" data-carga="${b.id}">Cargar</button>
          </div>
        </article>`
          )
          .join("")}
      </div>`;
    $$("#equipoTaller [data-asig]").forEach((sel) => {
      sel.addEventListener("change", async () => {
        try {
          state.piso = await api(`/api/taller/mesas/${sel.dataset.asig}/tecnico`, {
            method: "POST",
            body: JSON.stringify({ tech_id: sel.value ? Number(sel.value) : null }),
          });
          renderTaller();
          toast("técnico en la mesa");
        } catch (e) {
          toast(e.message);
        }
      });
    });
    const mover = async (bid, pid, reason) => {
      try {
        state.piso = await api(`/api/taller/mesas/${bid}/stock`, {
          method: "POST",
          body: JSON.stringify({ product_id: Number(pid), qty: 1, reason }),
        });
        await loadCatalog();
        renderTaller();
        toast(reason === "uso" ? "salió de la mesa" : "en la mesa");
      } catch (e) {
        toast(e.message);
      }
    };
    $$("#equipoTaller [data-carga]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const sel = $(`#equipoTaller [data-addp="${btn.dataset.carga}"]`);
        if (!sel || !sel.value) {
          toast("elige una pieza");
          return;
        }
        mover(btn.dataset.carga, sel.value, "carga");
      });
    });
    $$("#equipoTaller [data-uso]").forEach((btn) => {
      btn.addEventListener("click", () => mover(btn.dataset.uso, btn.dataset.pid, "uso"));
    });
  }

  function periodoLbl(days) {
    return days === 1 ? "hoy" : "últimos " + days + " días";
  }

  function markDias() {
    $$("#hoyDias .chip, #ventasDias .chip, #repDias .chip").forEach((x) => {
      x.classList.toggle("on", Number(x.dataset.dias) === state.cifrasDias);
    });
  }

  function bindAtencion(root) {
    $$(`${root} [data-go]`).forEach((el) => {
      el.addEventListener("click", () => {
        if (el.dataset.flag) {
          state.invFlag = el.dataset.flag;
          $$("#invFlags .chip").forEach((x) => x.classList.toggle("on", x.dataset.flag === el.dataset.flag));
        }
        showView(el.dataset.go);
      });
    });
  }

  function paintCentro(id, frase, cards) {
    const el = $(id);
    if (!el) return;
    el.innerHTML =
      `<p class="centro-frase">${esc(frase)}</p>` +
      `<div class="centro-cards">${(cards || [])
        .map(
          (c) => `<button type="button" class="centro-card${c.warn ? " warn" : ""}" data-go="${esc(c.go || "")}" data-flag="${esc(c.flag || "")}">
            <b>${typeof c.n === "number" ? c.n : esc(c.n)}</b>
            <span>${esc(c.titulo)}<small>${esc(c.detalle || "")}</small></span>
          </button>`
        )
        .join("")}</div>`;
    bindAtencion(id);
  }

  function fillCentros() {
    const c = state.cifras || state.hoy || {};
    const tal = c.taller || {};
    const inv = c.inventario || {};
    const listos = (state.taller.listo || []).length || tal.listo || 0;
    const llego = (state.taller.llego || []).length || tal.llego || 0;
    const enMesa = (state.taller.en_mesa || []).length || tal.en_mesa || 0;
    const abiertos =
      (state.taller.llego || []).length +
      (state.taller.en_mesa || []).length +
      (state.taller.listo || []).length;
    const nOpen = abiertos || tal.abiertos || 0;
    const hoy = c.hoy || {};
    const bajos = inv.bajos != null ? inv.bajos : state.catalog.filter((p) => p.stock <= stockAlert()).length;
    const sinSitio = inv.sin_sitio || 0;
    const tickets = hoy.ventas_n != null ? hoy.ventas_n : c.ventas_n || 0;
    const venta = hoy.ventas_clp != null ? hoy.ventas_clp : c.ventas_clp || 0;
    const red = (state.mercado && (state.mercado.pedidos_abiertos || 0)) || 0;
    const sinTech = c.sin_tecnico || 0;
    paintCentro("#centroPaso", "Venta rápida. Busca, cobra y listo. Esto no es factura del SII.", [
      { n: tickets, titulo: "Ventas de hoy", detalle: "ya cobradas", go: "ventas" },
      { n: listos, titulo: "Listos para entregar", detalle: "cobro de servicio", go: "taller", warn: !!listos },
      { n: bajos, titulo: "Bajos", detalle: "revisa al vender", go: "inventario", flag: "bajos", warn: !!bajos },
    ]);
    paintCentro("#centroTickets", "Ventas cobradas. Anular hoy devuelve el stock. No es boleta del SII.", [
      { n: clp(venta), titulo: "Cobrado", detalle: "este período", go: "vender" },
      { n: tickets, titulo: "Ventas", detalle: "cobrar otra en Ventas", go: "vender" },
      { n: listos, titulo: "Servicio listo", detalle: "aún sin cobrar", go: "taller", warn: !!listos },
    ]);
    paintCentro("#centroBodega", "Contar, ubicar y reponer. Si no está, se pide a otro local.", [
      { n: bajos, titulo: "Bajos", detalle: "pedir o contar", go: "inventario", flag: "bajos", warn: !!bajos },
      { n: sinSitio, titulo: "Sin ubicación", detalle: "están, no se sabe el cajón", go: "inventario", flag: "sitio", warn: !!sinSitio },
      { n: red, titulo: "Pedir en Market10", detalle: "otro local", go: "compras" },
    ]);
    paintCentro("#centroTaller", "Toma foto de la tapa o de la pantalla. A10 arma la ficha atrás. Tú puedes seguir.", [
      { n: llego, titulo: "Recién llegaron", detalle: "sin mesa todavía", go: "taller", warn: !!llego },
      { n: enMesa, titulo: "En mesa", detalle: "se están reparando", go: "taller" },
      { n: listos, titulo: "Listos", detalle: "cobrar al entregar", go: "taller", warn: !!listos },
      { n: sinTech, titulo: "Sin técnico", detalle: "nadie los tomó", go: "taller", warn: !!sinTech },
    ]);
    paintCentro("#centroRed", "Repuesto en otro local A10. El stock de esta caja no se mezcla.", [
      { n: red, titulo: "Pedidos abiertos", detalle: "hay trámite", go: "compras", warn: !!red },
      { n: bajos, titulo: "Bajos aquí", detalle: "tal vez lo tiene otro", go: "inventario", flag: "bajos", warn: !!bajos },
      { n: nOpen, titulo: "Servicio abierto", detalle: "puede faltar el repuesto", go: "taller" },
    ]);
  }

  function bindAnular(root) {
    $$(`${root} [data-anular]`).forEach((el) => {
      el.addEventListener("click", async () => {
        if (!confirm("¿Anular esta venta de hoy? El stock vuelve.")) return;
        try {
          await api(`/api/sales/${el.dataset.anular}/anular`, { method: "POST", body: "{}" });
          toast("venta anulada");
          await loadCifras();
          await loadPulse();
        } catch (err) {
          toast(err.message || "no se pudo anular");
        }
      });
    });
  }

  function fraseInicio(c) {
    const tal = c.taller || {};
    const inv = c.inventario || {};
    const venta = Number(c.ventas_clp) || 0;
    const margen = Number(c.margen_clp) || 0;
    const n = Number(c.ventas_n) || 0;
    const listos = tal.listo || 0;
    const bajos = inv.bajos || 0;
    const pct = venta > 0 ? Math.round((margen / venta) * 100) : 0;
    const cuando = c.days === 1 ? "Hoy" : periodoLbl(c.days);
    if (!n && listos) {
      return `${cuando} no se cobró. Hay ${listos} ${listos === 1 ? "equipo listo" : "equipos listos"}: plata parada hasta que el cliente pase.`;
    }
    if (!n && bajos) {
      return `${cuando} no se cobró. El inventario vale ${clp(inv.venta_clp)} y ${bajos} productos se están acabando.`;
    }
    if (!n) {
      return `${cuando} todavía no entra plata. La primera venta se cobra en Ventas.`;
    }
    if (listos) {
      return `${cuando} cobraste ${clp(venta)} y te quedó ${clp(margen)} (${pct}%). ${listos} ${listos === 1 ? "equipo espera" : "equipos esperan"} en Servicio.`;
    }
    if (bajos) {
      return `${cuando} cobraste ${clp(venta)}. De cada $100 te quedan $${pct}. ${bajos} productos están bajos.`;
    }
    return `${cuando} cobraste ${clp(venta)} y te quedó ${clp(margen)} (${pct}%). El inventario vale ${clp(inv.venta_clp)}.`;
  }

  function renderHoy() {
    const c = state.cifras;
    const box = $("#hoyDash");
    if (!c || !box) return;
    fillCentros();
    const sub = $("#hoySub");
    if (sub) sub.textContent = "";
    const venta = Number(c.ventas_clp) || 0;
    const n = Number(c.ventas_n) || 0;
    const ticket = n ? Math.round(venta / n) : 0;
    const pct = venta > 0 ? Math.round((Number(c.margen_clp) / venta) * 100) : 0;
    const attn = (c.atencion || []).filter((a) => Number(a.n) > 0);
    const bajos = c.bajos || [];
    const hora = new Date().toLocaleTimeString("es-CL", { hour: "2-digit", minute: "2-digit" });
    let mes = "";
    if (pagoState.mostrar) {
      const txt = pagoState.vencido
        ? "El mes se venció. Paga en Banco de Chile para renovar."
        : pagoState.quedan_d != null
          ? `El mes vence en ${pagoState.quedan_d} día${pagoState.quedan_d === 1 ? "" : "s"}.`
          : "Toca para pagar el mes en Banco de Chile.";
      mes = pagoState.url
        ? `<a class="alert go" id="hoyPagar" href="${esc(pagoState.url)}" target="_blank" rel="noopener"><b>Mes</b><span>${esc(txt)}<small>Te abre el link del banco. A10 no ve el dinero solo.</small></span></a>`
        : `<button type="button" class="alert go" data-go="ajustes" data-cfg="mes"><b>Mes</b><span>Falta el link de Banco de Chile.<small>Pégalo en Ajustes → El mes.</small></span></button>`;
    }
    box.innerHTML = `
      <div class="dash">
        <p class="dash-kicker">${esc(c.local || "Este local")} · ${hora}</p>
        ${mes}
        <div class="dash-hero">
          <button type="button" class="dash-fig sold" data-go="vender">
            <i></i>
            <em>Vendido</em>
            <strong>${clp(venta)}</strong>
            <span>${n} ${n === 1 ? "ticket" : "tickets"} · promedio ${clp(ticket)}</span>
          </button>
          <button type="button" class="dash-fig gain" data-go="hoy">
            <i></i>
            <em>Ganando</em>
            <strong>${clp(c.margen_clp)}</strong>
            <span>${pct}% de lo cobrado · costo ${clp(c.costo_clp)}</span>
          </button>
        </div>
        <div class="dash-split">
          <section class="dash-panel">
            <h2>Resolver ahora</h2>
            ${
              attn.length
                ? attn
                    .map(
                      (a) => `<button type="button" class="dash-hit" data-go="${esc(a.go)}" data-flag="${esc(a.flag || "")}">
                        <b>${a.n}</b>
                        <span>${esc(a.titulo)}<small>${esc(a.detalle || "")}</small></span>
                      </button>`
                    )
                    .join("")
                : `<p class="dash-ok">Nada trabado. El local corre.</p>`
            }
          </section>
          <section class="dash-panel">
            <h2>Se acaba</h2>
            ${
              bajos.length
                ? `<ul class="dash-gone">${bajos
                    .map(
                      (p) =>
                        `<li data-go="inventario" data-flag="bajos"><b>${p.stock}</b><span>${esc(p.name)}</span><em>${clp(p.price_clp)}</em></li>`
                    )
                    .join("")}</ul>`
                : `<p class="dash-ok">Stock en regla.</p>`
            }
          </section>
        </div>
      </div>`;
    bindAtencion("#hoyDash");
    $$("#hoyDash [data-cfg='mes']").forEach((el) => {
      el.addEventListener("click", () => {
        showView("ajustes");
        showCfg("mes");
      });
    });
    $$("#hoyDash [data-go]").forEach((el) => {
      if (el.tagName === "LI") {
        el.addEventListener("click", () => {
          state.invFlag = "bajos";
          showView("inventario");
        });
      }
    });
  }

  function renderVentas() {
    const c = state.cifras;
    const box = $("#ventasDash");
    if (!c || !box) return;
    const sub = $("#ventasSub");
    if (sub) sub.textContent = `${c.local} · ${periodoLbl(c.days)}. Lo cobrado aquí. No es boleta del SII.`;
    fillCentros();
    const rows = c.ventas || c.ultimas || [];
    const payMax = Math.max(1, ...Object.values(c.por_pago || {}));
    const vivas = rows.filter((s) => !Number(s.voided || 0));
    const anuladas = rows.length - vivas.length;
    box.innerHTML = `
      <div class="docs-map">
        <p><b>Aquí:</b> el ticket de cobro y anular el del mismo día (el stock vuelve).</p>
        <p><b>No es:</b> boleta, factura, nota de crédito ni guía. Eso es el SII. Esta caja no lo emite.</p>
      </div>
      <div class="kpis">
        <div class="kpi money"><dt>Cobrado</dt><dd>${clp(c.ventas_clp)}</dd></div>
        <div class="kpi"><dt>Ventas</dt><dd>${c.ventas_n}</dd></div>
        <div class="kpi"><dt>Anuladas</dt><dd>${anuladas}</dd></div>
        <div class="kpi ${c.margen_clp >= 0 ? "ok" : "warn"}"><dt>Margen</dt><dd>${clp(c.margen_clp)}</dd></div>
      </div>
      <div class="pay-bars">
        ${Object.entries(c.por_pago || {})
          .map(([k, v]) => `<div class="pay-bar"><span>${PAY_LBL[k] || k}</span><i><em style="width:${Math.round((v / payMax) * 100)}%"></em></i><b>${clp(v)}</b></div>`)
          .join("")}
      </div>
      <div class="stock-wrap hud">
        <table class="stock ventas-tbl">
          <thead>
            <tr>
              <th>Hora</th>
              <th>Pago</th>
              <th>Origen</th>
              <th>Estado</th>
              <th>Total</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            ${
              rows.length
                ? rows
                    .map((s) => {
                      const anulada = Boolean(s.voided);
                      const puede = !anulada && !s.order_id && c.days === 1;
                      return `<tr class="${anulada ? "voided" : ""}">
                        <td>${esc((s.ts || "").slice(0, 16).replace("T", " "))}</td>
                        <td>${esc(PAY_LBL[s.pay_method] || s.pay_method)}</td>
                        <td>${s.order_id ? "Servicio" : "Ventas"}</td>
                        <td>${anulada ? "Anulada" : "Cobrada"}</td>
                        <td>${clp(s.total_clp)}</td>
                        <td>${puede ? `<button type="button" class="key ghost" data-anular="${s.id}">Anular</button>` : ""}</td>
                      </tr>`;
                    })
                    .join("")
                : `<tr><td colspan="6" class="col-empty">Sin tickets en este período.</td></tr>`
            }
          </tbody>
        </table>
      </div>`;
    bindAnular("#ventasDash");
  }

  function renderLocal() {
    renderHoy();
    renderVentas();
    renderFinanzas();
    renderReportes();
  }

  function renderFinanzas() {
    const c = state.cifras;
    const pri = $("#finanzasPri");
    const sec = $("#finanzasSec");
    if (!c || !pri || !sec) return;
    const payMax = Math.max(1, ...Object.values(c.por_pago || {}));
    pri.innerHTML = `
      <div class="kpis">
        <div class="kpi money"><dt>Cobrado</dt><dd>${clp(c.ventas_clp)}</dd></div>
        <div class="kpi ${c.margen_clp >= 0 ? "ok" : "warn"}"><dt>Ganancia aprox.</dt><dd>${clp(c.margen_clp)}</dd></div>
        <div class="kpi"><dt>Costo</dt><dd>${clp(c.costo_clp)}</dd></div>
      </div>`;
    sec.innerHTML = `
      <p class="zona-lbl">Cómo se pagó</p>
      <div class="pay-bars">
        ${Object.entries(c.por_pago || {})
          .map(([k, v]) => `<div class="pay-bar"><span>${PAY_LBL[k] || k}</span><i><em style="width:${Math.round((v / payMax) * 100)}%"></em></i><b>${clp(v)}</b></div>`)
          .join("")}
      </div>`;
  }

  function renderReportes() {
    const c = state.cifras;
    const pri = $("#reportesPri");
    const sec = $("#reportesSec");
    if (!c || !pri || !sec) return;
    const inv = c.inventario || {};
    pri.innerHTML = `
      <div class="kpis">
        <div class="kpi money"><dt>Vendido</dt><dd>${clp(c.ventas_clp)}</dd></div>
        <div class="kpi"><dt>Ventas</dt><dd>${c.ventas_n}</dd></div>
        <div class="kpi ok"><dt>Margen</dt><dd>${clp(c.margen_clp)}</dd></div>
        <div class="kpi"><dt>Inventario</dt><dd>${clp(inv.venta_clp)}</dd></div>
      </div>`;
    const techs = c.tecnicos || [];
    sec.innerHTML = techs.length
      ? `<p class="zona-lbl">Por técnico</p><table class="stock compact"><thead><tr><th>Técnico</th><th>Abiertas</th><th>Entregadas</th></tr></thead><tbody>
          ${techs.map((t) => `<tr><td>${esc(t.name || "—")}</td><td>${t.abiertas || 0}</td><td>${t.entregadas || 0}</td></tr>`).join("")}
        </tbody></table>`
      : `<p class="empty">Sin órdenes con técnico en este período.</p>`;
  }

  async function loadClientes() {
    const body = $("#clientesBody");
    if (!body) return;
    try {
      const rows = await api("/api/clientes");
      body.innerHTML = rows.length
        ? rows
            .map(
              (r) =>
                `<tr><td>${esc(r.name)}</td><td>${esc(r.phone || "—")}</td><td>${r.visitas}</td><td>${esc((r.ultima || "").slice(0, 16).replace("T", " "))}</td></tr>`
            )
            .join("")
        : `<tr><td colspan="4" class="col-empty">Todavía no hay clientes en servicio.</td></tr>`;
    } catch (e) {
      body.innerHTML = `<tr><td colspan="4" class="col-empty">${esc(e.message)}</td></tr>`;
    }
  }

  async function loadSistema() {
    const box = $("#sisList");
    const live = $("#cajaLive");
    try {
      const s = await api("/api/sistema");
      if (box) {
        box.innerHTML = (s.piezas || [])
          .map(
            (p) =>
              `<li class="${p.ok ? "ok" : "bad"}"><b>${esc(p.titulo)}</b><span>${esc(p.detalle)}</span></li>`
          )
          .join("");
      }
      if (live) {
        live.hidden = !!s.ok;
        live.textContent = s.ok ? "" : "hay una falla";
        live.classList.toggle("warn", !s.ok);
      }
    } catch (e) {
      if (box) box.innerHTML = `<li class="bad"><b>Informe</b><span>${esc(e.message)}</span></li>`;
      if (live) {
        live.hidden = false;
        live.textContent = "sin informe";
      }
    }
  }

  function esc(s) {
    return String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function enTelefono() {
    return window.matchMedia("(max-width: 600px) and (orientation: portrait)").matches;
  }
  function railPri(name) {
    return name === "hoy" || name === "vender" || name === "inventario" || name === "taller";
  }
  function vistaEnPantalla(name) {
    if (enTelefono()) return !!document.querySelector(`.view[data-view="${name}"]`);
    const btn = document.querySelector(`.rail-btn[data-view="${name}"]`);
    if (!btn) return true;
    if (btn.hidden) return false;
    return getComputedStyle(btn).display !== "none";
  }
  function closeMas() {
    const el = $("#masSheet");
    if (el) el.hidden = true;
  }
  function openMas() {
    const el = $("#masSheet");
    if (!el) return;
    el.hidden = false;
    if (window.A10applyI18n) window.A10applyI18n((state.local && state.local.idioma) || "es");
  }
  function showView(name) {
    if (name === "local") name = "hoy";
    if (name === "mercado") name = "compras";
    if (!puedeVer(name)) name = "hoy";
    if (!vistaEnPantalla(name)) {
      if (name === "ventas" || name === "finanzas") name = "vender";
      else if (name === "clientes") name = "taller";
      else name = "hoy";
    }
    closeSheet();
    closeMas();
    $("#ticket").hidden = true;
    state.view = name;
    document.body.dataset.vista = name;
    $$(".view").forEach((v) => {
      const on = v.dataset.view === name;
      v.classList.toggle("on", on);
      v.hidden = !on;
    });
    $$(".rail-btn").forEach((b) => {
      const masOn = b.id === "btnAjustes" && enTelefono() && !railPri(name);
      const on = b.dataset.view === name || masOn;
      b.classList.toggle("on", on);
      b.setAttribute("aria-selected", on ? "true" : "false");
    });
    if (name === "taller") loadTaller();
    if (name === "inventario") renderStock();
    if (name === "compras") loadMercado();
    if (name === "hoy" || name === "ventas" || name === "finanzas" || name === "reportes") loadCifras();
    if (name === "clientes") loadClientes();
    if (name === "ajustes") {
      fillAjustes();
      showCfg(state.cfg || "tienda");
    }
    reportaVida("pantalla", name);
  }

  function benchOptions(selected) {
    const benches = (state.piso.benches || []).filter((b) => b.active);
    const opts = [`<option value="">Sin mesa</option>`].concat(
      benches.map(
        (b) =>
          `<option value="${b.id}" ${Number(selected) === b.id ? "selected" : ""}>${esc(b.label || b.name)}</option>`
      )
    );
    return opts.join("");
  }
  function techOptions(selected) {
    const techs = (state.piso.techs || []).filter((t) => t.active);
    return [`<option value="">Sin técnico</option>`]
      .concat(
        techs.map(
          (t) =>
            `<option value="${t.id}" ${Number(selected) === t.id ? "selected" : ""}>${esc(t.name)}</option>`
        )
      )
      .join("");
  }
  function pickIds(root) {
    const b = root.querySelector("[name=bench_id]");
    const t = root.querySelector("[name=tech_id]");
    return {
      bench_id: b && b.value ? Number(b.value) : null,
      tech_id: t && t.value ? Number(t.value) : null,
    };
  }

  function openSheet(title, html, wide) {
    $("#sheetTitle").textContent = title;
    $("#sheetBody").innerHTML = html;
    $("#sheet").hidden = false;
    $(".sheet-card")?.classList.toggle("wide", !!wide);
    const first = $("#sheetBody input, #sheetBody textarea, #sheetBody button.key");
    if (first) first.focus();
  }
  function closeSheet() {
    $("#sheet").hidden = true;
    $("#sheetBody").innerHTML = "";
  }

  function openJob(id) {
    const all = COLS.flatMap(([k]) => state.taller[k] || []);
    const j = all.find((x) => x.id === id);
    if (!j) return;
    const next = NEXT[j.status];
    const nextLbl = next ? COLS.find((c) => c[0] === next)[1] : "";
    openSheet(
      `Orden ${j.id}`,
      `${j.photo ? `<img class="tapa-shot" src="/fotos/${esc(j.photo)}" alt="Tapa del equipo">` : ""}
      <div class="meta-block">
        <div><strong>${esc(j.device)}</strong>${j.marca ? " · " + esc(j.marca) : ""}${j.color ? " · " + esc(j.color) : ""}</div>
        <div>${esc(j.customer_name)}${j.customer_phone ? " · " + esc(j.customer_phone) : ""}</div>
        <div>${esc(j.issue)}</div>
        ${j.imei ? `<div class="job-imei">IMEI ${esc(imeiGroups(j.imei))}</div>` : ""}
        ${j.serial ? `<div>Serie ${esc(j.serial)}</div>` : ""}
        <div>${j.price_clp ? "Presupuesto " + clp(j.price_clp) : "Sin precio de cobro"}</div>
      </div>
      <div class="sheet-actions" style="margin-bottom:12px">
        <button type="button" class="key ghost" id="jobConstancia">Ver constancia</button>
      </div>
      ${
        j.status !== "entregado"
          ? `<div class="duo">
        <label class="field"><span>Mesa</span><select name="bench_id" id="jobBench">${benchOptions(j.bench_id)}</select></label>
        <label class="field"><span>Técnico</span><select name="tech_id" id="jobTech">${techOptions(j.tech_id)}</select></label>
      </div>`
          : jobWhere(j)
      }
      <div class="sheet-actions">
        ${
          j.status !== "entregado"
            ? `<button type="button" class="key ghost" id="jobAsignar">Asignar</button>`
            : ""
        }
        ${
          j.status === "listo" && j.price_clp > 0
            ? `<button type="button" class="key copper" id="jobPay">Cobrar y entregar</button>`
            : ""
        }
        ${
          next
            ? `<button type="button" class="key primary" id="jobNext" data-to="${next}">Pasar a ${nextLbl.toLowerCase()}</button>`
            : `<button type="button" class="key ghost" id="sheetDone">Cerrar</button>`
        }
      </div>`
    );
    const sendMove = async (status) => {
      const pick = pickIds($("#sheetBody"));
      await api(`/api/taller/${j.id}/mover`, {
        method: "POST",
        body: JSON.stringify({ status, ...pick }),
      });
    };
    $("#jobNext")?.addEventListener("click", async (ev) => {
      try {
        await sendMove(ev.currentTarget.dataset.to);
        closeSheet();
        await loadTaller();
        toast("orden movida");
      } catch (e) {
        toast(e.message);
      }
    });
    $("#jobAsignar")?.addEventListener("click", async () => {
      try {
        await sendMove(j.status);
        closeSheet();
        await loadTaller();
        toast("mesa asignada");
      } catch (e) {
        toast(e.message);
      }
    });
    $("#jobPay")?.addEventListener("click", () => payOrder(j));
    $("#sheetDone")?.addEventListener("click", closeSheet);
    $("#jobConstancia")?.addEventListener("click", () => showConstancia(j));
  }

  function showConstancia(j) {
    const loc = (state.local && state.local.name) || "Este local";
    openSheet(
      "Constancia de ingreso",
      `<article class="constancia">
        <p class="constancia-k">No es boleta ni factura. El equipo queda en ${esc(loc)} hasta que lo retires.</p>
        <h3>Ingreso #${j.id}</h3>
        ${j.photo ? `<img class="tapa-shot" src="/fotos/${esc(j.photo)}" alt="">` : ""}
        <dl>
          <div><dt>Quién deja</dt><dd>${esc(j.customer_name)}${j.customer_phone ? " · " + esc(j.customer_phone) : ""}</dd></div>
          <div><dt>Equipo</dt><dd>${esc(j.device)}${j.marca ? " · " + esc(j.marca) : ""}${j.color ? " · " + esc(j.color) : ""}</dd></div>
          <div><dt>IMEI</dt><dd>${j.imei ? esc(imeiGroups(j.imei)) : "sin IMEI"}</dd></div>
          <div><dt>Serie</dt><dd>${esc(j.serial || "—")}</dd></div>
          <div><dt>Qué le pasa</dt><dd>${esc(j.issue)}</dd></div>
          <div><dt>Entró</dt><dd>${esc((j.opened_at || "").slice(0, 16).replace("T", " "))}</dd></div>
        </dl>
      </article>
      <div class="sheet-actions">
        <button type="button" class="key primary" id="constanciaOk">Listo</button>
      </div>`
    );
    $("#constanciaOk")?.addEventListener("click", closeSheet);
  }

  function openBench(id) {
    const b = (state.piso.benches || []).find((x) => x.id === id);
    if (!b) return;
    const jobs = b.jobs || [];
    const cola = state.piso.cola || [];
    openSheet(
      b.label || b.name || "Mesa",
      `<p class="sub" style="margin-bottom:12px">Semáforo ${LIGHT_LBL[b.light] || b.light}.</p>
      ${
        jobs.length
          ? jobs
              .map(
                (j) => `<button type="button" class="job" data-oid="${j.id}">
            <div class="job-dev">${esc(j.device)}</div>
            <div class="job-who">${esc(j.customer_name)}${j.tech_name ? " · " + esc(j.tech_name) : ""}</div>
          </button>`
              )
              .join("")
          : `<p class="col-empty">Nadie en esta mesa.</p>`
      }
      ${
        cola.length
          ? `<label class="field" style="margin-top:12px"><span>Pasar de la cola</span>
            <select id="colaPick">${cola.map((j) => `<option value="${j.id}">${esc(j.device)} · ${esc(j.customer_name)}</option>`).join("")}</select>
          </label>
          <div class="sheet-actions"><button type="button" class="key primary" id="colaGo">Poner en esta mesa</button></div>`
          : ""
      }`
    );
    $$("#sheetBody .job").forEach((btn) => {
      btn.addEventListener("click", () => openJob(Number(btn.dataset.oid)));
    });
    $("#colaGo")?.addEventListener("click", async () => {
      const oid = Number($("#colaPick").value);
      try {
        await api(`/api/taller/${oid}/mover`, {
          method: "POST",
          body: JSON.stringify({ status: "en_mesa", bench_id: b.id }),
        });
        closeSheet();
        await loadTaller();
        toast("en la mesa");
      } catch (e) {
        toast(e.message);
      }
    });
  }

  function formPiso() {
    const n = state.piso.n_benches || 4;
    const techs = state.piso.techs || [];
    openSheet(
      "Mesas y técnicos",
      `<p class="sub" style="margin-bottom:12px">Cuántas mesas hay en el taller y quién las atiende. El semáforo sale solo.</p>
      <div class="stepper">
        <span>Mesas</span>
        <button type="button" class="key ghost square" id="mesasMenos">−</button>
        <b id="mesasN">${n}</b>
        <button type="button" class="key ghost square" id="mesasMas">+</button>
      </div>
      <div class="tech-list" id="techList">
        ${
          techs
            .map(
              (t) => `<div class="tech-row" data-tid="${t.id}">
            <input value="${esc(t.name)}" ${t.active ? "" : "disabled"}>
            <button type="button" class="linkish" data-act="${t.active ? "off" : "on"}">${t.active ? "Fuera" : "Volver"}</button>
          </div>`
            )
            .join("") || `<p class="col-empty">Todavía no hay técnicos.</p>`
        }
      </div>
      <div class="duo">
        <label class="field"><span>Otro técnico</span><input id="techName" placeholder="Nombre"></label>
        <button type="button" class="key primary" id="techAdd">Sumar</button>
      </div>`
    );
    let benches = n;
    const paintN = () => {
      $("#mesasN").textContent = String(benches);
    };
    const saveBenches = async (v) => {
      benches = Math.min(16, Math.max(1, v));
      paintN();
      try {
        state.piso = await api("/api/taller/piso", {
          method: "POST",
          body: JSON.stringify({ benches }),
        });
        benches = state.piso.n_benches;
        paintN();
        renderTaller();
      } catch (e) {
        toast(e.message);
      }
    };
    $("#mesasMenos").addEventListener("click", () => saveBenches(benches - 1));
    $("#mesasMas").addEventListener("click", () => saveBenches(benches + 1));
    $$("#techList .tech-row").forEach((row) => {
      const tid = Number(row.dataset.tid);
      const input = $("input", row);
      const btn = $("button", row);
      input.addEventListener("change", async () => {
        try {
          await api(`/api/taller/tecnicos/${tid}`, {
            method: "POST",
            body: JSON.stringify({ name: input.value }),
          });
          await loadTaller();
        } catch (e) {
          toast(e.message);
        }
      });
      btn.addEventListener("click", async () => {
        try {
          await api(`/api/taller/tecnicos/${tid}`, {
            method: "POST",
            body: JSON.stringify({ name: input.value, active: btn.dataset.act === "on" }),
          });
          await loadTaller();
          formPiso();
        } catch (e) {
          toast(e.message);
        }
      });
    });
    $("#techAdd").addEventListener("click", async () => {
      try {
        await api("/api/taller/tecnicos", {
          method: "POST",
          body: JSON.stringify({ name: $("#techName").value }),
        });
        await loadTaller();
        formPiso();
        toast("técnico en el taller");
      } catch (e) {
        toast(e.message);
      }
    });
  }

  function payOrder(j) {
    openSheet(
      "Cobrar reparación",
      `<p class="sub" style="margin-bottom:12px">${esc(j.device)} · ${clp(j.price_clp)}</p>
      <div class="pays" id="ordPays">
        <button type="button" class="pay on" data-pay="efectivo">Efectivo</button>
        <button type="button" class="pay" data-pay="debito">Débito</button>
        <button type="button" class="pay" data-pay="credito">Crédito</button>
        <button type="button" class="pay" data-pay="transferencia">Transfer.</button>
      </div>
      <div class="sheet-actions">
        <button type="button" class="key copper" id="ordGo">Cobrar y entregar</button>
      </div>`
    );
    let method = "efectivo";
    $$("#ordPays .pay").forEach((b) => {
      b.addEventListener("click", () => {
        $$("#ordPays .pay").forEach((x) => x.classList.remove("on"));
        b.classList.add("on");
        method = b.dataset.pay;
      });
    });
    $("#ordGo").addEventListener("click", async () => {
      try {
        const sale = await api(`/api/taller/${j.id}/cobrar`, {
          method: "POST",
          body: JSON.stringify({ pay_method: method }),
        });
        closeSheet();
        await Promise.all([loadTaller(), loadCatalog(), loadCifras()]);
        showTicket(sale);
      } catch (e) {
        toast(e.message);
      }
    });
  }

  function formNuevaOrden() {
    showView("taller");
    $("#recibir")?.scrollIntoView({ block: "start" });
    $("#tapaFile")?.click();
  }

  function abrirFicha(data, leyendo) {
    state.tapa = data;
    const prev = $("#tapaPrev");
    const form = $("#fConstancia");
    if (prev) {
      prev.hidden = false;
      const aviso = leyendo
        ? `<p class="tapa-aviso">Leyendo la foto. Puedes cobrar o seguir: la ficha se llena sola.</p>`
        : (data.avisos || []).map((a) => `<p class="tapa-aviso">${esc(a)}</p>`).join("");
      prev.innerHTML =
        (data.photo ? `<img class="tapa-shot" src="/fotos/${esc(data.photo)}" alt="Foto del equipo">` : "") +
        aviso;
    }
    if (form) {
      form.hidden = false;
      if (data.photo) form.photo.value = data.photo;
      if (data.modelo && !form.device.value) form.device.value = data.modelo;
      if (data.marca && !form.marca.value) form.marca.value = data.marca;
      if (data.imei && !String(form.imei.value || "").replace(/\D/g, "")) form.imei.value = imeiGroups(data.imei);
      if (data.serial && !form.serial.value) form.serial.value = data.serial;
      if (data.color && !form.color.value) form.color.value = data.color;
      if (data.customer_name && !form.customer_name.value) form.customer_name.value = data.customer_name;
      if (data.customer_phone && !form.customer_phone.value) form.customer_phone.value = data.customer_phone;
      form.querySelector("[name=bench_id]").innerHTML = benchOptions(form.bench_id.value);
      form.querySelector("[name=tech_id]").innerHTML = techOptions(form.tech_id.value);
    }
  }

  function pararFoto() {
    if (state.fotoTimer) {
      clearInterval(state.fotoTimer);
      state.fotoTimer = 0;
    }
  }

  function aplicarLectura(data) {
    const leyendo = data.estado === "leyendo";
    abrirFicha(data, leyendo);
    if (leyendo) return;
    pararFoto();
    state.fotoId = "";
    if (data.estado === "fallo") {
      toast("No pude leer la foto. Complétala a mano.");
      return;
    }
    toast("Ficha lista. Revisa y anota la constancia.");
    (data.avisos || []).forEach((a) => toast(a));
    const form = $("#fConstancia");
    if (!form) return;
    if (!form.device.value) form.device.focus();
    else if (!form.customer_name.value) form.customer_name.focus();
    else if (!form.issue.value) form.issue.focus();
  }

  function seguirFoto(id) {
    pararFoto();
    state.fotoId = id;
    const tick = async () => {
      try {
        const d = await api(`/api/taller/foto/${id}`);
        if (d.estado === "leyendo") return;
        aplicarLectura(d);
      } catch (e) {
        pararFoto();
        toast(e.message || "no pude leer la foto");
      }
    };
    state.fotoTimer = setInterval(tick, 900);
    tick();
  }

  async function leerTapa(file) {
    if (!file) return;
    const fd = new FormData();
    fd.append("file", file, file.name || "foto.jpg");
    const res = await fetch("/api/taller/foto", { method: "POST", body: fd });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || "no pude leer la foto");
    abrirFicha(data, data.estado === "leyendo");
    toast("Leyendo la foto. Puedes cobrar o seguir.");
    const form = $("#fConstancia");
    if (form && !form.customer_name.value) form.customer_name.focus();
    if (data.estado === "leyendo" && data.id) seguirFoto(data.id);
    else aplicarLectura(data);
  }

  async function retomarFoto() {
    try {
      const d = await api("/api/taller/foto");
      if (!d || d.estado === "ninguna") return;
      if (d.estado === "leyendo" && d.id) {
        abrirFicha(d, true);
        seguirFoto(d.id);
      }
    } catch (_) {}
  }

  function bindConstancia() {
    const file = $("#tapaFile");
    const drop = $("#tapaDrop");
    const form = $("#fConstancia");
    file?.addEventListener("change", async () => {
      try {
        await leerTapa(file.files && file.files[0]);
      } catch (e) {
        toast(e.message);
      }
    });
    drop?.addEventListener("dragover", (ev) => {
      ev.preventDefault();
      drop.classList.add("on");
    });
    drop?.addEventListener("dragleave", () => drop.classList.remove("on"));
    drop?.addEventListener("drop", async (ev) => {
      ev.preventDefault();
      drop.classList.remove("on");
      const f = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0];
      try {
        await leerTapa(f);
      } catch (e) {
        toast(e.message);
      }
    });
    const imei = form && form.imei;
    imei?.addEventListener("input", () => {
      const d = imei.value.replace(/\D/g, "").slice(0, 15);
      imei.value = imeiGroups(d);
    });
    form?.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const fd = new FormData(form);
      const body = Object.fromEntries(fd.entries());
      body.imei = String(body.imei || "").replace(/\D/g, "");
      body.price_clp = Number(String(body.price_clp).replace(/\D/g, "") || 0);
      body.bench_id = body.bench_id ? Number(body.bench_id) : null;
      body.tech_id = body.tech_id ? Number(body.tech_id) : null;
      try {
        const orden = await api("/api/taller", { method: "POST", body: JSON.stringify(body) });
        form.reset();
        form.hidden = true;
        const prev = $("#tapaPrev");
        if (prev) {
          prev.hidden = true;
          prev.innerHTML = "";
        }
        pararFoto();
        state.tapa = null;
        state.fotoId = "";
        await loadTaller();
        showConstancia(orden);
        toast("constancia anotada");
      } catch (e) {
        toast(e.message);
      }
    });
  }

  function errDetail(data) {
    const d = data && data.detail;
    if (typeof d === "string") return d;
    if (Array.isArray(d) && d[0] && d[0].msg) return d[0].msg;
    return "";
  }

  async function leerLista(file, text, kind) {
    state.listaKind = kind === "factura" ? "factura" : "lista";
    const fd = new FormData();
    if (file) fd.append("file", file, file.name || "lista.csv");
    fd.append("text", text || "");
    const res = await fetch("/api/inventario/leer", { method: "POST", body: fd });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(errDetail(data) || (res.status === 404 ? "la caja no tiene la carga de listas. Reiníciala." : "no se pudo leer el archivo"));
    }
    if (state.listaKind === "factura") {
      state.factura = {
        proveedor: ($("#facProv") && $("#facProv").value.trim()) || data.proveedor || "",
        folio: ($("#facFolio") && $("#facFolio").value.trim()) || data.folio || "",
        fecha: ($("#facFecha") && $("#facFecha").value) || data.fecha || "",
      };
      if (data.proveedor && $("#facProv") && !$("#facProv").value) $("#facProv").value = data.proveedor;
      if (data.folio && $("#facFolio") && !$("#facFolio").value) $("#facFolio").value = data.folio;
      if (data.fecha && $("#facFecha") && !$("#facFecha").value) $("#facFecha").value = data.fecha;
    }
    paintLista(data);
    showView("inventario");
  }

  function paintLista(data) {
    const lines = (data.lines || []).map((l) => ({ ...l, on: true }));
    state.listaDraft = lines;
    const warn = (data.warnings || []).map((w) => `<p class="sub">${esc(w)}</p>`).join("");
    const box = $("#listaPrev");
    if (!box) return;
    if (!lines.length) {
      box.innerHTML = `${warn}<p class="col-empty">No saqué productos de esa lista.</p>
        <div class="sheet-actions"><button type="button" class="key ghost" id="listaCancel">Cerrar</button></div>`;
      $("#listaCancel")?.addEventListener("click", cancelLista);
      return;
    }
    const factura = state.listaKind === "factura";
    const fac = state.factura || {};
    const cabecera = factura
      ? `<div class="lista-bar">
        <p>${lines.length} líneas de la factura. El stock se suma. Revisa y acepta.</p>
        <div class="lista-bar-btns">
          <button type="button" class="linkish" id="listaAll">Todas</button>
          <button type="button" class="linkish" id="listaNone">Ninguna</button>
        </div>
      </div>
      <div class="duo">
        <label class="field"><span>Proveedor</span><input id="listaProv" maxlength="80" value="${esc(fac.proveedor || "")}"></label>
        <label class="field"><span>Número</span><input id="listaFolio" maxlength="40" value="${esc(fac.folio || "")}"></label>
      </div>
      <label class="field"><span>Fecha</span><input id="listaFecha" type="date" value="${esc(fac.fecha || "")}"></label>`
      : `<div class="lista-bar">
        <p>${lines.length} líneas leídas. Marca, tipo y genérico ya vienen completados. Marca las que entran.</p>
        <div class="lista-bar-btns">
          <button type="button" class="linkish" id="listaAll">Todas</button>
          <button type="button" class="linkish" id="listaNone">Ninguna</button>
        </div>
      </div>`;
    box.innerHTML = `${warn}
      ${cabecera}
      <div class="inv-table">
        <table>
          <thead><tr>
            <th></th><th>Producto</th><th>Marca</th><th>Tipo</th><th>Ref. proveedor</th>
            <th>Cant.</th><th>Costo</th><th>Precio</th><th></th>
          </tr></thead>
          <tbody>
            ${lines
              .map(
                (l, i) => `<tr data-i="${i}">
                  <td><input type="checkbox" data-on="${i}" ${l.on ? "checked" : ""}></td>
                  <td><input data-f="name" data-i="${i}" value="${esc(l.name)}"></td>
                  <td><input data-f="brand" data-i="${i}" value="${esc(l.brand || "")}"></td>
                  <td><select data-f="kind" data-i="${i}">
                    <option value="repuesto" ${l.kind === "repuesto" ? "selected" : ""}>Repuesto</option>
                    <option value="accesorio" ${l.kind === "accesorio" ? "selected" : ""}>Accesorio</option>
                    <option value="celular" ${l.kind === "celular" ? "selected" : ""}>Celular</option>
                  </select></td>
                  <td><input data-f="ref" data-i="${i}" value="${esc(l.ref || l.sku || "")}"></td>
                  <td><input data-f="qty" data-i="${i}" inputmode="numeric" value="${l.qty || 0}"></td>
                  <td><input data-f="cost_clp" data-i="${i}" inputmode="numeric" value="${l.cost_clp != null ? l.cost_clp : ""}"></td>
                  <td><input data-f="price_clp" data-i="${i}" inputmode="numeric" value="${l.price_clp != null ? l.price_clp : ""}"></td>
                  <td>${l.action === "nuevo" ? "nuevo" : "ya está"}</td>
                </tr>`
              )
              .join("")}
          </tbody>
        </table>
      </div>
      ${factura ? "" : '<label class="check"><input type="checkbox" id="listaReemplaza"> Reemplazar stock de los que ya están (si no, se suma)</label>'}
      <div class="sheet-actions">
        <button type="button" class="key ghost" id="listaCancel">Cancelar</button>
        <button type="button" class="key primary" id="listaGo">Aceptar seleccionados</button>
      </div>`;
    const draft = state.listaDraft;
    $$("#listaPrev [data-on]").forEach((el) => {
      el.addEventListener("change", () => {
        draft[Number(el.dataset.on)].on = el.checked;
      });
    });
    $$("#listaPrev [data-f]").forEach((el) => {
      const apply = () => {
        const i = Number(el.dataset.i);
        const f = el.dataset.f;
        if (f === "qty" || f === "cost_clp" || f === "price_clp") {
          draft[i][f] = el.value === "" ? null : digits(el.value);
        } else {
          draft[i][f] = el.value;
        }
      };
      el.addEventListener("input", apply);
      el.addEventListener("change", apply);
    });
    $("#listaAll").addEventListener("click", () => {
      draft.forEach((l) => (l.on = true));
      $$("#listaPrev [data-on]").forEach((el) => (el.checked = true));
    });
    $("#listaNone").addEventListener("click", () => {
      draft.forEach((l) => (l.on = false));
      $$("#listaPrev [data-on]").forEach((el) => (el.checked = false));
    });
    $("#listaCancel").addEventListener("click", cancelLista);
    $("#listaGo").addEventListener("click", async () => {
      const picked = draft.filter((l) => l.on);
      if (!picked.length) {
        toast("no marcaste ningún ítem");
        return;
      }
      try {
        const factura = state.listaKind === "factura";
        const out = await api("/api/inventario/cargar", {
          method: "POST",
          body: JSON.stringify({
            lines: picked,
            modo: factura ? "sumar" : ($("#listaReemplaza") && $("#listaReemplaza").checked ? "reemplazar" : "sumar"),
            origen: factura ? "factura" : "lista",
            proveedor: factura ? ($("#listaProv") && $("#listaProv").value.trim()) || "" : "",
            folio: factura ? ($("#listaFolio") && $("#listaFolio").value.trim()) || "" : "",
            fecha: factura ? ($("#listaFecha") && $("#listaFecha").value) || "" : "",
          }),
        });
        cancelLista();
        await loadCatalog();
        showView("inventario");
        const extra = (out.errores || []).length ? ` · ${out.errores.length} no entraron` : "";
        toast(`${out.nuevos} nuevos · ${out.suman} actualizados${extra}`);
      } catch (e) {
        toast(e.message);
      }
    });
  }

  function cancelLista() {
    state.listaDraft = [];
    state.listaKind = "lista";
    const box = $("#listaPrev");
    if (box) box.innerHTML = "";
    const invFile = $("#invFile");
    if (invFile) invFile.value = "";
    const facFile = $("#facFile");
    if (facFile) facFile.value = "";
  }

  function formFicha(p, extra) {
    const edit = !!p;
    const presetBar = (extra && extra.barcode) || p?.barcode || "";
    const cost = edit ? p.cost_clp || 0 : 0;
    const price = edit ? p.price_clp || 0 : 0;
    const m = edit ? marginPct(cost, price) : defaultMargin();
    openSheet(
      edit ? "Ficha del producto" : "Nuevo producto",
      `<form id="fProd">
        <label class="field"><span>Nombre</span><input name="name" required value="${esc(p?.name || "")}"></label>
        <div class="duo">
          <label class="field"><span>Marca</span><input name="brand" value="${esc(p?.brand || "")}"></label>
          <label class="field"><span>Tipo</span>
            <select name="kind">
              <option value="repuesto" ${p?.kind === "repuesto" ? "selected" : ""}>Repuesto</option>
              <option value="accesorio" ${p?.kind === "accesorio" ? "selected" : ""}>Accesorio</option>
              <option value="celular" ${p?.kind === "celular" ? "selected" : ""}>Celular</option>
            </select>
          </label>
        </div>
        ${
          edit
            ? `<label class="field"><span>Código A10</span><input name="sku" value="${esc(p.sku || "")}" readonly></label>`
            : `<p class="sub">Al guardar, A10 le asigna su código interno.</p>`
        }
        <div class="duo">
          <label class="field"><span>Ref. proveedor</span><input name="ref_code" value="${esc(p?.ref_code || "")}"></label>
          <label class="field"><span>Código de barras</span><input name="barcode" value="${esc(presetBar)}" inputmode="numeric"></label>
        </div>
        <label class="field"><span>Dónde está</span><input name="ubicacion" placeholder="Vitrina, cajón 2, bodega…" value="${esc(p?.ubicacion || "")}"></label>
        <div id="fMoves"></div>
        <div class="trio">
          <label class="field"><span>Costo</span><input name="cost_clp" id="fCost" inputmode="numeric" value="${cost || ""}"></label>
          <label class="field"><span>Margen %</span><input name="margen" id="fMargen" inputmode="decimal" value="${m == null ? "" : m}"></label>
          <label class="field"><span>Precio venta</span><input name="price_clp" id="fPrice" inputmode="numeric" required value="${price || ""}"></label>
        </div>
        <label class="field"><span>Stock</span><input name="stock" inputmode="numeric" value="${edit ? p.stock : 1}"></label>
        <label class="field"><span>Nota</span><textarea name="note">${esc(p?.note || "")}</textarea></label>
        ${
          edit
            ? `<fieldset class="m10-box ${p.market_on ? "on" : ""}">
          <legend>Market10</legend>
          <label class="check"><input type="checkbox" name="m10_on" ${p.market_on ? "checked" : ""}> Subir a la red de locales</label>
          <div class="duo">
            <label class="field"><span>Precio en la red</span><input name="m10_price" inputmode="numeric" value="${p.market_price_clp || p.price_clp}"></label>
            <label class="field"><span>Tiempo (min)</span><input name="m10_eta" inputmode="numeric" value="${p.market_eta_min || 30}"></label>
          </div>
          <label class="check"><input type="checkbox" name="m10_stock" ${p.market_show_stock ? "checked" : ""}> Mostrar stock al otro local</label>
          <label class="field"><span>Cómo lo dan</span>
            <select name="m10_fulfill">
              <option value="retiro" ${p.market_fulfill === "retiro" ? "selected" : ""}>Solo retiro</option>
              <option value="envio" ${p.market_fulfill === "envio" ? "selected" : ""}>Solo envío</option>
              <option value="ambos" ${p.market_fulfill === "ambos" ? "selected" : ""}>Retiro o envío</option>
            </select>
          </label>
        </fieldset>`
            : `<p class="sub">Cuando lo crees, en la ficha puedes subirlo a Market10.</p>`
        }
        <label class="shot-pick">
          <span class="shot-box" id="shotPrev">${
            p?.photo
              ? `<img src="/fotos/${esc(p.photo)}" alt="">`
              : `<span>Foto</span>`
          }</span>
          <input id="shotFile" type="file" accept="image/*" capture="environment">
        </label>
        <div class="sheet-actions">
          <button type="button" class="key ghost" id="fCancel">Cancelar</button>
          ${edit ? `<button type="button" class="key ghost" id="fHide">Quitar</button>` : ""}
          <button type="submit" class="key primary">${edit ? "Guardar" : "Crear"}</button>
        </div>
      </form>`,
      true
    );
    bindShotPreview("#shotFile", "#shotPrev");
    const costEl = $("#fCost");
    const marEl = $("#fMargen");
    const priceEl = $("#fPrice");
    let lock = "";
    costEl.addEventListener("input", () => {
      if (lock === "price") return;
      lock = "cost";
      const c = digits(costEl.value);
      const pct = parseFloat(String(marEl.value).replace(",", "."));
      if (c && Number.isFinite(pct)) priceEl.value = String(priceFromMargin(c, pct));
      lock = "";
    });
    marEl.addEventListener("input", () => {
      if (lock === "price") return;
      lock = "margen";
      const c = digits(costEl.value);
      const pct = parseFloat(String(marEl.value).replace(",", "."));
      if (c && Number.isFinite(pct)) priceEl.value = String(priceFromMargin(c, pct));
      lock = "";
    });
    priceEl.addEventListener("input", () => {
      if (lock) return;
      lock = "price";
      const m2 = marginPct(digits(costEl.value), digits(priceEl.value));
      marEl.value = m2 == null ? "" : String(m2);
      lock = "";
    });
    if (edit) {
      api(`/api/catalog/${p.id}/movimientos`)
        .then((rows) => {
          const box = $("#fMoves");
          if (!box) return;
          if (!rows.length) {
            box.innerHTML = `<p class="sub">Todavía no hay movimientos de este producto.</p>`;
            return;
          }
          const lbl = { alta: "Alta", lista: "Lista", ficha: "Ficha", venta: "Venta", conteo: "Recuento" };
          box.innerHTML = `<div class="moves"><h3>Movimientos</h3>${rows
            .map(
              (m) => `<div class="move">
                <span>${esc((m.ts || "").slice(0, 16).replace("T", " "))} · ${esc(lbl[m.reason] || m.reason)}${m.detail ? " · " + esc(m.detail) : ""}</span>
                <b>${m.qty > 0 ? "+" : ""}${m.qty} → ${m.stock_after}</b>
              </div>`
            )
            .join("")}</div>`;
        })
        .catch(() => {});
    }
    $("#fCancel").addEventListener("click", closeSheet);
    $("#fHide")?.addEventListener("click", async () => {
      if (!edit) return;
      try {
        await api(`/api/catalog/${p.id}/quitar`, { method: "POST", body: "{}" });
        closeSheet();
        await loadCatalog();
        toast("fuera del inventario");
      } catch (e) {
        toast(e.message);
      }
    });
    $("#fProd").addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const fd = new FormData(ev.target);
      const file = $("#shotFile").files[0];
      const body = {
        name: fd.get("name"),
        kind: fd.get("kind"),
        brand: fd.get("brand") || "",
        sku: fd.get("sku") || "",
        ref_code: fd.get("ref_code") || "",
        barcode: fd.get("barcode") || "",
        ubicacion: fd.get("ubicacion") || "",
        note: fd.get("note") || "",
        price_clp: digits(fd.get("price_clp")),
        cost_clp: digits(fd.get("cost_clp")),
        stock: digits(fd.get("stock")),
      };
      try {
        const saved = edit
          ? await api(`/api/catalog/${p.id}`, { method: "POST", body: JSON.stringify(body) })
          : await api("/api/catalog", { method: "POST", body: JSON.stringify(body) });
        if (file) await uploadFoto(saved.id, file);
        if (edit) {
          await publicarMarket(
            {
              ...saved,
              market_price_clp: digits(fd.get("m10_price")),
              market_eta_min: digits(fd.get("m10_eta")),
              market_fulfill: fd.get("m10_fulfill"),
              market_show_stock: fd.get("m10_stock") === "on",
            },
            fd.get("m10_on") === "on",
            true
          );
        }
        closeSheet();
        await loadCatalog();
        showView("inventario");
        toast(edit ? "ficha guardada" : "en el inventario");
      } catch (e) {
        toast(e.message);
      }
    });
  }

  function bindShotPreview(fileSel, boxSel) {
    const input = $(fileSel);
    const box = $(boxSel);
    input.addEventListener("change", () => {
      const file = input.files[0];
      if (!file) return;
      const url = URL.createObjectURL(file);
      box.innerHTML = `<img src="${url}" alt="">`;
    });
  }

  async function uploadFoto(id, file) {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch(`/api/catalog/${id}/foto`, { method: "POST", body: fd });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || "no se pudo guardar la foto");
    return data;
  }

  function formFoto(p) {
    openSheet(
      "Foto del producto",
      `<p class="sub" style="margin-bottom:12px">${esc(p.name)} · recuadro 1:1</p>
      <label class="shot-pick">
        <span class="shot-box" id="shotPrev">${
          p.photo
            ? `<img src="/fotos/${esc(p.photo)}" alt="">`
            : `<span>Tocar para cargar</span>`
        }</span>
        <input id="shotFile" type="file" accept="image/*" capture="environment">
      </label>
      <div class="sheet-actions">
        <button type="button" class="key primary" id="shotSave" disabled>Guardar foto</button>
      </div>`
    );
    bindShotPreview("#shotFile", "#shotPrev");
    const save = $("#shotSave");
    $("#shotFile").addEventListener("change", () => {
      save.disabled = !$("#shotFile").files[0];
    });
    save.addEventListener("click", async () => {
      const file = $("#shotFile").files[0];
      if (!file) return;
      try {
        await uploadFoto(p.id, file);
        closeSheet();
        await loadCatalog();
        toast("foto en el recuadro");
      } catch (e) {
        toast(e.message);
      }
    });
  }

  const PAIS_ID = { CL: "RUT", PE: "RUC", CO: "NIT", MX: "RFC", AR: "CUIT", VE: "RIF", EC: "RUC", BO: "NIT", PA: "RUC", BR: "CNPJ" };

  function showTicket(sale) {
    const loc = state.local || {};
    state.lastSaleId = sale && sale.id ? sale.id : 0;
    const logo = $("#ticketLogo");
    if (logo) {
      if (loc.logo) {
        logo.src = `/fotos/${loc.logo}?t=${Date.now()}`;
        logo.hidden = false;
      } else {
        logo.removeAttribute("src");
        logo.hidden = true;
      }
    }
    const kicker = $("#ticketKicker");
    if (kicker) kicker.textContent = loc.doc || "Venta";
    const shop = $("#ticketShop");
    if (shop) shop.textContent = loc.name || "";
    const headTxt = $("#ticketHeadTxt");
    if (headTxt) {
      const txt = loc.ticket_header || "";
      headTxt.hidden = !txt;
      headTxt.textContent = txt;
    }
    $("#ticketHead").textContent = `Nº ${sale.id}`;
    $("#ticketLines").innerHTML = (sale.items || [])
      .map(
        (i) =>
          `<li><span>${esc(i.name)}${i.qty > 1 ? " ×" + i.qty : ""}${
            i.imei ? `<small style="display:block;color:var(--mute);font-family:var(--mono)">${esc(imeiGroups(i.imei))}</small>` : ""
          }</span><b>${clp(i.price_clp * (i.qty || 1))}</b></li>`
      )
      .join("");
    $("#ticketPay").textContent = PAY_LBL[sale.pay_method] || sale.pay_method;
    $("#ticketSum").textContent = clp(sale.total_clp);
    const foot = $("#ticketFoot");
    const txt = (state.local && state.local.ticket_footer) || "";
    if (foot) {
      foot.hidden = !txt;
      foot.textContent = txt;
    }
    const aviso = $("#ticketAviso");
    if (aviso) aviso.textContent = loc.aviso || "Este PDF es un comprobante de prueba. No es documento tributario.";
    $("#ticket").hidden = false;
  }

  async function cobrar() {
    if (!state.cart.length) return;
    if (netState.piloto && netState.expired) {
      toast("conecta a internet un momento para seguir cobrando");
      return;
    }
    for (const l of state.cart) {
      if (l.imei_required && l.imei.replace(/\D/g, "").length !== 15) {
        toast("falta el IMEI de 15 dígitos");
        return;
      }
    }
    $("#btnCobrar").disabled = true;
    try {
      const sale = await api("/api/sales", {
        method: "POST",
        body: JSON.stringify({
          pay_method: state.pay,
          items: state.cart.map((l) => ({
            product_id: l.product_id,
            qty: l.qty,
            imei: l.imei,
          })),
        }),
      });
      state.cart = [];
      renderCart();
      await loadCatalog();
      await loadPulse();
      reportaVida("cobro", `${PAY_LBL[sale.pay_method] || sale.pay_method} ${clp(sale.total_clp)}`);
      showTicket(sale);
    } catch (e) {
      reportaVida("cobro", e.message || "no se pudo cobrar");
      toast(e.message);
    } finally {
      syncCobrar();
    }
  }

  async function loadCatalog() {
    state.catalog = await api("/api/catalog");
    renderGrid();
    renderStock();
    renderPulse();
  }
  async function loadTaller() {
    const data = await api("/api/taller");
    state.piso = data.piso || state.piso;
    state.taller = data;
    renderTaller();
  }
  async function loadCifras() {
    state.cifras = await api(`/api/cifras?dias=${state.cifrasDias}`);
    renderLocal();
  }
  async function loadLocal() {
    const loc = await api("/api/local");
    state.local = loc;
    $("#localName").textContent = loc.name;
    const code = $("#shopCode");
    if (code) code.textContent = loc.shop_code || "M10";
    applyLang();
    renderPulse();
  }

  function applyLang() {
    const lang = (state.local && state.local.idioma) || "es";
    if (window.A10applyI18n) window.A10applyI18n(lang);
  }

  function startTour(replay) {
    if (!window.A10Tour) return;
    window.A10Tour.start({
      showView,
      showCfg,
      markSeen: async () => {
        try {
          await api("/api/local", { method: "POST", body: JSON.stringify({ tutorial_visto: 1 }) });
          if (state.local) state.local.tutorial_visto = 1;
        } catch (_) {}
      },
    });
    if (replay) reportaVida("pantalla", "tutorial");
  }

  function pedirTutorial() {
    if (!Number(state.local && state.local.tutorial_visto)) startTour(false);
  }

  async function entrarCaja() {
    await Promise.all([
      loadLocal(),
      loadCatalog(),
      loadTaller(),
      loadMercado(),
      loadPulse(),
      loadCifras().catch(() => {}),
      loadPago().catch(() => {}),
    ]);
    retomarFoto();
    loadSistema();
    showView(puedeVer(state.view) ? state.view : "hoy");
    pedirTutorial();
  }
  async function loadMercado() {
    const q = state.mktQ.trim();
    const [feed, pedidos] = await Promise.all([
      api(`/api/mercado?q=${encodeURIComponent(q)}&fulfill=${encodeURIComponent(state.mktFf)}`),
      api("/api/mercado/pedidos"),
    ]);
    state.mercado = feed;
    state.pedidos = pedidos;
    const badge = $("#badgeRed");
    const n = (feed.pedidos_abiertos || 0) + (feed.chats_abiertos || 0);
    badge.hidden = n === 0;
    badge.textContent = String(n);
    renderMercado();
  }

  function kmLbl(km) {
    if (!km) return "esta caja";
    return km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1)} km`;
  }
  function minLbl(n) {
    if (n < 60) return `${n} min`;
    const h = Math.floor(n / 60);
    const m = n % 60;
    return m ? `${h} h ${m} min` : `${h} h`;
  }

  function renderMercado() {
    fillCentros();
    const asked = Boolean(state.mercado.asked);
    const items = state.mercado.items || [];
    const open = (state.pedidos || []).filter(
      (p) => p.status !== "recibida" && p.status !== "cancelada"
    );
    const pedidosHtml = open.length
      ? `<div class="listbox">
          <h3>Pedidos en curso</h3>
          ${open
            .map(
              (p) => `<button type="button" class="row" data-oid="${p.id}" style="width:100%;text-align:left">
                <div>${esc(p.name)}<small>${esc(p.shop)} · ${FF_LBL[p.fulfill] || p.fulfill}${p.backup ? " · si no es, se devuelve" : ""}</small></div>
                <b>${clp(p.price_clp * p.qty)}</b>
              </button>`
            )
            .join("")}
        </div>`
      : "";
    let body;
    if (!asked) {
      body = `<div class="mkt-empty"><b>Escribe la pieza</b>No hay vitrina. Si nadie la publicó, aquí no aparece nada.</div>`;
    } else if (!items.length) {
      body = `<div class="mkt-empty"><b>Nadie la tiene</b>Ningún local publicó “${esc(state.mktQ.trim())}”.</div>`;
    } else {
      body = items
        .map(
          (it) => `<article class="mkt-row ${it.mine ? "mine" : ""}">
              <div>
                <div class="mkt-name">${esc(it.name)}</div>
                <div class="mkt-meta">${esc(it.shop)} · ${kmLbl(it.km)} · ${FF_LBL[it.fulfill] || it.fulfill}${it.show_stock && it.stock != null ? " · " + it.stock + " u." : ""}</div>
              </div>
              <div>
                <div class="mkt-price">${clp(it.price_clp)}</div>
                <div class="mkt-eta">${
                  it.fulfill === "envio"
                    ? "envío " + minLbl(it.eta_min)
                    : "retiro " + minLbl(it.walk_min || it.eta_min)
                }</div>
              </div>
              <div class="mkt-acts">
                ${
                  it.mine
                    ? `<button type="button" class="key ghost" data-pub="${it.product_id}">Editar publicación</button>`
                    : `<button type="button" class="key primary" data-chat="${esc(it.key)}">Escribir</button>
                       <button type="button" class="key ghost" data-ask="${esc(it.key)}">Pedir</button>`
                }
              </div>
            </article>`
        )
        .join("");
    }
    $("#mktList").innerHTML = pedidosHtml + body;
    $$("#mktList .row").forEach((btn) => {
      btn.addEventListener("click", () => openPedido(Number(btn.dataset.oid)));
    });
    $$("#mktList [data-chat]").forEach((btn) => {
      btn.addEventListener("click", () => openChat(btn.dataset.chat));
    });
    $$("#mktList [data-ask]").forEach((btn) => {
      btn.addEventListener("click", () => openListing(btn.dataset.ask));
    });
    $$("#mktList [data-pub]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const p = state.catalog.find((x) => x.id === Number(btn.dataset.pub));
        if (p) formPublicar(p);
      });
    });
  }

  function paintChat(box, chat) {
    const msgs = chat.messages || [];
    box.innerHTML = msgs.length
      ? msgs
          .map(
            (m) =>
              `<div class="bubble ${m.mine ? "mine" : "theirs"}">${esc(m.text)}</div>`
          )
          .join("")
      : `<p class="col-empty">Escribile a ${esc(chat.shop)}.</p>`;
    box.scrollTop = box.scrollHeight;
  }

  async function openChat(key) {
    let chat;
    try {
      chat = await api(`/api/mercado/chat?key=${encodeURIComponent(key)}`);
    } catch (e) {
      toast(e.message);
      return;
    }
    openSheet(
      chat.name,
      `<div class="meta-block">
        <div><strong>${esc(chat.shop)}</strong> · ${kmLbl(chat.km)}</div>
        <div>${esc(chat.address || "")}</div>
        <div>${clp(chat.price_clp)} · A10 no se queda con nada</div>
      </div>
      <div class="chat-log" id="chatLog"></div>
      <form class="chat-send" id="fChat">
        <input name="text" required maxlength="400" placeholder="Escribe al local" autocomplete="off">
        <button type="submit" class="key primary">Enviar</button>
      </form>
      <div class="sheet-actions" style="margin-top:10px">
        <button type="button" class="key ghost" id="chatAsk">Pedir esta pieza</button>
      </div>`
    );
    paintChat($("#chatLog"), chat);
    $("#fChat").addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const input = ev.target.querySelector("input");
      const text = input.value.trim();
      if (!text) return;
      try {
        const next = await api("/api/mercado/chat", {
          method: "POST",
          body: JSON.stringify({ key, text }),
        });
        input.value = "";
        paintChat($("#chatLog"), next);
        await loadMercado();
      } catch (e) {
        toast(e.message);
      }
    });
    $("#chatAsk").addEventListener("click", () => openListing(key));
  }

  function openListing(key) {
    const it = (state.mercado.items || []).find((x) => x.key === key);
    if (!it) return;
    if (it.mine) {
      const p = state.catalog.find((x) => x.id === it.product_id);
      if (p) formPublicar(p);
      return;
    }
    const canRetiro = it.fulfill === "retiro" || it.fulfill === "ambos";
    const canEnvio = it.fulfill === "envio" || it.fulfill === "ambos";
    openSheet(
      it.name,
      `<div class="meta-block">
        <div><strong>${esc(it.shop)}</strong> · ${kmLbl(it.km)}</div>
        <div>${esc(it.address || "")}</div>
        <div>Precio de red ${clp(it.price_clp)} · A10 no se queda con nada</div>
        <div>${
          it.show_stock && it.stock != null ? it.stock + " publicadas" : "Stock no visible"
        }</div>
      </div>
      <form id="fAsk">
        <div class="duo">
          <label class="field"><span>Cantidad</span><input name="qty" inputmode="numeric" value="1"></label>
          <label class="field"><span>Cómo</span>
            <select name="fulfill">
              ${canRetiro ? `<option value="retiro">Retiro · ${minLbl(it.walk_min || it.eta_min)}</option>` : ""}
              ${canEnvio ? `<option value="envio">Que lo envíen · ${minLbl(it.eta_min)}</option>` : ""}
            </select>
          </label>
        </div>
        <label class="check"><input type="checkbox" name="backup"> Si no es, se devuelve</label>
        <div class="sheet-actions">
          <button type="submit" class="key primary">Pedir a ${esc(it.shop)}</button>
        </div>
      </form>`
    );
    $("#fAsk").addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const fd = new FormData(ev.target);
      try {
        await api("/api/mercado/pedir", {
          method: "POST",
          body: JSON.stringify({
            key: it.key,
            qty: Number(String(fd.get("qty")).replace(/\D/g, "") || 1),
            fulfill: fd.get("fulfill"),
            backup: fd.get("backup") === "on",
          }),
        });
        closeSheet();
        await loadMercado();
        toast("pedido anotado");
      } catch (e) {
        toast(e.message);
      }
    });
  }

  function openPedido(id) {
    const p = state.pedidos.find((x) => x.id === id);
    if (!p) return;
    let next = RED_NEXT[p.status];
    if (p.status === "aceptada") {
      next = p.fulfill === "envio" ? ["en_camino", "Salió"] : ["lista", "Lista para retiro"];
    }
    openSheet(
      `Pedido ${p.id}`,
      `<div class="meta-block">
        <div><strong>${esc(p.name)}</strong> ×${p.qty}</div>
        <div>${esc(p.shop)} · ${FF_LBL[p.fulfill] || p.fulfill}</div>
        <div>${clp(p.price_clp * p.qty)} · ${esc(p.status)}${p.backup ? " · si no es, se devuelve" : ""}</div>
      </div>
      <div class="sheet-actions">
        ${next ? `<button type="button" class="key primary" id="pedNext" data-to="${next[0]}">${next[1]}</button>` : ""}
        ${
          p.status !== "recibida" && p.status !== "cancelada"
            ? `<button type="button" class="key ghost" id="pedCancel">Cancelar</button>`
            : ""
        }
      </div>`
    );
    $("#pedNext")?.addEventListener("click", async (ev) => {
      try {
        await api(`/api/mercado/pedidos/${p.id}/mover`, {
          method: "POST",
          body: JSON.stringify({ status: ev.currentTarget.dataset.to }),
        });
        closeSheet();
        await loadMercado();
      } catch (e) {
        toast(e.message);
      }
    });
    $("#pedCancel")?.addEventListener("click", async () => {
      try {
        await api(`/api/mercado/pedidos/${p.id}/mover`, {
          method: "POST",
          body: JSON.stringify({ status: "cancelada" }),
        });
        closeSheet();
        await loadMercado();
      } catch (e) {
        toast(e.message);
      }
    });
  }

  async function publicarMarket(p, on, quiet) {
    await api(`/api/catalog/${p.id}/mercado`, {
      method: "POST",
      body: JSON.stringify({
        on: !!on,
        price_clp: Number(p.market_price_clp || p.price_clp || 0),
        show_stock: !!p.market_show_stock,
        fulfill: p.market_fulfill || "retiro",
        eta_min: Number(p.market_eta_min || 30),
      }),
    });
    await Promise.all([loadCatalog(), loadMercado()]);
    if (!quiet) toast(on ? "en Market10" : "fuera de Market10");
  }

  function formPublicar(p) {
    openSheet(
      "En la red",
      `<form id="fPub">
        <p class="sub" style="margin-bottom:12px">${esc(p.name)} · mostrador ${clp(p.price_clp)}</p>
        <label class="check"><input type="checkbox" name="on" ${p.market_on ? "checked" : ""}> Disponible para otros locales</label>
        <label class="field"><span>Precio para la red</span><input name="price_clp" inputmode="numeric" value="${p.market_price_clp || p.price_clp}"></label>
        <label class="check"><input type="checkbox" name="show_stock" ${p.market_show_stock ? "checked" : ""}> Mostrar stock</label>
        <div class="duo">
          <label class="field"><span>Cómo lo dan</span>
            <select name="fulfill">
              <option value="retiro" ${p.market_fulfill === "retiro" ? "selected" : ""}>Solo retiro</option>
              <option value="envio" ${p.market_fulfill === "envio" ? "selected" : ""}>Solo envío</option>
              <option value="ambos" ${p.market_fulfill === "ambos" ? "selected" : ""}>Retiro o envío</option>
            </select>
          </label>
          <label class="field"><span>Tiempo (min)</span><input name="eta_min" inputmode="numeric" value="${p.market_eta_min || 30}"></label>
        </div>
        <div class="sheet-actions">
          <button type="submit" class="key primary">Guardar</button>
        </div>
      </form>`
    );
    $("#fPub").addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const fd = new FormData(ev.target);
      try {
        await api(`/api/catalog/${p.id}/mercado`, {
          method: "POST",
          body: JSON.stringify({
            on: fd.get("on") === "on",
            price_clp: Number(String(fd.get("price_clp")).replace(/\D/g, "") || 0),
            show_stock: fd.get("show_stock") === "on",
            fulfill: fd.get("fulfill"),
            eta_min: Number(String(fd.get("eta_min")).replace(/\D/g, "") || 30),
          }),
        });
        closeSheet();
        await Promise.all([loadCatalog(), loadMercado()]);
        toast(fd.get("on") === "on" ? "en la red" : "fuera de la red");
      } catch (e) {
        toast(e.message);
      }
    });
  }

  function showCfg(name) {
    const ok = $$(".cfg-pane").some((p) => p.dataset.cfg === name);
    if (!ok) name = "tienda";
    state.cfg = name;
    $$(".cfg-tab").forEach((b) => {
      const on = b.dataset.cfg === name;
      b.classList.toggle("on", on);
      b.setAttribute("aria-selected", on ? "true" : "false");
    });
    $$(".cfg-pane").forEach((p) => p.classList.toggle("on", p.dataset.cfg === name));
    if (name === "impresora") loadImpresoras();
    if (name === "telefono") loadTelefono();
    if (name === "gente") loadUsuarios();
    if (name === "sistema") loadSistema();
  }

  function formLocal() {
    if (!puedeVer("ajustes")) {
      toast("eso lo ve el dueño");
      return;
    }
    showView("ajustes");
  }

  function fillAjustes() {
    const loc = state.local || {};
    const form = $("#fAjustes");
    if (!form) return;
    const set = (name, value) => {
      const el = form.elements[name];
      if (el) el.value = value == null ? "" : value;
    };
    set("name", loc.name || "");
    set("phone", loc.phone || "");
    set("email", loc.email || "");
    set("address", loc.address || "");
    set("city", loc.city || "");
    set("comuna", loc.comuna || "");
    set("pais", loc.pais || "CL");
    set("idioma", loc.idioma || "es");
    set("tax_id", loc.tax_id || "");
    const taxLbl = $("#taxLbl");
    if (taxLbl) taxLbl.textContent = loc.id_fiscal || PAIS_ID[loc.pais] || "RUT";
    set("ticket_header", loc.ticket_header || "");
    set("ticket_footer", loc.ticket_footer || "");
    set("printer_name", loc.printer_name || "");
    set("printer_paper", loc.printer_paper || "80");
    set("printer_copies", String(loc.printer_copies || 1));
    const cut = form.elements.printer_cut;
    if (cut) cut.checked = loc.printer_cut === undefined ? true : !!Number(loc.printer_cut);
    set("margin_pct", loc.margin_pct ?? 100);
    set("stock_alert", loc.stock_alert ?? 2);
    set("whatsapp", loc.whatsapp || "");
    set("instagram", loc.instagram || "");
    set("facebook", loc.facebook || "");
    set("website", loc.website || "");
    set("lat", loc.lat ?? "");
    set("lng", loc.lng ?? "");
    const code = $("#ajustesShop");
    if (code) code.textContent = loc.shop_code || "—";
    paintLogo();
    paintPago();
  }

  function paintPago() {
    const p = pagoState || {};
    const hint = $("#pagoHint");
    const hasta = $("#pagoHasta");
    const input = $("#pagoUrl");
    const pagar = $("#btnPagarMes");
    if (input && !input.dataset.dirty) input.value = p.url || "";
    if (hasta) {
      if (p.hasta) {
        const d = new Date(p.hasta);
        hasta.textContent = Number.isNaN(d.getTime())
          ? p.hasta
          : d.toLocaleDateString("es-CL") + (p.vencido ? " · vencido" : "");
      } else {
        hasta.textContent = "sin fecha";
      }
    }
    if (hint) {
      if (!p.url) hint.textContent = "Falta el link de Banco de Chile. Pégalo y guarda.";
      else if (p.vencido) hint.textContent = "El mes se venció. Paga y después marca el mes.";
      else if (p.quedan_d != null) hint.textContent = `Quedan ${p.quedan_d} día${p.quedan_d === 1 ? "" : "s"} de este mes.`;
      else hint.textContent = "El cobro sigue. Este pago es la suscripción.";
    }
    if (pagar) {
      if (p.url) {
        pagar.href = p.url;
        pagar.removeAttribute("aria-disabled");
      } else {
        pagar.href = "#";
        pagar.setAttribute("aria-disabled", "true");
      }
    }
  }

  async function loadPago() {
    try {
      pagoState = await api("/api/pago");
    } catch {
      pagoState = pagoState || {};
    }
    paintPago();
    if (state.view === "hoy") renderHoy();
  }

  function paintImpresoras(snap) {
    const pick = $("#printerPick");
    const port = $("#printerPort");
    const list = $("#printerList");
    const rows = (snap && snap.impresoras) || [];
    state.impresoras = rows;
    const usada = (snap && snap.usada) || (state.local && state.local.printer_name) || "";
    if (pick) {
      const opts = [`<option value="">Ninguna · no imprimir</option>`].concat(
        rows.map((p) => {
          const sel = p.name === usada ? " selected" : "";
          const extra = p.port ? ` · ${esc(p.port)}` : "";
          return `<option value="${esc(p.name)}"${sel}>${esc(p.name)}${extra}</option>`;
        })
      );
      pick.innerHTML = opts.join("");
      if (usada) pick.value = usada;
    }
    const actual = rows.find((p) => p.name === (pick && pick.value)) || rows.find((p) => p.usada);
    if (port) {
      if (actual) {
        port.textContent = `Puerto ${actual.port || "—"} · ${actual.estado || "lista"}`;
      } else if ((snap && snap.puertos || []).length) {
        port.textContent = `${snap.puertos.length} puerto(s) vistos. Instala la impresora en Windows y búscalo.`;
      } else if (rows.length && rows.every((p) => /pdf|onenote|fax|xps/i.test(p.name || "") || /portprompt|nul/i.test(p.port || ""))) {
        port.textContent = "Windows muestra PDF u OneNote. Enchufa la impresora de tickets, instálala en Windows y toca buscar.";
      } else {
        port.textContent = rows.length ? "Elige la impresora del ticket." : "No hay impresora conectada.";
      }
    }
    if (list) {
      const extra = snap && snap.puertos ? snap.puertos : [];
      list.innerHTML = rows.length
        ? rows
            .map(
              (p) =>
                `<li class="${p.usada ? "on" : ""}"><span>${esc(p.name)}<small> ${esc(p.port || "sin puerto")} · ${esc(p.estado)}</small></span><b>${p.predeterminada ? "esta PC" : ""}</b></li>`
            )
            .join("")
        : extra.length
          ? extra
              .map((p) => `<li><span>${esc(p.name)}<small> ${esc(p.port || "")}</small></span></li>`)
              .join("")
          : `<li><span>Enchufa la impresora de tickets y toca buscar.</span></li>`;
    }
  }

  async function loadImpresoras(fresco) {
    try {
      const snap = await api(`/api/impresoras${fresco ? "?fresco=1" : ""}`);
      paintImpresoras(snap);
      if (snap.usada && state.local) state.local.printer_name = snap.usada;
    } catch (e) {
      const port = $("#printerPort");
      if (port) port.textContent = e.message;
    }
  }

  async function loadTelefono() {
    const urlEl = $("#fonoUrl");
    const hint = $("#fonoHint");
    const img = $("#fonoQr");
    try {
      const t = await api("/api/telefono");
      if (urlEl) urlEl.textContent = t.url || "—";
      if (img && t.url) {
        img.src = `/api/telefono/qr?t=${Date.now()}`;
        img.hidden = false;
        img.onerror = () => {
          img.hidden = true;
        };
      }
      if (hint) {
        hint.textContent = t.lan
          ? "Misma wifi. Si no entra, permite A10 en el firewall de Windows."
          : "Esta caja no ve la wifi. Enchufa red o revisa el cable.";
      }
    } catch (e) {
      if (urlEl) urlEl.textContent = e.message;
    }
  }

  async function loadUsuarios() {
    const box = $("#usersList");
    if (!box) return;
    try {
      const rows = await api("/api/usuarios");
      box.innerHTML = rows.length
        ? rows
            .map((u) => {
              const yo = state.yo && Number(state.yo.id) === Number(u.id);
              return `<li class="${u.active ? "on" : ""}"><span>${esc(u.name)}<small> ${esc(ROLE_LBL[u.role] || u.role)}</small></span>${
                yo || !u.active
                  ? ""
                  : `<button type="button" class="key ghost" data-user-del="${u.id}">Sacar</button>`
              }</li>`;
            })
            .join("")
        : `<li><span>Todavía no hay claves. Entra quien está en este PC.</span></li>`;
    } catch (e) {
      box.innerHTML = `<li><span>${esc(e.message)}</span></li>`;
    }
  }

  function paintLogo() {
    const loc = state.local || {};
    const img = $("#logoPrev");
    const hint = $("#logoHint");
    const quitar = $("#btnLogoQuitar");
    if (img && loc.logo) {
      img.src = `/fotos/${loc.logo}?t=${Date.now()}`;
      img.hidden = false;
      if (hint) hint.hidden = true;
      if (quitar) quitar.hidden = false;
    } else {
      if (img) img.hidden = true;
      if (hint) hint.hidden = false;
      if (quitar) quitar.hidden = true;
    }
  }

  async function saveAjustes(ev) {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    const lat = parseFloat(fd.get("lat"));
    const lng = parseFloat(fd.get("lng"));
    try {
      await api("/api/impresoras", {
        method: "POST",
        body: JSON.stringify({
          name: fd.get("printer_name") || "",
          paper: fd.get("printer_paper") || "80",
          copies: digits(fd.get("printer_copies") || 1) || 1,
          cut: !!fd.get("printer_cut"),
        }),
      });
      state.local = await api("/api/local", {
        method: "POST",
        body: JSON.stringify({
          name: fd.get("name"),
          phone: fd.get("phone") || "",
          email: fd.get("email") || "",
          address: fd.get("address") || "",
          city: fd.get("city") || "",
          comuna: fd.get("comuna") || "",
          pais: fd.get("pais") || "CL",
          idioma: fd.get("idioma") || "es",
          tax_id: fd.get("tax_id") || "",
          ticket_header: fd.get("ticket_header") || "",
          ticket_footer: fd.get("ticket_footer") || "",
          printer_name: fd.get("printer_name") || "",
          printer_paper: fd.get("printer_paper") || "80",
          printer_copies: digits(fd.get("printer_copies") || 1) || 1,
          printer_cut: fd.get("printer_cut") ? 1 : 0,
          margin_pct: parseFloat(String(fd.get("margin_pct") || "100").replace(",", ".")),
          stock_alert: digits(fd.get("stock_alert")),
          whatsapp: fd.get("whatsapp") || "",
          instagram: fd.get("instagram") || "",
          facebook: fd.get("facebook") || "",
          website: fd.get("website") || "",
          lat: Number.isFinite(lat) ? lat : null,
          lng: Number.isFinite(lng) ? lng : null,
        }),
      });
      await Promise.all([loadLocal(), loadMercado(), loadPulse(), loadCifras().catch(() => {})]);
      renderStock();
      renderGrid();
      fillAjustes();
      applyLang();
      toast("ajustes guardados");
      showView("hoy");
    } catch (e) {
      toast(e.message);
    }
  }

  const SCAN_FMTS = [
    "ean_13",
    "ean_8",
    "upc_a",
    "upc_e",
    "code_128",
    "code_39",
    "codabar",
    "qr_code",
    "itf",
    "data_matrix",
  ];
  let scanStream = null;
  let scanRaf = 0;

  function nativeCaja() {
    return !!(window.A10_NATIVE && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.caja);
  }
  function beep() {
    try {
      navigator.vibrate && navigator.vibrate(24);
      const ac = new (window.AudioContext || window.webkitAudioContext)();
      const o = ac.createOscillator();
      const g = ac.createGain();
      o.type = "square";
      o.frequency.value = 880;
      g.gain.value = 0.04;
      o.connect(g);
      g.connect(ac.destination);
      o.start();
      o.stop(ac.currentTime + 0.07);
    } catch {
      /* sin audio */
    }
  }
  function looksLikeCode(s) {
    const t = String(s || "").trim();
    if (/^A10-[A-Z0-9]+-[A-Z0-9]+-\d+$/i.test(t)) return true;
    return /^\d{8,14}$/.test(t.replace(/\s/g, ""));
  }
  function normalizeScan(raw) {
    let s = String(raw || "").trim();
    if (/^https?:\/\//i.test(s)) {
      try {
        const u = new URL(s);
        s = u.searchParams.get("sku") || u.searchParams.get("ean") || u.searchParams.get("code") || s;
        if (s === raw) {
          const parts = u.pathname.split("/").filter(Boolean);
          if (parts.length) s = parts[parts.length - 1];
        }
      } catch {
        /* URL rara */
      }
    }
    return s.replace(/\s+/g, "");
  }
  function hitsForCode(raw) {
    const code = normalizeScan(raw);
    if (!code) return [];
    const low = code.toLowerCase();
    const digits = code.replace(/\D/g, "");
    const variants = new Set([code, low, digits]);
    if (digits.length === 12) variants.add("0" + digits);
    if (digits.length === 13 && digits.startsWith("0")) variants.add(digits.slice(1));
    const exact = [];
    const rest = [];
    for (const p of state.catalog) {
      const bar = String(p.barcode || "").replace(/\s/g, "");
      const sku = String(p.sku || "");
      const ref = String(p.ref_code || "");
      const keys = [bar, sku, ref, bar.toLowerCase(), sku.toLowerCase(), ref.toLowerCase()];
      if (keys.some((k) => k && variants.has(k))) exact.push(p);
      else if (low.length >= 4 && `${sku} ${ref} ${bar} ${p.name}`.toLowerCase().includes(low)) rest.push(p);
    }
    return exact.length ? exact : rest;
  }
  function markScanModes() {
    $$("#scanModes .chip").forEach((c) => c.classList.toggle("on", c.dataset.scan === state.scanMode));
  }
  function scanHint() {
    if (state.scanMode === "contar") return "Escanea cada unidad. A10 suma al recuento.";
    if (state.scanMode === "ficha") return "Apunta la etiqueta para abrir la ficha.";
    if (state.scanMode === "precio") return "Apunta la etiqueta para ver el precio, sin cobrar.";
    return "Apunta la etiqueta para sumar al ticket.";
  }
  function puedeCamaraViva() {
    return !!(
      window.isSecureContext &&
      navigator.mediaDevices &&
      navigator.mediaDevices.getUserMedia &&
      "BarcodeDetector" in window
    );
  }
  function showPrecio(p) {
    openSheet(
      "Precio",
      `<p><b>${esc(p.name)}</b></p>
       <p class="sub">${esc(p.brand || KIND_LBL[p.kind] || "")} · ${p.stock <= 0 ? "sin stock" : p.stock + " u."}${p.ref_code ? " · " + esc(p.ref_code) : ""}</p>
       <p class="precio-cifra">${clp(p.price_clp)}</p>
       <div class="sheet-actions">
         <button type="button" class="key ghost" id="precioCerrar">Cerrar</button>
         <button type="button" class="key primary" id="precioTicket" ${p.stock <= 0 ? "disabled" : ""}>Al ticket</button>
       </div>`
    );
    $("#precioCerrar")?.addEventListener("click", closeSheet);
    $("#precioTicket")?.addEventListener("click", () => {
      addToCart(p);
      closeSheet();
      showView("vender");
    });
  }
  function stopWebScan() {
    if (scanRaf) cancelAnimationFrame(scanRaf);
    scanRaf = 0;
    if (scanStream) {
      scanStream.getTracks().forEach((t) => t.stop());
      scanStream = null;
    }
    const v = $("#scanVideo");
    if (v) v.srcObject = null;
  }
  function closeScan() {
    stopWebScan();
    const box = $("#scan");
    if (box) {
      box.hidden = true;
      box.classList.remove("foto");
    }
    if (nativeCaja()) {
      window.webkit.messageHandlers.caja.postMessage({ t: "scanStop" });
    }
  }
  function modoFoto(box, hint) {
    if (box) box.classList.add("foto");
    if (hint) hint.textContent = "Toma una foto nítida de la etiqueta";
  }
  async function openScan(mode) {
    if (mode) state.scanMode = mode;
    if (state.scanMode === "contar") {
      showView("inventario");
      renderConteo();
    }
    markScanModes();
    const hint = $("#scanHint");
    if (hint) hint.textContent = scanHint();
    if (nativeCaja()) {
      window.webkit.messageHandlers.caja.postMessage({ t: "scan", mode: state.scanMode });
      return;
    }
    const box = $("#scan");
    if (box) box.hidden = false;
    const live = puedeCamaraViva();
    if (box) box.classList.toggle("foto", !live);
    if (live) {
      try {
        stopWebScan();
        scanStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" } },
          audio: false,
        });
        const v = $("#scanVideo");
        v.srcObject = scanStream;
        await v.play();
        const det = new BarcodeDetector({ formats: SCAN_FMTS });
        const tick = async () => {
          if ($("#scan").hidden) return;
          try {
            if (v.readyState >= 2) {
              const found = await det.detect(v);
              if (found[0] && found[0].rawValue) aplicarScan(found[0].rawValue);
            }
          } catch {
            /* frame vacío */
          }
          scanRaf = requestAnimationFrame(tick);
        };
        tick();
        return;
      } catch {
        modoFoto(box, hint);
      }
    } else {
      modoFoto(box, hint);
    }
  }
  async function leerFoto(file) {
    if (!file) return "";
    if ("BarcodeDetector" in window) {
      try {
        const bmp = await createImageBitmap(file);
        const det = new BarcodeDetector({ formats: SCAN_FMTS });
        const found = await det.detect(bmp);
        if (bmp.close) bmp.close();
        if (found[0] && found[0].rawValue) return found[0].rawValue;
      } catch {
        /* la caja lo intenta */
      }
    }
    const fd = new FormData();
    fd.append("file", file, file.name || "etiqueta.jpg");
    const res = await fetch("/api/scan/foto", { method: "POST", body: fd, credentials: "same-origin" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || "no vi un código en esa foto");
    return data.code || "";
  }
  function renderConteo() {
    const box = $("#conteo");
    if (!box) return;
    const rows = Object.values(state.conteo);
    if (!rows.length) {
      box.hidden = true;
      box.innerHTML = "";
      return;
    }
    box.hidden = false;
    box.innerHTML = `<h2>Recuento con cámara</h2>
      ${rows
        .map((r) => {
          const diff = r.counted - r.sistema;
          const cls = diff === 0 ? "ok" : "warn";
          const d = diff > 0 ? "+" + diff : String(diff);
          return `<div class="conteo-row">
            <span><b>${esc(r.name)}</b><small> ${esc(r.sku || "")}</small></span>
            <span>sist. ${r.sistema}</span>
            <span>contado ${r.counted}</span>
            <span class="diff ${cls}">${d}</span>
          </div>`;
        })
        .join("")}
      <div class="conteo-acts">
        <button type="button" class="key ghost" id="conteoScan">Seguir escaneando</button>
        <button type="button" class="key ghost" id="conteoClear">Descartar</button>
        <button type="button" class="key primary" id="conteoApply">Aplicar al stock</button>
      </div>`;
    $("#conteoScan").addEventListener("click", () => openScan("contar"));
    $("#conteoClear").addEventListener("click", () => {
      state.conteo = {};
      renderConteo();
      toast("recuento descartado");
    });
    $("#conteoApply").addEventListener("click", applyConteo);
  }
  async function applyConteo() {
    const rows = Object.values(state.conteo);
    if (!rows.length) return;
    let n = 0;
    try {
      for (const r of rows) {
        if (r.counted === r.sistema) continue;
        await api(`/api/catalog/${r.id}/stock`, {
          method: "POST",
          body: JSON.stringify({ stock: r.counted, reason: "conteo" }),
        });
        n += 1;
      }
      state.conteo = {};
      renderConteo();
      await loadCatalog();
      toast(n ? `${n} productos ajustados` : "sin diferencias");
    } catch (e) {
      toast(e.message);
    }
  }
  function contarHit(p) {
    const prev = state.conteo[p.id];
    const counted = (prev ? prev.counted : 0) + 1;
    state.conteo[p.id] = {
      id: p.id,
      name: p.name,
      sku: p.sku,
      sistema: prev ? prev.sistema : p.stock,
      counted,
    };
    showView("inventario");
    renderConteo();
  }
  function altaConBarra(code) {
    closeScan();
    showView("inventario");
    formFicha(null, { barcode: code });
    toast("no estaba · completa la ficha");
  }
  function aplicarScan(raw) {
    const code = normalizeScan(raw);
    if (!code) return;
    const now = Date.now();
    if (code === state.lastScan && now - state.lastScanAt < 1400) return;
    state.lastScan = code;
    state.lastScanAt = now;
    const hits = hitsForCode(code);
    if (hits.length !== 1) {
      beep();
      if (state.scanMode === "ficha" || state.scanMode === "contar") {
        altaConBarra(code);
        return;
      }
      toast(hits.length ? "hay varios con esa etiqueta" : "no está en el inventario");
      return;
    }
    const p = hits[0];
    beep();
    reportaVida("scan", `${state.scanMode} · ${p.name}`);
    if (state.scanMode === "contar") {
      contarHit(p);
      toast(`${p.name} · ${state.conteo[p.id].counted}`);
      return;
    }
    if (state.scanMode === "ficha") {
      closeScan();
      showView("inventario");
      formFicha(p);
      return;
    }
    if (state.scanMode === "precio") {
      closeScan();
      showPrecio(p);
      return;
    }
    addToCart(p);
    toast(`${p.name} al ticket`);
    if (state.scanMode === "vender" && !nativeCaja()) {
      /* la cámara sigue abierta para el siguiente */
    }
  }
  window.A10_onScan = aplicarScan;

  function bind() {
    $$(".rail-btn").forEach((b) => {
      b.addEventListener("click", (ev) => {
        if (b.id === "btnAjustes" && enTelefono()) {
          ev.preventDefault();
          if ($("#masSheet") && !$("#masSheet").hidden) closeMas();
          else openMas();
          return;
        }
        closeMas();
        showView(b.dataset.view);
      });
    });
    $("#masSheet")?.addEventListener("click", (ev) => {
      if (ev.target.id === "masSheet") closeMas();
    });
    $("#masCerrar")?.addEventListener("click", closeMas);
    $$("#masSheet .mas-btn").forEach((b) => {
      b.addEventListener("click", () => showView(b.dataset.view));
    });
    $("#q").addEventListener("input", () => {
      state.q = $("#q").value;
      renderGrid();
    });
    $("#q").addEventListener("keydown", (ev) => {
      if (ev.key !== "Enter") return;
      const code = $("#q").value.trim();
      if (!looksLikeCode(code)) return;
      const hits = hitsForCode(code);
      if (hits.length !== 1) return;
      ev.preventDefault();
      addToCart(hits[0]);
      $("#q").value = "";
      state.q = "";
      renderGrid();
      beep();
    });
    $("#scanShutter")?.addEventListener("click", () => $("#scanFile")?.click());
    $("#btnScanCaja").addEventListener("click", () => openScan("vender"));
    $("#btnInvScan").addEventListener("click", () => {
      const hayConteo = Object.keys(state.conteo).length;
      openScan(hayConteo ? "contar" : "ficha");
    });
    $$("#scanModes .chip").forEach((c) => {
      c.addEventListener("click", () => {
        state.scanMode = c.dataset.scan;
        markScanModes();
        const hint = $("#scanHint");
        if (hint) hint.textContent = scanHint();
        if (state.scanMode === "contar") {
          showView("inventario");
          renderConteo();
        }
      });
    });
    $("#scanClose").addEventListener("click", closeScan);
    $("#scanFoto").addEventListener("click", () => $("#scanFile").click());
    $("#scanFile").addEventListener("change", async () => {
      const file = $("#scanFile").files[0];
      $("#scanFile").value = "";
      if (!file) return;
      try {
        const code = await leerFoto(file);
        if (!code) {
          toast("no vi un código en esa foto");
          return;
        }
        aplicarScan(code);
      } catch (e) {
        toast(e.message || "no pude leer esa foto");
      }
    });
    $$("#chips .chip").forEach((c) => {
      c.addEventListener("click", () => {
        state.kind = c.dataset.kind;
        $$("#chips .chip").forEach((x) => x.classList.toggle("on", x === c));
        renderGrid();
      });
    });
    $$("#pays .pay").forEach((b) => {
      b.addEventListener("click", () => {
        state.pay = b.dataset.pay;
        $$("#pays .pay").forEach((x) => x.classList.toggle("on", x === b));
      });
    });
    $("#btnCobrar").addEventListener("click", cobrar);
    $("#btnVaciar").addEventListener("click", () => {
      state.cart = [];
      renderCart();
    });
    $("#btnNuevaOrden").addEventListener("click", formNuevaOrden);
    bindConstancia();
    $("#btnPiso").addEventListener("click", formPiso);
    $$("#hoyDias .chip, #ventasDias .chip, #repDias .chip").forEach((c) => {
      c.addEventListener("click", () => {
        state.cifrasDias = Number(c.dataset.dias);
        markDias();
        loadCifras();
      });
    });
    $("#btnNuevoProd").addEventListener("click", () => formFicha(null));
    $("#btnLocal").addEventListener("click", formLocal);
    $$(".cfg-tab").forEach((b) => {
      b.addEventListener("click", () => showCfg(b.dataset.cfg));
    });
    $("#fAjustes")?.addEventListener("submit", saveAjustes);
    $("#btnFonoCopy")?.addEventListener("click", async () => {
      const url = ($("#fonoUrl")?.textContent || "").trim();
      if (!url || url === "—") {
        toast("todavía no hay dirección");
        return;
      }
      try {
        await navigator.clipboard.writeText(url);
        toast("dirección copiada");
      } catch {
        toast(url);
      }
    });
    $("#btnPrinters")?.addEventListener("click", () => loadImpresoras(true));
    $("#printerPick")?.addEventListener("change", () => {
      const name = $("#printerPick").value;
      const p = state.impresoras.find((x) => x.name === name);
      const port = $("#printerPort");
      if (port) port.textContent = p ? `Puerto ${p.port || "—"} · ${p.estado || "lista"}` : "Ninguna elegida.";
    });
    $("#btnUserAdd")?.addEventListener("click", async () => {
      const name = ($("#userName")?.value || "").trim();
      const clave = ($("#userClave")?.value || "").trim();
      const role = $("#userRole")?.value || "mostrador";
      try {
        await api("/api/usuarios", { method: "POST", body: JSON.stringify({ name, clave, role }) });
        if (!state.yo) {
          state.yo = await api("/api/login", { method: "POST", body: JSON.stringify({ name, clave }) });
          paintWho();
        }
        if ($("#userName")) $("#userName").value = "";
        if ($("#userClave")) $("#userClave").value = "";
        toast("persona agregada");
        await loadUsuarios();
      } catch (e) {
        toast(e.message);
      }
    });
    $("#usersList")?.addEventListener("click", async (ev) => {
      const btn = ev.target.closest("[data-user-del]");
      if (!btn) return;
      try {
        await api(`/api/usuarios/${btn.dataset.userDel}/quitar`, { method: "POST" });
        toast("sacada");
        await loadUsuarios();
      } catch (e) {
        toast(e.message);
      }
    });
    $("#btnSalir")?.addEventListener("click", async () => {
      try {
        await api("/api/salir", { method: "POST" });
      } catch {
        /* da igual */
      }
      state.yo = null;
      paintWho();
      showGate(false);
    });
    $("#btnOlvido")?.addEventListener("click", () => {
      const box = $("#gateOlvido");
      if (box) box.hidden = !box.hidden;
    });
    $("#fGate")?.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const fd = new FormData(ev.target);
      const err = $("#gateErr");
      const primero = $("#gate")?.dataset.primero === "1";
      try {
        const user = await api(primero ? "/api/primero" : "/api/login", {
          method: "POST",
          body: JSON.stringify({ name: fd.get("name"), clave: fd.get("clave") }),
        });
        state.yo = user;
        hideGate();
        paintWho();
        ev.target.reset();
        if (err) err.hidden = true;
        await entrarCaja();
      } catch (e) {
        if (err) {
          err.hidden = false;
          err.textContent = e.message;
        } else toast(e.message);
      }
    });
    $("#btnRespaldo")?.addEventListener("click", () => {
      window.location.href = "/api/respaldo";
    });
    $("#pagoUrl")?.addEventListener("input", () => {
      $("#pagoUrl").dataset.dirty = "1";
    });
    $("#btnPagoUrl")?.addEventListener("click", async () => {
      const u = ($("#pagoUrl")?.value || "").trim();
      try {
        const r = await api("/api/pago/url", { method: "POST", body: JSON.stringify({ url: u }) });
        if ($("#pagoUrl")) $("#pagoUrl").dataset.dirty = "";
        toast(r.url ? "link guardado" : "saqué el link");
        await loadPago();
      } catch (e) {
        toast(e.message);
      }
    });
    $("#btnPagarMes")?.addEventListener("click", (ev) => {
      const u = (pagoState && pagoState.url) || ($("#pagoUrl")?.value || "").trim();
      if (!u) {
        ev.preventDefault();
        toast("falta el link de Banco de Chile");
        return;
      }
    });
    $("#btnMarcarMes")?.addEventListener("click", async () => {
      try {
        await api("/api/pago/mes", { method: "POST", body: JSON.stringify({}) });
        toast("mes marcado");
        await loadPago();
      } catch (e) {
        toast(e.message);
      }
    });
    $("#btnGeo")?.addEventListener("click", () => {
      if (!navigator.geolocation) {
        toast("este equipo no da ubicación");
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const form = $("#fAjustes");
          if (!form) return;
          form.elements.lat.value = pos.coords.latitude.toFixed(5);
          form.elements.lng.value = pos.coords.longitude.toFixed(5);
        },
        () => toast("no se pudo leer la ubicación")
      );
    });
    $$("#pulse [data-go]").forEach((b) => {
      b.addEventListener("click", () => {
        const go = b.dataset.go;
        if (go === "inventario" && b.id === "pulseBajosBtn") {
          state.invFlag = "bajos";
          $$("#invFlags .chip").forEach((x) => x.classList.toggle("on", x.dataset.flag === "bajos"));
        }
        showView(go);
      });
    });
    const toggleInvPanel = (id) => {
      const box = $(id);
      if (!box) return;
      const open = box.hidden;
      if ($("#invLoad")) $("#invLoad").hidden = true;
      if ($("#invFactura")) $("#invFactura").hidden = true;
      box.hidden = !open;
    };
    $("#btnInvLoad").addEventListener("click", () => {
      state.listaKind = "lista";
      toggleInvPanel("#invLoad");
    });
    $("#btnInvFactura")?.addEventListener("click", () => {
      state.listaKind = "factura";
      toggleInvPanel("#invFactura");
    });
    $$("#invFlags .chip").forEach((c) => {
      c.addEventListener("click", () => {
        state.invFlag = state.invFlag === c.dataset.flag ? "" : c.dataset.flag;
        $$("#invFlags .chip").forEach((x) => x.classList.toggle("on", x.dataset.flag === state.invFlag));
        renderStock();
      });
    });
    $("#invBrand").addEventListener("change", () => {
      state.invBrand = $("#invBrand").value;
      renderStock();
    });
    $("#invSort").addEventListener("change", () => {
      state.invSort = $("#invSort").value;
      renderStock();
    });
    $("#invQ").addEventListener("input", () => {
      state.invQ = $("#invQ").value;
      renderStock();
    });
    $("#invQ").addEventListener("keydown", (ev) => {
      if (ev.key !== "Enter") return;
      const code = $("#invQ").value.trim();
      if (!looksLikeCode(code)) return;
      const hits = hitsForCode(code);
      if (hits.length !== 1) return;
      ev.preventDefault();
      formFicha(hits[0]);
    });
    $$("#invChips .chip").forEach((c) => {
      c.addEventListener("click", () => {
        state.invKind = c.dataset.kind;
        $$("#invChips .chip").forEach((x) => x.classList.toggle("on", x === c));
        renderStock();
      });
    });
    const drop = $("#invDrop");
    const invFile = $("#invFile");
    const leerArchivo = async (file) => {
      if (!file) return;
      try {
        toast("leyendo lista…");
        await leerLista(file);
      } catch (e) {
        toast(e.message);
      }
    };
    $("#btnInvFile").addEventListener("click", () => invFile.click());
    drop.addEventListener("dragover", (ev) => {
      ev.preventDefault();
      drop.classList.add("over");
    });
    drop.addEventListener("dragleave", () => drop.classList.remove("over"));
    drop.addEventListener("drop", async (ev) => {
      ev.preventDefault();
      drop.classList.remove("over");
      await leerArchivo(ev.dataTransfer && ev.dataTransfer.files[0]);
    });
    invFile.addEventListener("change", async () => {
      await leerArchivo(invFile.files[0]);
      invFile.value = "";
    });
    $("#btnInvPaste").addEventListener("click", async () => {
      const text = ($("#invPaste").value || "").trim();
      if (!text) {
        toast("pega la lista o elige un archivo");
        return;
      }
      try {
        toast("leyendo lista…");
        await leerLista(null, text, "lista");
        $("#invPaste").value = "";
      } catch (e) {
        toast(e.message);
      }
    });
    const facFile = $("#facFile");
    const leerFactura = async (file) => {
      if (!file) return;
      try {
        toast("leyendo factura…");
        await leerLista(file, "", "factura");
      } catch (e) {
        toast(e.message);
      }
    };
    $("#btnFacFile")?.addEventListener("click", () => facFile && facFile.click());
    const facDrop = $("#facDrop");
    facDrop?.addEventListener("dragover", (ev) => {
      ev.preventDefault();
      facDrop.classList.add("over");
    });
    facDrop?.addEventListener("dragleave", () => facDrop.classList.remove("over"));
    facDrop?.addEventListener("drop", async (ev) => {
      ev.preventDefault();
      facDrop.classList.remove("over");
      await leerFactura(ev.dataTransfer && ev.dataTransfer.files[0]);
    });
    facFile?.addEventListener("change", async () => {
      await leerFactura(facFile.files[0]);
      facFile.value = "";
    });
    $("#btnFacPaste")?.addEventListener("click", async () => {
      const text = ($("#facPaste") && $("#facPaste").value || "").trim();
      if (!text) {
        toast("pega las líneas o elige un archivo");
        return;
      }
      try {
        toast("leyendo factura…");
        await leerLista(null, text, "factura");
        if ($("#facPaste")) $("#facPaste").value = "";
      } catch (e) {
        toast(e.message);
      }
    });
    const subirLogo = async (file) => {
      if (!file) return;
      const fd = new FormData();
      fd.append("file", file, file.name || "logo.jpg");
      const res = await fetch("/api/local/logo", { method: "POST", body: fd });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(errDetail(data) || "no pude guardar el logo");
      state.local = { ...(state.local || {}), ...data };
      paintLogo();
      toast("logo listo para el ticket");
    };
    const elegirLogo = async () => {
      try {
        if (window.pywebview && window.pywebview.api && window.pywebview.api.guardar_logo) {
          const data = await window.pywebview.api.guardar_logo();
          if (!data || data.ok === false) {
            if (data && data.error) throw new Error(data.error);
            return;
          }
          state.local = { ...(state.local || {}), logo: data.logo || "logo.jpg" };
          paintLogo();
          toast("logo listo para el ticket");
          return;
        }
        $("#logoFile")?.click();
      } catch (e) {
        toast(e.message);
      }
    };
    $("#btnLogo")?.addEventListener("click", elegirLogo);
    $("#logoDrop")?.addEventListener("click", elegirLogo);
    const logoDrop = $("#logoDrop");
    logoDrop?.addEventListener("dragover", (ev) => {
      ev.preventDefault();
      logoDrop.classList.add("on");
    });
    logoDrop?.addEventListener("dragleave", () => logoDrop.classList.remove("on"));
    logoDrop?.addEventListener("drop", async (ev) => {
      ev.preventDefault();
      logoDrop.classList.remove("on");
      try {
        await subirLogo(ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0]);
      } catch (e) {
        toast(e.message);
      }
    });
    $("#logoFile")?.addEventListener("change", async () => {
      try {
        await subirLogo($("#logoFile").files[0]);
      } catch (e) {
        toast(e.message);
      }
      $("#logoFile").value = "";
    });
    $("#btnLogoQuitar")?.addEventListener("click", async () => {
      try {
        const data = await api("/api/local/logo", { method: "DELETE" });
        state.local = { ...(state.local || {}), ...data, logo: "" };
        paintLogo();
        toast("logo quitado");
      } catch (e) {
        toast(e.message);
      }
    });
    const buscarPieza = () => {
      state.mktQ = $("#mktQ").value;
      loadMercado();
    };
    $("#mktGo").addEventListener("click", buscarPieza);
    $("#mktGoBand")?.addEventListener("click", () => {
      showView("compras");
      $("#mktQ")?.focus();
    });
    bindAtencion("#view-finanzas");
    bindAtencion("#view-clientes");
    $("#mktQ").addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") {
        ev.preventDefault();
        buscarPieza();
      }
    });
    $("#sheetClose").addEventListener("click", closeSheet);
    $("#sheet").addEventListener("click", (ev) => {
      if (ev.target.id === "sheet") closeSheet();
    });
    $("#ticketPrint")?.addEventListener("click", () => {
      const n = Math.max(1, Math.min(3, Number(state.local && state.local.printer_copies) || 1));
      for (let i = 0; i < n; i += 1) window.print();
    });
    $("#ticketPdf")?.addEventListener("click", () => {
      const id = state.lastSaleId;
      if (!id) return;
      window.open(`/api/sales/${id}/pdf`, "_blank");
    });
    $("#btnTutorial")?.addEventListener("click", () => startTour(true));
    $("#btnTutorialCaja")?.addEventListener("click", () => startTour(true));
    $("#paisPick")?.addEventListener("change", (ev) => {
      const code = ev.target.value;
      const taxLbl = $("#taxLbl");
      if (taxLbl) taxLbl.textContent = PAIS_ID[code] || "RUT";
      const idioma = document.querySelector('#fAjustes [name="idioma"]');
      if (idioma && code === "BR") idioma.value = "pt";
    });
    $("#ticketOk").addEventListener("click", () => {
      $("#ticket").hidden = true;
    });
    $("#ticket").addEventListener("click", (ev) => {
      if (ev.target.id === "ticket") $("#ticket").hidden = true;
    });
    document.addEventListener("keydown", (ev) => {
      if (ev.key === "Escape") {
        closeSheet();
        closeMas();
        closeScan();
        $("#ticket").hidden = true;
        return;
      }
      const tag = (ev.target && ev.target.tagName) || "";
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (ev.key === "/" || ev.key === "f" || ev.key === "F") {
        ev.preventDefault();
        showView("vender");
        $("#q")?.focus();
      }
    });
  }

  async function boot() {
    clock();
    setInterval(clock, 15000);
    pulsoRed();
    setInterval(pulsoRed, 20000);
    setInterval(() => {
      if (netState.piloto && !netState.internet && !netState.expired && netState.quedan_s != null) {
        netState.quedan_s = Math.max(0, netState.quedan_s - 1);
        if (netState.quedan_s === 0) netState.expired = true;
        paintNet(netState);
      }
    }, 1000);
    bind();
    renderCart();
    try {
      const yo = await api("/api/yo");
      if (!(await gateReady(yo))) return;
      await entrarCaja();
      const ios = /iPhone|iPad|iPod/i.test(navigator.userAgent);
      const sola = window.navigator.standalone || window.matchMedia("(display-mode: standalone)").matches;
      if (ios && !sola && !nativeCaja() && !sessionStorage.getItem("a10_ios")) {
        sessionStorage.setItem("a10_ios", "1");
        toast("Safari: Compartir → Agregar a inicio");
      }
    } catch (e) {
      toast(e.message || "la caja no responde");
    }
  }

  boot();
})();
