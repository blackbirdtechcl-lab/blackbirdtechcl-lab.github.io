#!/bin/bash
# A10 en este Mac. Un toque. El cobro queda aquí.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true

export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8
PORT="${A10_PORT:-5050}"

say() { printf "%s\n" "$*"; }
fail() { say ""; say "$*"; say ""; read -r -p "Enter para cerrar. " _; exit 1; }

py=""
for cand in python3.12 python3.11 python3.10 python3; do
  if command -v "$cand" >/dev/null 2>&1; then
    py="$(command -v "$cand")"
    break
  fi
done
if [[ -z "$py" ]]; then
  open "https://www.python.org/downloads/macos/" >/dev/null 2>&1 || true
  fail "Falta Python 3. Instálalo desde python.org (el de macOS), cierra y toca A10 otra vez."
fi
if ! "$py" -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" 2>/dev/null; then
  open "https://www.python.org/downloads/macos/" >/dev/null 2>&1 || true
  fail "Este Python es viejo. Instala Python 3.10 o más nuevo y toca A10 otra vez."
fi
if ! "$py" -c "import sys" >/dev/null 2>&1; then
  fail "macOS pide las herramientas de Xcode. En Terminal: xcode-select --install"
fi

if [[ ! -x "$ROOT/.venv/bin/python" ]]; then
  say "Primera vez: un minuto, con internet."
  "$py" -m venv "$ROOT/.venv"
fi
VENV="$ROOT/.venv/bin/python"
"$VENV" -m pip install --upgrade pip >/dev/null
"$VENV" -m pip install -r "$ROOT/requirements.txt"

lan=""
for iface in en0 en1 en2; do
  lan="$(ipconfig getifaddr "$iface" 2>/dev/null || true)"
  [[ -n "$lan" ]] && break
done

if curl -sf --max-time 2 "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
  open "http://127.0.0.1:${PORT}/"
  say "A10 ya estaba abierto. Se abrió el navegador."
  if [[ -n "$lan" ]]; then
    say "iPhone, misma wifi:  http://${lan}:${PORT}/"
  fi
  read -r -p "Puedes cerrar esta ventana. La caja sigue. " _
  exit 0
fi

say "Abriendo A10…"
"$VENV" -m uvicorn edge.app:app --host 0.0.0.0 --port "$PORT" &
UV=$!
trap 'kill "$UV" 2>/dev/null || true' EXIT

ok=0
for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
  if curl -sf --max-time 1 "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
    ok=1
    break
  fi
  sleep 0.4
done
if [[ "$ok" -ne 1 ]]; then
  fail "No levantó la caja en el puerto ${PORT}."
fi

open "http://127.0.0.1:${PORT}/"
say ""
say "Listo. Se abrió el navegador. Esa es la caja."
if [[ -n "$lan" ]]; then
  say "iPhone, misma wifi:  http://${lan}:${PORT}/"
  say "Safari → Compartir → Agregar a inicio."
fi
say "Cierra esta ventana para apagar la caja."
say ""
wait "$UV"
