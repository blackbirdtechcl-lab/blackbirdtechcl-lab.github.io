"""A10 — caja del local. Puerto 5000."""
from __future__ import annotations

import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, Request, Response, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from edge import auth
from edge import catalog
from edge import cifras
from edge import clientes
from edge import db as store
from edge import impresora
from edge import sistema
from edge import inventario
from edge import inventario_parse
from edge import market
from edge import piso
from edge import comprobante
from edge import parte
from edge import pais
from edge import pago
from edge import photo
from edge import red as redmod
from edge import sales
from edge import scan
from edge import taller
from edge import tapa
from edge import telefono

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"

app = FastAPI(title="A10", version="0.1.0")
UI_VER = "1"


_ABIERTOS = {
    "/api/health",
    "/api/pulso",
    "/api/yo",
    "/api/login",
    "/api/salir",
    "/api/primero",
    "/api/descargar",
    "/api/parte",
    "/api/centro",
    "/api/pago",
}


def _api_abierto(path: str) -> bool:
    return path in _ABIERTOS


@app.middleware("http")
async def _acceso(request: Request, call_next):
    path = request.url.path
    if not path.startswith("/api/") or _api_abierto(path):
        return await call_next(request)
    try:
        if not auth.hay_usuarios():
            return await call_next(request)
    except Exception:
        return await call_next(request)
    yo = auth.quien(request.cookies.get(auth.COOKIE) or "")
    if not yo:
        return JSONResponse({"detail": "entra con tu nombre y clave"}, status_code=401)
    request.state.yo = yo
    role = yo.get("role") or ""
    if role != "dueno":
        if path.startswith("/api/usuarios") or (
            path == "/api/impresoras" and request.method in {"POST", "PUT"}
        ):
            return JSONResponse({"detail": "eso lo hace el dueño"}, status_code=403)
        if path == "/api/local" and request.method == "POST":
            return JSONResponse({"detail": "eso lo hace el dueño"}, status_code=403)
        if path.startswith("/api/pago/") and request.method == "POST":
            return JSONResponse({"detail": "eso lo hace el dueño"}, status_code=403)
        if path.endswith("/anular"):
            return JSONResponse({"detail": "eso lo hace el dueño"}, status_code=403)
        if role == "tecnico" and path.startswith("/api/sales") and request.method == "POST":
            return JSONResponse({"detail": "el técnico no cobra en el mostrador"}, status_code=403)
    return await call_next(request)


@app.middleware("http")
async def _no_cache_ui(request, call_next):
    response = await call_next(request)
    path = request.url.path
    if path == "/" or path.endswith(".html"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
        response.headers["Pragma"] = "no-cache"
    elif path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-cache, must-revalidate"
    try:
        ip = request.client.host if request.client else ""
        parte.notar(path, ip, request.headers.get("user-agent") or "")
    except Exception:
        pass
    return response


@app.on_event("startup")
def _boot() -> None:
    store.init_db()
    redmod.start()


@app.on_event("shutdown")
def _halt() -> None:
    redmod.stop()


def _http(err: Exception) -> HTTPException:
    if isinstance(err, KeyError):
        return HTTPException(status_code=404, detail=str(err) or "no encontrado")
    if isinstance(err, ValueError):
        return HTTPException(status_code=400, detail=str(err))
    return HTTPException(status_code=500, detail=str(err))


class LocalIn(BaseModel):
    name: str | None = None
    address: str | None = None
    lat: float | None = None
    lng: float | None = None
    ticket_footer: str | None = None
    ticket_header: str | None = None
    margin_pct: float | None = None
    stock_alert: int | None = None
    phone: str | None = None
    email: str | None = None
    city: str | None = None
    comuna: str | None = None
    whatsapp: str | None = None
    instagram: str | None = None
    facebook: str | None = None
    website: str | None = None
    printer_name: str | None = None
    printer_paper: str | None = None
    printer_copies: int | None = None
    printer_cut: int | None = None
    pais: str | None = None
    idioma: str | None = None
    tax_id: str | None = None
    tutorial_visto: int | None = None


class MarketIn(BaseModel):
    on: bool
    price_clp: int = Field(0, ge=0)
    show_stock: bool = False
    fulfill: str = "retiro"
    eta_min: int = Field(30, ge=0)


class AskIn(BaseModel):
    key: str
    qty: int = Field(1, ge=1)
    fulfill: str
    backup: bool = False
    note: str = ""


class ChatIn(BaseModel):
    key: str
    text: str


class AccesoIn(BaseModel):
    name: str
    clave: str


class UserIn(BaseModel):
    name: str
    clave: str
    role: str = "mostrador"


class ImpresoraIn(BaseModel):
    name: str = ""
    paper: str = "80"
    copies: int = Field(1, ge=1, le=3)
    cut: bool = True


class ProductIn(BaseModel):
    name: str
    kind: str
    price_clp: int = Field(..., ge=0)
    stock: int = Field(0, ge=0)
    brand: str = ""
    sku: str = ""
    cost_clp: int = Field(0, ge=0)
    barcode: str = ""
    note: str = ""
    ref_code: str = ""
    ubicacion: str = ""


class InventarioCargaIn(BaseModel):
    lines: list[dict[str, Any]]
    modo: str = "sumar"
    origen: str = "lista"
    proveedor: str = ""
    folio: str = ""
    fecha: str = ""


class StockIn(BaseModel):
    stock: int = Field(..., ge=0)
    reason: str = "conteo"


class SaleItemIn(BaseModel):
    product_id: int
    qty: int = Field(..., ge=1)
    imei: str = ""


class SaleIn(BaseModel):
    items: list[SaleItemIn]
    pay_method: str
    note: str = ""


class OrderIn(BaseModel):
    customer_name: str
    device: str
    issue: str
    customer_phone: str = ""
    imei: str = ""
    price_clp: int = Field(0, ge=0)
    note: str = ""
    bench_id: int | None = None
    tech_id: int | None = None
    marca: str = ""
    serial: str = ""
    color: str = ""
    photo: str = ""


class MoveIn(BaseModel):
    status: str
    bench_id: int | None = None
    tech_id: int | None = None


class PisoIn(BaseModel):
    benches: int = Field(..., ge=1, le=16)


class MesaIn(BaseModel):
    x: float
    y: float
    name: str | None = None


class MesaTechIn(BaseModel):
    tech_id: int | None = None


class MesaStockIn(BaseModel):
    product_id: int
    qty: int = Field(..., ge=1)
    reason: str = "carga"


class TechIn(BaseModel):
    name: str = ""
    active: bool | None = None


class PayOrderIn(BaseModel):
    pay_method: str


@app.get("/api/health")
def health() -> dict[str, Any]:
    loc = store.local()
    return {"ok": True, "name": loc["name"], "db": str(store.DB_PATH), "red": redmod.snapshot()}


@app.get("/api/telefono")
def get_telefono() -> dict[str, Any]:
    return telefono.enlace()


@app.get("/api/telefono/qr")
def get_telefono_qr():
    raw = telefono.qr_png()
    if not raw:
        raise HTTPException(status_code=404, detail="sin código")
    return Response(content=raw, media_type="image/png")


@app.post("/api/scan/foto")
async def post_scan_foto(file: UploadFile = File(...)) -> dict[str, Any]:
    raw = await file.read()
    try:
        return scan.leer(raw)
    except Exception as e:
        raise _http(e) from e


@app.get("/api/yo")
def get_yo(request: Request) -> dict[str, Any]:
    rec = {"ok": False, "hecho": False, "nombre": ""}
    try:
        rec = auth.aplicar_recuperar()
    except Exception:
        rec = {"ok": False, "hecho": False, "nombre": ""}
    locked = False
    try:
        locked = auth.hay_usuarios()
    except Exception:
        locked = False
    yo = auth.quien(request.cookies.get(auth.COOKIE) or "")
    return {
        "locked": locked,
        "primero": bool(store.es_instalado() and not locked),
        "user": yo,
        "nombres": auth.nombres() if locked else [],
        "recupero": rec,
    }


@app.post("/api/primero")
def post_primero(body: AccesoIn, response: Response) -> dict[str, Any]:
    try:
        auth.primero(body.name, body.clave)
        data = auth.entrar(body.name, body.clave)
    except Exception as e:
        raise _http(e) from e
    response.set_cookie(
        auth.COOKIE,
        data["token"],
        httponly=True,
        samesite="lax",
        max_age=auth.HORAS * 3600,
    )
    return data["user"]


@app.post("/api/login")
def post_login(body: AccesoIn, response: Response) -> dict[str, Any]:
    try:
        data = auth.entrar(body.name, body.clave)
    except Exception as e:
        raise _http(e) from e
    response.set_cookie(
        auth.COOKIE,
        data["token"],
        httponly=True,
        samesite="lax",
        max_age=auth.HORAS * 3600,
    )
    return data["user"]


@app.post("/api/salir")
def post_salir(request: Request, response: Response) -> dict[str, Any]:
    auth.salir(request.cookies.get(auth.COOKIE) or "")
    response.delete_cookie(auth.COOKIE)
    return {"ok": True}


@app.get("/api/usuarios")
def get_usuarios() -> list[dict[str, Any]]:
    return auth.listar()


@app.post("/api/usuarios")
def post_usuario(body: UserIn) -> dict[str, Any]:
    try:
        return auth.crear(body.name, body.clave, body.role)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/usuarios/{user_id}/quitar")
def post_quitar_usuario(user_id: int, request: Request) -> dict[str, Any]:
    yo = getattr(request.state, "yo", None) or auth.quien(request.cookies.get(auth.COOKIE) or "")
    if not yo:
        raise HTTPException(status_code=401, detail="entra con tu nombre y clave")
    try:
        auth.borrar(user_id, int(yo["id"]))
    except Exception as e:
        raise _http(e) from e
    return {"ok": True}


@app.get("/api/impresoras")
def get_impresoras(fresco: int = 0) -> dict[str, Any]:
    try:
        return impresora.snapshot(fresco=bool(fresco))
    except Exception as e:
        raise _http(e) from e


@app.post("/api/impresoras")
def post_impresora(body: ImpresoraIn) -> dict[str, Any]:
    try:
        loc = impresora.usar(body.name, body.paper, body.copies, body.cut)
    except Exception as e:
        raise _http(e) from e
    return {
        "ok": True,
        "usada": loc.get("printer_name") or "",
        "papel": loc.get("printer_paper") or "80",
        "copias": int(loc.get("printer_copies") or 1),
        "corte": bool(int(loc.get("printer_cut") if loc.get("printer_cut") is not None else 1)),
    }


@app.get("/api/sistema")
def get_sistema() -> dict[str, Any]:
    return sistema.informe()


@app.get("/api/pulso")
def get_pulso() -> dict[str, Any]:
    st = sistema.estado_arriendo(ping=True)
    st["ok"] = True
    st["version"] = store.version()
    st["pago"] = pago.estado(piloto=bool(st.get("piloto")))
    if st.get("internet"):
        parte.avisar()
    return st


@app.get("/api/pago")
def get_pago() -> dict[str, Any]:
    st = pago.estado()
    st["ok"] = True
    return st


@app.post("/api/pago/url")
def post_pago_url(body: dict[str, Any]) -> dict[str, Any]:
    try:
        u = pago.guardar_url(str(body.get("url") or ""))
    except Exception as e:
        raise _http(e) from e
    return {"ok": True, "url": u}


@app.post("/api/pago/mes")
def post_pago_mes(body: dict[str, Any] | None = None) -> dict[str, Any]:
    data = body or {}
    code = str(data.get("shop_code") or "").strip()
    try:
        if code:
            hasta = pago.marcar_nodo(code)
        else:
            hasta = pago.marcar_mes()
    except Exception as e:
        raise _http(e) from e
    return {"ok": True, "hasta": hasta}


@app.get("/api/clientes")
def get_clientes() -> list[dict[str, Any]]:
    return clientes.listar()


@app.get("/api/local")
def get_local() -> dict[str, Any]:
    loc = store.local()
    p = pais.actual()
    loc["pais"] = p["pais"]
    loc["idioma"] = p["idioma"]
    loc["moneda"] = p["moneda"]
    loc["simbolo"] = p["simbolo"]
    loc["id_fiscal"] = p["id_fiscal"]
    loc["doc"] = p["doc"]
    loc["aviso"] = p["aviso"]
    loc["pais_nombre"] = p["nombre"]
    return loc


@app.get("/api/pais")
def get_pais() -> dict[str, Any]:
    cur = pais.actual()
    cur["paises"] = [{"code": code, **pais.pack(code)} for code in pais.PAISES]
    cur["idiomas"] = [{"code": code, "nombre": nombre} for code, nombre in pais.IDIOMAS.items()]
    return cur


@app.post("/api/local")
def post_local(body: LocalIn) -> dict[str, Any]:
    try:
        return store.set_local(
            name=body.name,
            address=body.address,
            lat=body.lat,
            lng=body.lng,
            ticket_footer=body.ticket_footer,
            ticket_header=body.ticket_header,
            margin_pct=body.margin_pct,
            stock_alert=body.stock_alert,
            phone=body.phone,
            email=body.email,
            city=body.city,
            comuna=body.comuna,
            whatsapp=body.whatsapp,
            instagram=body.instagram,
            facebook=body.facebook,
            website=body.website,
            printer_name=body.printer_name,
            printer_paper=body.printer_paper,
            printer_copies=body.printer_copies,
            printer_cut=body.printer_cut,
            pais=body.pais,
            idioma=body.idioma,
            tax_id=body.tax_id,
            tutorial_visto=body.tutorial_visto,
        )
    except Exception as e:
        raise _http(e) from e


@app.get("/api/mercado")
def get_mercado(q: str = "", fulfill: str = "") -> dict[str, Any]:
    return market.feed(q=q, fulfill=fulfill)


@app.post("/api/catalog/{product_id}/mercado")
def post_publicar(product_id: int, body: MarketIn) -> dict[str, Any]:
    try:
        return market.publish(
            product_id=product_id,
            on=body.on,
            price_clp=body.price_clp,
            show_stock=body.show_stock,
            fulfill=body.fulfill,
            eta_min=body.eta_min,
        )
    except Exception as e:
        raise _http(e) from e


@app.post("/api/mercado/pedir")
def post_pedir(body: AskIn) -> dict[str, Any]:
    try:
        return market.ask(
            key=body.key,
            qty=body.qty,
            fulfill=body.fulfill,
            backup=body.backup,
            note=body.note,
        )
    except Exception as e:
        raise _http(e) from e


@app.get("/api/mercado/chat")
def get_chat(key: str) -> dict[str, Any]:
    try:
        return market.thread(key)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/mercado/chat")
def post_chat(body: ChatIn) -> dict[str, Any]:
    try:
        return market.say(body.key, body.text)
    except Exception as e:
        raise _http(e) from e


@app.get("/api/mercado/pedidos")
def get_pedidos() -> list[dict[str, Any]]:
    return market.orders()


@app.post("/api/mercado/pedidos/{order_id}/mover")
def post_pedido_mover(order_id: int, body: MoveIn) -> dict[str, Any]:
    try:
        return market.move(order_id, body.status)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/inventario/leer")
async def post_inventario_leer(
    file: UploadFile | None = File(None),
    lista: UploadFile | None = File(None),
    text: str = Form(""),
) -> dict[str, Any]:
    try:
        up = file if file is not None and file.filename else lista
        if up is not None and (up.filename or "").strip():
            raw = await up.read()
            parsed = inventario_parse.read_upload(up.filename or "lista.csv", raw)
        elif (text or "").strip():
            parsed = inventario_parse.parse_text(text)
        else:
            raise ValueError("sube una lista o una factura (Excel, CSV o foto) o pega el texto")
        return inventario.preview(parsed)
    except KeyError as e:
        raise HTTPException(
            status_code=400,
            detail="no pude leer ese archivo. Prueba un Excel .xlsx, un CSV o una foto",
        ) from e
    except Exception as e:
        raise _http(e) from e


@app.post("/api/inventario/cargar")
def post_inventario_cargar(body: InventarioCargaIn) -> dict[str, Any]:
    try:
        return inventario.apply(
            body.lines,
            modo=body.modo,
            origen=body.origen,
            proveedor=body.proveedor,
            folio=body.folio,
            fecha=body.fecha,
        )
    except Exception as e:
        raise _http(e) from e


@app.get("/api/catalog")
def get_catalog(q: str = "", kind: str = "") -> list[dict[str, Any]]:
    return catalog.list_products(q=q, kind=kind)


@app.post("/api/catalog")
def post_catalog(body: ProductIn) -> dict[str, Any]:
    try:
        return catalog.add_product(
            name=body.name,
            kind=body.kind,
            price_clp=body.price_clp,
            stock=body.stock,
            brand=body.brand,
            sku=body.sku,
            cost_clp=body.cost_clp,
            barcode=body.barcode,
            note=body.note,
            ref_code=body.ref_code,
            ubicacion=body.ubicacion,
        )
    except Exception as e:
        raise _http(e) from e


@app.post("/api/catalog/{product_id}")
def post_catalog_edit(product_id: int, body: ProductIn) -> dict[str, Any]:
    try:
        return catalog.update_product(
            product_id,
            name=body.name,
            kind=body.kind,
            price_clp=body.price_clp,
            stock=body.stock,
            brand=body.brand,
            sku=body.sku,
            cost_clp=body.cost_clp,
            barcode=body.barcode,
            note=body.note,
            ref_code=body.ref_code,
            ubicacion=body.ubicacion,
        )
    except Exception as e:
        raise _http(e) from e


@app.get("/api/catalog/{product_id}/movimientos")
def get_catalog_moves(product_id: int) -> list[dict[str, Any]]:
    return catalog.movimientos(product_id)


@app.post("/api/catalog/{product_id}/stock")
def post_catalog_stock(product_id: int, body: StockIn) -> dict[str, Any]:
    try:
        return catalog.ajustar_stock(product_id, body.stock, body.reason)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/catalog/{product_id}/quitar")
def post_catalog_hide(product_id: int) -> dict[str, Any]:
    try:
        return catalog.hide_product(product_id)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/catalog/{product_id}/foto")
async def post_foto(product_id: int, file: UploadFile = File(...)) -> dict[str, Any]:
    raw = await file.read()
    try:
        name = photo.save(product_id, raw)
        item = next(
            (p for p in catalog.list_products() if p["id"] == product_id),
            None,
        )
        if item is None:
            raise KeyError("ese producto ya no está")
        item["photo"] = name
        return item
    except Exception as e:
        raise _http(e) from e


@app.post("/api/local/logo")
async def post_local_logo(file: UploadFile = File(...)) -> dict[str, Any]:
    try:
        raw = await file.read()
        name = photo.save_logo(raw)
        data = store.local()
        data["logo"] = name
        return data
    except Exception as e:
        raise _http(e) from e


@app.delete("/api/local/logo")
def delete_local_logo() -> dict[str, Any]:
    try:
        photo.clear_logo()
        data = store.local()
        data["logo"] = ""
        return data
    except Exception as e:
        raise _http(e) from e


@app.get("/fotos/{name}")
def get_foto(name: str) -> FileResponse:
    try:
        if name.startswith("t"):
            path = tapa.resolve(name)
        else:
            path = photo.resolve(name)
    except Exception as e:
        raise _http(e) from e
    return FileResponse(path, media_type="image/jpeg", headers={"Cache-Control": "no-cache"})


@app.post("/api/sales")
def post_sale(body: SaleIn) -> dict[str, Any]:
    try:
        return sales.checkout(
            items=[i.model_dump() for i in body.items],
            pay_method=body.pay_method,
            note=body.note,
        )
    except Exception as e:
        raise _http(e) from e


@app.get("/api/sales/today")
def get_sales_today() -> list[dict[str, Any]]:
    return sales.today_sales()


@app.get("/api/sales/{sale_id}/pdf")
def get_sale_pdf(sale_id: int) -> Response:
    try:
        raw = comprobante.armar(sales.get(sale_id), store.local())
    except Exception as e:
        raise _http(e) from e
    return Response(
        content=raw,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="venta-{sale_id}.pdf"'},
    )


@app.post("/api/sales/{sale_id}/anular")
def post_sale_anular(sale_id: int) -> dict[str, Any]:
    try:
        return sales.void_sale(sale_id)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/taller/tapa")
async def post_tapa(file: UploadFile = File(...)) -> dict[str, Any]:
    raw = await file.read()
    try:
        return tapa.leer(raw)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/taller/foto")
async def post_foto(file: UploadFile = File(...)) -> dict[str, Any]:
    raw = await file.read()
    try:
        return tapa.empezar(raw)
    except Exception as e:
        raise _http(e) from e


@app.get("/api/taller/foto")
def get_foto_ultima() -> dict[str, Any]:
    got = tapa.ultima()
    return got or {"estado": "ninguna"}


@app.get("/api/taller/foto/{job_id}")
def get_foto(job_id: str) -> dict[str, Any]:
    try:
        return tapa.consultar(job_id)
    except Exception as e:
        raise _http(e) from e


@app.get("/api/taller")
def get_taller() -> dict[str, Any]:
    data = taller.board()
    data["piso"] = piso.snapshot()
    return data


@app.post("/api/taller")
def post_taller(body: OrderIn) -> dict[str, Any]:
    try:
        return taller.open_order(
            customer_name=body.customer_name,
            device=body.device,
            issue=body.issue,
            customer_phone=body.customer_phone,
            imei=body.imei,
            price_clp=body.price_clp,
            note=body.note,
            bench_id=body.bench_id,
            tech_id=body.tech_id,
            marca=body.marca,
            serial=body.serial,
            color=body.color,
            photo=body.photo,
        )
    except Exception as e:
        raise _http(e) from e


@app.post("/api/taller/{order_id}/mover")
def post_mover(order_id: int, body: MoveIn) -> dict[str, Any]:
    try:
        return taller.move(order_id, body.status, bench_id=body.bench_id, tech_id=body.tech_id)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/taller/{order_id}/cobrar")
def post_cobrar_orden(order_id: int, body: PayOrderIn) -> dict[str, Any]:
    try:
        return sales.checkout_service(order_id, body.pay_method)
    except Exception as e:
        raise _http(e) from e


@app.get("/api/taller/piso")
def get_piso() -> dict[str, Any]:
    return piso.snapshot()


@app.post("/api/taller/piso")
def post_piso(body: PisoIn) -> dict[str, Any]:
    try:
        return piso.set_benches(body.benches)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/taller/mesas/{bench_id}")
def post_mesa(bench_id: int, body: MesaIn) -> dict[str, Any]:
    try:
        return piso.move_bench(bench_id, body.x, body.y, body.name)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/taller/mesas/{bench_id}/tecnico")
def post_mesa_tecnico(bench_id: int, body: MesaTechIn) -> dict[str, Any]:
    try:
        return piso.assign_tech(bench_id, body.tech_id)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/taller/mesas/{bench_id}/stock")
def post_mesa_stock(bench_id: int, body: MesaStockIn) -> dict[str, Any]:
    try:
        return piso.mover_stock(bench_id, body.product_id, body.qty, body.reason)
    except Exception as e:
        raise _http(e) from e


@app.get("/api/taller/tecnicos")
def get_tecnicos() -> list[dict[str, Any]]:
    return piso.techs()


@app.post("/api/taller/tecnicos")
def post_tecnico(body: TechIn) -> dict[str, Any]:
    try:
        return piso.add_tech(body.name)
    except Exception as e:
        raise _http(e) from e


@app.post("/api/taller/tecnicos/{tech_id}")
def post_tecnico_edit(tech_id: int, body: TechIn) -> dict[str, Any]:
    try:
        return piso.set_tech(tech_id, name=body.name, active=body.active)
    except Exception as e:
        raise _http(e) from e


@app.get("/api/cifras")
def get_cifras(dias: int = 7) -> dict[str, Any]:
    return cifras.snapshot(dias)


@app.get("/api/hoy")
def get_hoy() -> dict[str, Any]:
    loc = store.local()
    sold = sales.today_sales()
    vivas = [s for s in sold if not int(s.get("voided") or 0)]
    board = taller.board()
    counts = taller.counts()
    por_pago = {m: 0 for m in store.PAY_METHODS}
    for s in vivas:
        por_pago[s["pay_method"]] = por_pago.get(s["pay_method"], 0) + s["total_clp"]
    return {
        "local": loc["name"],
        "ventas_n": len(vivas),
        "ventas_clp": sum(s["total_clp"] for s in vivas),
        "por_pago": por_pago,
        "taller": counts,
        "listos": board["listo"],
        "ultimas": sold[:8],
        "red_abiertos": market.open_count(),
    }


@app.get("/")
def index() -> FileResponse:
    return FileResponse(WEB / "index.html")


def _instalador() -> Path:
    return ROOT / "dist" / "A10-Instalador.exe"


def _mac_zip() -> Path:
    return ROOT / "dist" / "A10-Mac.zip"


@app.get("/centro")
def centro() -> FileResponse:
    return FileResponse(WEB / "centro.html")


@app.get("/api/centro")
def get_centro() -> dict[str, Any]:
    return parte.panel()


@app.get("/api/parte")
def get_parte() -> dict[str, Any]:
    return parte.snapshot()


@app.post("/api/parte")
def post_parte(request: Request, body: dict[str, Any]) -> dict[str, Any]:
    try:
        from edge import geoip

        visto = geoip.ip_pedido(
            request.headers, request.client.host if request.client else ""
        )
        parte.guardar(body, ip_visto=visto)
        return {
            "ok": True,
            "pago_url": pago.url(),
            "pago_hasta": pago.hasta_nodo(str(body.get("shop_code") or "")),
        }
    except Exception as e:
        raise _http(e) from e


class VidaIn(BaseModel):
    tipo: str = ""
    texto: str = ""


@app.post("/api/vida")
def post_vida(body: VidaIn) -> dict[str, Any]:
    try:
        return parte.anotar_vida(body.tipo, body.texto)
    except Exception as e:
        raise _http(e) from e


@app.get("/api/vida")
def get_vida() -> list[dict[str, Any]]:
    return parte.listar_vida()


@app.get("/descargar")
def descargar() -> FileResponse:
    return FileResponse(WEB / "descargar.html")


@app.get("/api/descargar")
def descargar_estado() -> dict[str, Any]:
    p = _instalador()
    n = p.stat().st_size if p.is_file() else 0
    mac = _mac_zip()
    m = mac.stat().st_size if mac.is_file() else 0
    return {
        "listo": p.is_file() and n > 0,
        "bytes": n,
        "version": store.version(),
        "mac": {"listo": mac.is_file() and m > 0, "bytes": m},
    }


@app.get("/api/respaldo")
def get_respaldo() -> FileResponse:
    try:
        stamp = datetime.now().strftime("%Y-%m-%d")
        dest = Path(tempfile.gettempdir()) / f"a10-{stamp}.db"
        store.backup_to(dest)
        return FileResponse(
            dest,
            filename=f"a10-{stamp}.db",
            media_type="application/octet-stream",
        )
    except Exception as e:
        raise _http(e) from e


@app.get("/descargar/A10-Instalador.exe")
def descargar_instalador() -> FileResponse:
    p = _instalador()
    if not p.is_file():
        raise HTTPException(status_code=404, detail="el instalador no está listo")
    return FileResponse(
        p,
        filename="A10-Instalador.exe",
        media_type="application/octet-stream",
    )


@app.get("/descargar/A10-Mac.zip")
def descargar_mac() -> FileResponse:
    p = _mac_zip()
    if not p.is_file():
        raise HTTPException(status_code=404, detail="el zip de Mac no está listo")
    return FileResponse(
        p,
        filename="A10-Mac.zip",
        media_type="application/zip",
    )


app.mount("/static", StaticFiles(directory=str(WEB)), name="static")
