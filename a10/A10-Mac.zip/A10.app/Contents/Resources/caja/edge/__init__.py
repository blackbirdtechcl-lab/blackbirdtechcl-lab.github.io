"""A10 edge — caja del local."""
