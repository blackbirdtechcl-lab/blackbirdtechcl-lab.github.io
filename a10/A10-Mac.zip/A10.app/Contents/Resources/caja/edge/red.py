"""La caja se anuncia sola en la wifi. El iPhone no escribe IPs."""
from __future__ import annotations

import logging
import os
import shutil
import socket
import subprocess
import sys
import threading
from typing import Any

log = logging.getLogger("a10.red")

SERVICE_TYPE = "_a10._tcp.local."
HOSTNAME = "a10.local"
DEFAULT_PORT = 5000

_lock = threading.Lock()
_stop = threading.Event()
_thread: threading.Thread | None = None
_proc: subprocess.Popen[bytes] | None = None
_port = DEFAULT_PORT
_ip = ""
_anunciada = False


def _apagada() -> bool:
    flag = (os.environ.get("A10_RED") or "").strip().lower()
    if flag in ("0", "off", "false", "no"):
        return True
    if os.environ.get("PYTEST_CURRENT_TEST"):
        return True
    if any("unittest" in a for a in sys.argv):
        return True
    return False


def puerto() -> int:
    raw = (os.environ.get("A10_PORT") or "").strip()
    if raw.isdigit():
        return int(raw)
    return DEFAULT_PORT


def lan_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("1.1.1.1", 80))
        ip = sock.getsockname()[0]
    except OSError:
        ip = "127.0.0.1"
    finally:
        sock.close()
    return ip or "127.0.0.1"


def snapshot() -> dict[str, Any]:
    with _lock:
        return {
            "host": HOSTNAME,
            "ip": _ip or lan_ip(),
            "port": _port or puerto(),
            "servicio": SERVICE_TYPE.rstrip("."),
            "anunciada": _anunciada,
        }


def _matar_proc() -> None:
    global _proc
    if _proc is None:
        return
    if _proc.poll() is None:
        _proc.terminate()
        try:
            _proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            _proc.kill()
    _proc = None


def _publicar(ip: str, port: int) -> None:
    global _proc, _anunciada, _ip, _port
    exe = shutil.which("dns-sd")
    if not exe or ip in ("", "127.0.0.1", "0.0.0.0"):
        log.warning("no pude anunciar la caja; sigue en :%s", port)
        return
    _matar_proc()
    _proc = subprocess.Popen(
        [
            exe,
            "-P",
            "caja",
            "_a10._tcp",
            "local",
            str(int(port)),
            HOSTNAME,
            ip,
            "rol=caja",
            "path=/",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    _anunciada = True
    _ip = ip
    _port = port
    log.info("caja anunciada %s:%s", ip, port)


def _ciclo() -> None:
    while not _stop.wait(4):
        ip = lan_ip()
        if ip in ("", "127.0.0.1", "0.0.0.0"):
            continue
        with _lock:
            if ip == _ip:
                continue
            try:
                _publicar(ip, _port)
            except Exception:
                log.exception("no pude mudar el anuncio")


def start(port: int | None = None) -> None:
    global _thread, _port
    if _apagada():
        return
    p = int(port or puerto())
    ip = lan_ip()
    with _lock:
        if _thread and _thread.is_alive():
            return
        _stop.clear()
        _port = p
        if ip not in ("", "127.0.0.1", "0.0.0.0"):
            try:
                _publicar(ip, p)
            except Exception:
                log.exception("el anuncio no arrancó")
        _thread = threading.Thread(target=_ciclo, name="a10-red", daemon=True)
        _thread.start()


def stop() -> None:
    global _thread, _ip, _anunciada
    _stop.set()
    with _lock:
        _matar_proc()
        _ip = ""
        _thread = None
        _anunciada = False
