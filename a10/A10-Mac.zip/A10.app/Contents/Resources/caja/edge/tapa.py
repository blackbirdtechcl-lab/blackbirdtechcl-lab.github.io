"""Foto de la tapa o de la pantalla → datos para la ficha de ingreso.

Acepta la parte de atrás o una captura de Ajustes / Información.
La lectura corre atrás: el que atiende puede cobrar o seguir.
No es boleta ni factura. Se confirma lo que A10 alcanzó a leer.
"""
from __future__ import annotations

import json
import re
import subprocess
import threading
import uuid
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageFilter, ImageOps, UnidentifiedImageError

from edge import db as store

MAX_BYTES = 8 * 1024 * 1024
FOTOS = store.ROOT / "data" / "fotos"
_NAME = re.compile(r"^t[0-9a-f]{8}\.jpg$")
_JOB = re.compile(r"^l[0-9a-f]{8}$")
_IMEI = re.compile(r"(?<!\d)(\d{15})(?!\d)")
_IMEI_LABELED = re.compile(
    r"imei\s*[12]?\s*[:\s]*([0-9][0-9\s\-]{13,22})",
    re.I,
)
_SERIAL = re.compile(
    r"(?:s/?n|serial(?:\s*(?:number|no\.?))?|n[úu]mero\s*de\s*serie)"
    r"[:\s]*([A-Z0-9]{8,14})",
    re.I,
)
_CAP = re.compile(r"\b((?:64|128|256|512)\s*GB|1\s*TB)\b", re.I)
_PHONE = re.compile(r"(?:\+?56[\s\-]*)?9[\s\-]?(?:\d[\s\-]?){8}")
_OWNER = re.compile(
    r"(?:iphone|galaxy|redmi|pixel|moto)\s+de\s+([A-ZÁÉÍÓÚÑ][\wáéíóúñ]{1,20})",
    re.I,
)
_OWNER_EN = re.compile(r"([A-Z][a-z]{1,20})'s\s+(?:iPhone|Galaxy|Pixel)", re.I)
_COLOR = re.compile(
    r"\b(negro|black|blanco|white|azul|blue|rojo|red|verde|green|"
    r"dorado|gold|plata|silver|gris|gray|grey|violeta|purple|rosa|pink)\b",
    re.I,
)

MARCAS = (
    ("iphone", "Apple"),
    ("ipad", "Apple"),
    ("apple", "Apple"),
    ("samsung", "Samsung"),
    ("galaxy", "Samsung"),
    ("xiaomi", "Xiaomi"),
    ("redmi", "Xiaomi"),
    ("poco", "Xiaomi"),
    ("motorola", "Motorola"),
    ("moto ", "Motorola"),
    ("huawei", "Huawei"),
    ("honor", "Honor"),
    ("oppo", "Oppo"),
    ("realme", "Realme"),
    ("vivo", "Vivo"),
    ("nokia", "Nokia"),
    ("sony", "Sony"),
    ("lg ", "LG"),
    ("google", "Google"),
    ("pixel", "Google"),
)

MODELOS = (
    "iPhone 16 Pro Max",
    "iPhone 16 Pro",
    "iPhone 16 Plus",
    "iPhone 16",
    "iPhone 15 Pro Max",
    "iPhone 15 Pro",
    "iPhone 15 Plus",
    "iPhone 15",
    "iPhone 14 Pro Max",
    "iPhone 14 Pro",
    "iPhone 14 Plus",
    "iPhone 14",
    "iPhone 13 Pro Max",
    "iPhone 13 Pro",
    "iPhone 13 mini",
    "iPhone 13",
    "iPhone 12 Pro Max",
    "iPhone 12 Pro",
    "iPhone 12 mini",
    "iPhone 12",
    "iPhone 11 Pro Max",
    "iPhone 11 Pro",
    "iPhone 11",
    "iPhone SE",
    "iPhone XR",
    "iPhone XS",
    "iPhone X",
    "Galaxy S24 Ultra",
    "Galaxy S24+",
    "Galaxy S24",
    "Galaxy S23 Ultra",
    "Galaxy S23",
    "Galaxy S22",
    "Galaxy A55",
    "Galaxy A54",
    "Galaxy A35",
    "Galaxy A34",
    "Galaxy A25",
    "Galaxy A24",
    "Galaxy A15",
    "Galaxy A14",
    "Redmi Note 13",
    "Redmi Note 12",
    "Redmi 13",
    "Poco X6",
    "Poco X5",
    "Moto G84",
    "Moto G54",
    "Moto G24",
    "Moto G14",
    "Pixel 8",
    "Pixel 7",
)


def dir_fotos() -> Path:
    FOTOS.mkdir(parents=True, exist_ok=True)
    return FOTOS  # tests pueden reasignar tapa.FOTOS


def normalize(raw: bytes) -> bytes:
    if not raw:
        raise ValueError("no hay foto")
    if len(raw) > MAX_BYTES:
        raise ValueError("la foto pesa más de 8 MB")
    try:
        im = Image.open(BytesIO(raw))
        im = ImageOps.exif_transpose(im)
    except (UnidentifiedImageError, OSError) as e:
        raise ValueError("ese archivo no es una foto") from e
    im = im.convert("RGB")
    w, h = im.size
    if w < 40 or h < 40:
        raise ValueError("la foto es demasiado chica")
    if max(w, h) > 1600:
        if w >= h:
            im = im.resize((1600, max(1, int(h * 1600 / w))), Image.Resampling.LANCZOS)
        else:
            im = im.resize((max(1, int(w * 1600 / h)), 1600), Image.Resampling.LANCZOS)
    out = BytesIO()
    im.save(out, format="JPEG", quality=88, optimize=True)
    return out.getvalue()


def save(raw: bytes) -> str:
    data = normalize(raw)
    name = f"t{uuid.uuid4().hex[:8]}.jpg"
    (dir_fotos() / name).write_bytes(data)
    return name


def resolve(name: str) -> Path:
    name = (name or "").strip()
    if not _NAME.match(name):
        raise KeyError("esa foto no está")
    path = dir_fotos() / name
    if not path.exists():
        raise KeyError("esa foto no está")
    return path


def imei_luhn(digits: str) -> bool:
    if len(digits) != 15 or not digits.isdigit():
        return False
    total = 0
    for i, ch in enumerate(digits[:14]):
        n = int(ch)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    check = (10 - (total % 10)) % 10
    return check == int(digits[14])


def _imeis(text: str) -> list[str]:
    found: list[str] = []
    for m in _IMEI_LABELED.finditer(text):
        digits = re.sub(r"\D", "", m.group(1))
        if len(digits) >= 15:
            cand = digits[:15]
            if cand not in found:
                found.append(cand)
    compact = re.sub(r"[\s\-]+", "", text)
    for m in _IMEI.findall(compact):
        if m not in found:
            found.append(m)
    return found


def _chile_phone(text: str) -> str:
    for m in _PHONE.finditer(text or ""):
        d = re.sub(r"\D", "", m.group(0))
        if d.startswith("56"):
            d = d[2:]
        if len(d) == 9 and d.startswith("9"):
            return d
    return ""


def _duenio(text: str) -> str:
    m = _OWNER.search(text or "")
    if m:
        return m.group(1).strip().title()
    m = _OWNER_EN.search(text or "")
    if m:
        return m.group(1).strip().title()
    return ""


def parse_text(text: str) -> dict:
    raw = (text or "").replace("\x00", " ")
    imeis = _imeis(raw)
    imei = ""
    for cand in imeis:
        if imei_luhn(cand):
            imei = cand
            break
    if not imei and imeis:
        imei = imeis[0]
    low = raw.lower()
    marca = ""
    for key, name in MARCAS:
        if key in low:
            marca = name
            break
    modelo = ""
    for name in MODELOS:
        if name.lower() in low:
            modelo = name
            break
    if not modelo:
        m = re.search(
            r"((?:iphone|galaxy|redmi|poco|moto|pixel)\s+[a-z0-9]{1,12}(?:\s*(?:pro|max|plus|ultra|mini))?)",
            low,
            re.I,
        )
        if m:
            modelo = re.sub(r"\s+", " ", m.group(1)).strip().title()
            modelo = modelo.replace("Iphone", "iPhone")
    serial = ""
    sm = _SERIAL.search(raw)
    if sm:
        serial = sm.group(1).upper()
    color = ""
    cm = _COLOR.search(raw)
    if cm:
        color = cm.group(1).lower()
    cap = ""
    gm = _CAP.search(raw)
    if gm:
        cap = re.sub(r"\s+", " ", gm.group(1)).upper().replace("GB", "GB").replace("TB", "TB")
        cap = re.sub(r"\s+", " ", cap)
    if modelo and cap and cap.lower() not in modelo.lower():
        modelo = f"{modelo} {cap}"
    return {
        "imei": imei,
        "marca": marca,
        "modelo": modelo,
        "serial": serial,
        "color": color,
        "capacidad": cap,
        "customer_name": _duenio(raw),
        "customer_phone": _chile_phone(raw),
    }


def _png_ocr(im) -> bytes:
    buf = BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue()


def _tesseract(png: bytes, lang: str) -> str:
    try:
        proc = subprocess.run(
            ["tesseract", "stdin", "stdout", "-l", lang, "--psm", "6"],
            input=png,
            capture_output=True,
            timeout=8,
        )
        if proc.returncode == 0:
            return proc.stdout.decode("utf-8", errors="replace")
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return ""


def _ocr(raw: bytes) -> str:
    try:
        im = Image.open(BytesIO(raw)).convert("L")
        im = ImageOps.autocontrast(im)
        im = im.filter(ImageFilter.SHARPEN)
        variants = [im, ImageOps.invert(im)]
    except Exception:
        return ""
    best = ""
    for shot in variants:
        png = _png_ocr(shot)
        for lang in ("spa+eng", "eng"):
            text = _tesseract(png, lang)
            if len(text.strip()) > len(best.strip()):
                best = text
            if _imeis(best) or _SERIAL.search(best):
                return best
    return best


def _avisos(fields: dict) -> list[str]:
    avisos: list[str] = []
    if not fields.get("imei"):
        avisos.append("No alcancé el IMEI. Complétalo a mano: son 15 dígitos.")
    elif not imei_luhn(fields["imei"]):
        avisos.append("El IMEI no cuadra. Revísalo antes de anotar.")
    if not fields.get("modelo"):
        avisos.append("No reconocí el modelo. Escríbelo como está en la tapa o en la pantalla.")
    return avisos


def _as_dict(row) -> dict:
    avisos = json.loads(row["avisos"] or "[]")
    return {
        "id": row["id"],
        "photo": row["photo"],
        "estado": row["estado"],
        "texto": row["texto"],
        "imei": row["imei"],
        "marca": row["marca"],
        "modelo": row["modelo"],
        "serial": row["serial"],
        "color": row["color"],
        "capacidad": row["capacidad"],
        "customer_name": row["customer_name"],
        "customer_phone": row["customer_phone"],
        "avisos": avisos,
    }


def consultar(job_id: str) -> dict:
    job_id = (job_id or "").strip()
    if not _JOB.match(job_id):
        raise KeyError("esa lectura no está")
    with store.db() as con:
        row = con.execute("SELECT * FROM lecturas WHERE id = ?", (job_id,)).fetchone()
    if not row:
        raise KeyError("esa lectura no está")
    return _as_dict(row)


def ultima() -> dict | None:
    with store.db() as con:
        row = con.execute("SELECT * FROM lecturas ORDER BY ts DESC LIMIT 1").fetchone()
    return _as_dict(row) if row else None


def _guardar(job_id: str, **fields) -> None:
    keys = ", ".join(f"{k} = ?" for k in fields)
    vals = list(fields.values()) + [job_id]
    with store.db() as con:
        con.execute(f"UPDATE lecturas SET {keys} WHERE id = ?", vals)


def _trabajar(job_id: str, raw: bytes) -> None:
    try:
        texto = _ocr(raw)
        fields = parse_text(texto)
        _guardar(
            job_id,
            estado="lista",
            texto=texto.strip(),
            imei=fields["imei"],
            marca=fields["marca"],
            modelo=fields["modelo"],
            serial=fields["serial"],
            color=fields["color"],
            capacidad=fields.get("capacidad") or "",
            customer_name=fields.get("customer_name") or "",
            customer_phone=fields.get("customer_phone") or "",
            avisos=json.dumps(_avisos(fields), ensure_ascii=False),
        )
    except Exception:
        _guardar(
            job_id,
            estado="fallo",
            avisos=json.dumps(["No pude leer la foto. Complétala a mano."], ensure_ascii=False),
        )


def empezar(raw: bytes) -> dict:
    photo = save(raw)
    job_id = f"l{uuid.uuid4().hex[:8]}"
    with store.db() as con:
        con.execute(
            "INSERT INTO lecturas (id, ts, photo, estado) VALUES (?, ?, ?, 'leyendo')",
            (job_id, store.now_iso(), photo),
        )
    threading.Thread(target=_trabajar, args=(job_id, raw), daemon=True).start()
    return consultar(job_id)


def leer(raw: bytes) -> dict:
    photo = save(raw)
    texto = _ocr(raw)
    fields = parse_text(texto)
    return {
        "photo": photo,
        "texto": texto.strip(),
        "avisos": _avisos(fields),
        **fields,
    }
