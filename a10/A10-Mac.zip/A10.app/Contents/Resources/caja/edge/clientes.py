"""Clientes que ya pasaron por servicio. No es una agenda aparte."""
from __future__ import annotations

from typing import Any

from edge import db as store


def listar() -> list[dict[str, Any]]:
    with store.db() as con:
        rows = con.execute(
            "SELECT TRIM(customer_name) AS name, TRIM(customer_phone) AS phone, "
            "COUNT(*) AS visitas, MAX(opened_at) AS ultima "
            "FROM service_orders "
            "WHERE TRIM(customer_name) != '' "
            "GROUP BY LOWER(TRIM(customer_name)), TRIM(customer_phone) "
            "ORDER BY ultima DESC"
        ).fetchall()
    return [store.row(r) for r in rows]
