"""Carga masiva al catálogo. Primero se lee, después se confirma."""
from __future__ import annotations

from typing import Any

from edge import catalog
from edge import codigo
from edge import db as store
from edge.inventario_parse import _es_total_linea, enrich, fold


def preview(parsed: dict[str, Any]) -> dict[str, Any]:
    lines = list(parsed.get("lines") or [])
    if not lines:
        raise ValueError(parsed.get("warnings") and parsed["warnings"][0] or "no hay líneas para cargar")
    cataloged = catalog.list_products()
    out = []
    for raw in lines:
        filled = enrich(raw)
        ref = catalog.clean_sku(str(filled.get("ref_code") or filled.get("sku") or ""))
        hit = _match(cataloged, {**filled, "ref_code": ref})
        qty = int(filled.get("qty") or 0)
        cost = filled.get("cost_clp")
        price = filled.get("price_clp")
        kind = filled.get("kind") or (hit["kind"] if hit else "repuesto")
        brand = filled.get("brand") or (hit["brand"] if hit else "")
        if cost is None and hit:
            cost = hit.get("cost_clp")
        if price is None and hit:
            old = int(hit.get("price_clp") or 0)
            if cost and qty and _es_total_linea(old, qty, int(cost)):
                price = None
            else:
                price = old or None
        if price is None and cost:
            price = _precio_desde_costo(int(cost), kind, cataloged)
        if qty <= 0 and (cost is not None or price is not None):
            qty = 1
        row = {
            "name": filled.get("name") or "",
            "sku": (hit["sku"] if hit else ""),
            "ref": ref,
            "barcode": (filled.get("barcode") or (hit.get("barcode") if hit else "") or ""),
            "brand": brand,
            "kind": kind,
            "qty": qty,
            "cost_clp": int(cost) if cost is not None else None,
            "price_clp": int(price) if price is not None else None,
            "note": filled.get("note") or "",
            "ubicacion": (hit.get("ubicacion") if hit else "") or "",
            "product_id": hit["id"] if hit else None,
            "action": "sumar" if hit else "nuevo",
            "stock_ahora": int(hit["stock"]) if hit else 0,
        }
        if not row["name"]:
            continue
        if row["qty"] <= 0 and row["cost_clp"] is None and row["price_clp"] is None:
            continue
        out.append(row)
    return {
        "lines": out,
        "nuevos": sum(1 for x in out if x["action"] == "nuevo"),
        "suman": sum(1 for x in out if x["action"] == "sumar"),
        "warnings": list(parsed.get("warnings") or []),
        "method": parsed.get("method") or "",
        "source": parsed.get("source") or "",
        "proveedor": str(parsed.get("proveedor") or ""),
        "folio": str(parsed.get("folio") or ""),
        "fecha": str(parsed.get("fecha") or ""),
    }


def apply(
    lines: list[dict[str, Any]],
    modo: str = "sumar",
    origen: str = "lista",
    proveedor: str = "",
    folio: str = "",
    fecha: str = "",
) -> dict[str, Any]:
    origen = (origen or "lista").strip().lower()
    if origen not in ("lista", "factura"):
        origen = "lista"
    if origen == "factura":
        modo = "sumar"
    if modo not in ("sumar", "reemplazar"):
        raise ValueError("el stock se suma o se reemplaza")
    if not lines:
        raise ValueError("no hay líneas de inventario para cargar")
    added = 0
    updated = 0
    errores: list[str] = []
    news: list[dict[str, Any]] = []
    with store.db() as con:
        cataloged = [
            store.row(r)
            for r in con.execute(
                "SELECT id, sku, name, brand, kind, stock, price_clp, cost_clp, barcode, ref_code "
                "FROM products WHERE active = 1"
            )
        ]
        for raw in lines:
            try:
                filled = enrich(raw)
                name = str(filled.get("name") or "").strip()
                if not name:
                    continue
                qty = max(0, int(filled.get("qty") or 0))
                kind = str(filled.get("kind") or "repuesto")
                if kind not in store.KINDS:
                    kind = "repuesto"
                brand = str(filled.get("brand") or "").strip()
                ref = catalog.clean_sku(str(raw.get("ref") or filled.get("ref_code") or filled.get("sku") or ""))
                barcode = str(filled.get("barcode") or "").strip()
                note = str(filled.get("note") or "").strip()
                ubicacion = str(raw.get("ubicacion") or filled.get("ubicacion") or "").strip()
                cost = filled.get("cost_clp")
                price = filled.get("price_clp")
                if price is None and cost:
                    price = _precio_desde_costo(int(cost), kind, cataloged)
                if qty <= 0 and (cost is not None or price is not None):
                    qty = 1
                pid = raw.get("product_id")
                row = None
                if pid:
                    row = con.execute(
                        "SELECT id, stock, price_clp, cost_clp, barcode, ref_code, brand, kind "
                        "FROM products WHERE id = ? AND active = 1",
                        (int(pid),),
                    ).fetchone()
                if row is None:
                    hit = _match(
                        cataloged,
                        {"name": name, "sku": ref, "ref_code": ref, "brand": brand, "barcode": barcode},
                    )
                    if hit:
                        row = con.execute(
                            "SELECT id, stock, price_clp, cost_clp, barcode, ref_code, brand, kind "
                            "FROM products WHERE id = ?",
                            (hit["id"],),
                        ).fetchone()
                if row is None:
                    news.append(
                        {
                            "name": name,
                            "kind": kind,
                            "brand": brand,
                            "ref": ref,
                            "barcode": barcode,
                            "note": note,
                            "ubicacion": ubicacion,
                            "qty": qty,
                            "cost": cost,
                            "price": price,
                        }
                    )
                    continue
                new_stock = qty if modo == "reemplazar" else int(row["stock"]) + qty
                new_price = int(price) if price is not None else int(row["price_clp"])
                new_cost = int(cost) if cost is not None else int(row["cost_clp"] or 0)
                new_bar = barcode or (row["barcode"] or "")
                new_ref = ref or (row["ref_code"] or "")
                new_brand = brand or (row["brand"] or "")
                new_kind = kind if kind in store.KINDS else (row["kind"] or "repuesto")
                if new_stock < 0:
                    raise ValueError("el stock no puede quedar negativo")
                con.execute(
                    "UPDATE products SET stock = ?, price_clp = ?, cost_clp = ?, barcode = ?, "
                    "ref_code = ?, brand = ?, kind = ?, ubicacion = COALESCE(NULLIF(?, ''), ubicacion) "
                    "WHERE id = ?",
                    (new_stock, new_price, new_cost, new_bar, new_ref, new_brand, new_kind, ubicacion, row["id"]),
                )
                reason = "factura" if origen == "factura" else "lista"
                doc = " ".join(x for x in (proveedor.strip(), folio.strip(), fecha.strip()) if x)
                catalog.registrar_movimiento(
                    con,
                    row["id"],
                    qty if modo == "reemplazar" else qty,
                    new_stock,
                    reason,
                    doc or name,
                )
                updated += 1
            except Exception as e:
                errores.append(f"{raw.get('name') or '?'}: {e}")
        if origen == "factura":
            doc = " ".join(x for x in (proveedor.strip(), folio.strip()) if x)
            store.event(con, f"Factura {doc}: {len(news)} nuevos, {updated} con stock.".strip())
        else:
            store.event(con, f"Inventario: {len(news)} nuevos, {updated} con stock.")
    for item in news:
        try:
            if item["price"] is None:
                raise ValueError("falta el precio de venta")
            doc = " ".join(x for x in (proveedor.strip(), folio.strip(), fecha.strip()) if x)
            catalog.add_product(
                name=item["name"],
                kind=item["kind"],
                price_clp=int(item["price"]),
                stock=item["qty"],
                brand=item["brand"],
                sku="",
                cost_clp=int(item["cost"] or 0),
                barcode=item.get("barcode") or "",
                note=item.get("note") or "",
                ref_code=item.get("ref") or "",
                ubicacion=item.get("ubicacion") or "",
                reason="factura" if origen == "factura" else "alta",
                detail=doc or item["name"],
            )
            added += 1
        except Exception as e:
            errores.append(f"{item['name']}: {e}")
    if not added and not updated:
        raise ValueError(errores[0] if errores else "no se pudo cargar ningún producto")
    return {"ok": True, "nuevos": added, "suman": updated, "errores": errores}


def _match(cataloged: list[dict[str, Any]], raw: dict[str, Any]) -> dict[str, Any] | None:
    ref = catalog.clean_sku(str(raw.get("ref_code") or raw.get("ref") or raw.get("sku") or ""))
    bar = str(raw.get("barcode") or "").strip()
    if ref:
        for p in cataloged:
            if catalog.clean_sku(p.get("ref_code") or "") == ref:
                return p
            if not codigo.es_codigo_a10(str(p.get("sku") or "")) and catalog.clean_sku(p.get("sku") or "") == ref:
                return p
    if bar:
        for p in cataloged:
            if str(p.get("barcode") or "").strip() == bar:
                return p
    name_key = fold(raw.get("name") or "")
    brand_key = fold(raw.get("brand") or "")
    if not name_key:
        return None
    named = [p for p in cataloged if fold(p.get("name") or "") == name_key]
    if brand_key:
        for p in named:
            if fold(p.get("brand") or "") == brand_key:
                return p
    if named:
        return named[0]
    return None


def _precio_desde_costo(cost: int, kind: str, cataloged: list[dict[str, Any]]) -> int:
    ratios: list[float] = []
    for p in cataloged:
        if p.get("kind") != kind:
            continue
        c = int(p.get("cost_clp") or 0)
        pr = int(p.get("price_clp") or 0)
        if c > 0 and pr > c:
            ratios.append(pr / c)
    if ratios:
        ratios.sort()
        ratio = ratios[len(ratios) // 2]
    else:
        try:
            pct = float(store.local().get("margin_pct") or 100)
        except Exception:
            pct = 100
        ratio = 1 + max(0, pct) / 100
    n = int(round(cost * ratio))
    if n < 100:
        n = max(100, cost)
    return n if n % 10 == 0 else n - (n % 10) + 10
