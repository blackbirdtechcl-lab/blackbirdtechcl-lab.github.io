"""Cifras del local: venta, costo, taller y mesas. Para quien lleva el negocio."""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

from edge import db as store
from edge import market
from edge import piso
from edge import sales
from edge import taller


def _since(days: int) -> str:
    d = datetime.now() - timedelta(days=max(1, days) - 1)
    return d.strftime("%Y-%m-%d")


def snapshot(days: int = 7) -> dict[str, Any]:
    days = 7 if days not in (1, 7, 30) else days
    start = _since(days)
    loc = store.local()
    alert = max(0, int(loc.get("stock_alert") or 2))
    floor = piso.snapshot()
    today = sales.today_sales()
    board = taller.board()
    counts = taller.counts()
    with store.db() as con:
        sold = [
            store.row(r)
            for r in con.execute(
                "SELECT id, ts, total_clp, pay_method, order_id, "
                "COALESCE(voided, 0) AS voided FROM sales "
                "WHERE ts >= ? ORDER BY id DESC",
                (start,),
            )
        ]
        cost_rows = con.execute(
            "SELECT si.qty, si.price_clp, COALESCE(p.cost_clp, 0) AS cost_clp, "
            "si.product_id FROM sale_items si "
            "JOIN sales s ON s.id = si.sale_id "
            "LEFT JOIN products p ON p.id = si.product_id "
            "WHERE s.ts >= ? AND COALESCE(s.voided, 0) = 0",
            (start,),
        ).fetchall()
        inv = con.execute(
            "SELECT COALESCE(SUM(stock * price_clp), 0) AS venta, "
            "COALESCE(SUM(stock * cost_clp), 0) AS costo, "
            "COALESCE(SUM(stock), 0) AS unidades, "
            "COUNT(*) AS productos, "
            "SUM(CASE WHEN stock <= ? AND active = 1 THEN 1 ELSE 0 END) AS bajos, "
            "SUM(CASE WHEN TRIM(COALESCE(ubicacion, '')) = '' AND active = 1 THEN 1 ELSE 0 END) AS sin_sitio "
            "FROM products WHERE active = 1",
            (alert,),
        ).fetchone()
        bajos = [
            store.row(r)
            for r in con.execute(
                "SELECT id, name, stock, price_clp, cost_clp FROM products "
                "WHERE active = 1 AND stock <= ? ORDER BY stock, name LIMIT 12",
                (alert,),
            )
        ]
        eventos = [
            store.row(r)
            for r in con.execute(
                "SELECT ts, ok, text FROM events ORDER BY id DESC LIMIT 18"
            )
        ]
        movimientos = [
            store.row(r)
            for r in con.execute(
                "SELECT m.ts, m.qty, m.stock_after, m.reason, m.detail, p.name, p.sku "
                "FROM inventory_moves m JOIN products p ON p.id = m.product_id "
                "ORDER BY m.id DESC LIMIT 14"
            )
        ]
        por_tech = [
            store.row(r)
            for r in con.execute(
                "SELECT t.id, t.name, "
                "COALESCE(SUM(CASE WHEN o.status IN ('llego','en_mesa','listo') THEN 1 ELSE 0 END), 0) AS abiertas, "
                "COALESCE(SUM(CASE WHEN o.status = 'entregado' AND o.delivered_at >= ? THEN 1 ELSE 0 END), 0) AS entregadas "
                "FROM technicians t "
                "LEFT JOIN service_orders o ON o.tech_id = t.id "
                "WHERE t.active = 1 GROUP BY t.id ORDER BY t.id",
                (start,),
            )
        ]
        sin_tech = con.execute(
            "SELECT COUNT(*) AS n FROM service_orders "
            "WHERE status IN ('llego','en_mesa','listo') AND (tech_id IS NULL OR tech_id = 0)"
        ).fetchone()["n"]

    vivas = [s for s in sold if not int(s.get("voided") or 0)]
    venta = sum(int(s["total_clp"]) for s in vivas)
    costo = 0
    for r in cost_rows:
        if r["product_id"]:
            costo += int(r["cost_clp"] or 0) * int(r["qty"] or 0)
    margen = venta - costo
    por_pago = {m: 0 for m in store.PAY_METHODS}
    for s in vivas:
        por_pago[s["pay_method"]] = por_pago.get(s["pay_method"], 0) + int(s["total_clp"])
    listos = board.get("listo") or []
    return {
        "local": loc["name"],
        "days": days,
        "ventas_n": len(vivas),
        "ventas_clp": venta,
        "costo_clp": costo,
        "margen_clp": margen,
        "por_pago": por_pago,
        "hoy": {
            "ventas_n": len([s for s in today if not int(s.get("voided") or 0)]),
            "ventas_clp": sum(s["total_clp"] for s in today if not int(s.get("voided") or 0)),
        },
        "inventario": {
            "venta_clp": int(inv["venta"] or 0),
            "costo_clp": int(inv["costo"] or 0),
            "unidades": int(inv["unidades"] or 0),
            "productos": int(inv["productos"] or 0),
            "bajos": int(inv["bajos"] or 0),
            "sin_sitio": int(inv["sin_sitio"] or 0),
            "alerta": alert,
        },
        "bajos": bajos,
        "taller": {
            **counts,
            "abiertos": (counts.get("llego") or 0)
            + (counts.get("en_mesa") or 0)
            + (counts.get("listo") or 0),
            "listos": len(listos),
        },
        "piso": {
            "mesas": floor["n_benches"],
            "tecnicos": floor["n_techs"],
            "lights": floor["lights"],
            "cola": len(floor["cola"]),
        },
        "tecnicos": por_tech,
        "sin_tecnico": sin_tech,
        "red_abiertos": market.open_count(),
        "eventos": eventos,
        "movimientos": movimientos,
        "ultimas": sold[:8],
        "ventas": sold,
        "atencion": _atencion(
            listos=listos,
            sin_tech=sin_tech,
            bajos=int(inv["bajos"] or 0),
            sin_sitio=int(inv["sin_sitio"] or 0),
            red=market.open_count(),
            cola=len(floor["cola"]),
        ),
    }


def _atencion(*, listos, sin_tech, bajos, sin_sitio, red, cola) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    n_listos = len(listos)
    if n_listos:
        out.append({
            "go": "taller",
            "n": n_listos,
            "titulo": "Listos para entregar",
            "detalle": "El cliente puede pasar a buscar el equipo.",
        })
    if cola:
        out.append({
            "go": "taller",
            "n": cola,
            "titulo": "Sin mesa",
            "detalle": "Llegaron y todavía no tienen banco.",
        })
    if sin_tech:
        out.append({
            "go": "taller",
            "n": sin_tech,
            "titulo": "Sin técnico",
            "detalle": "Órdenes abiertas que nadie tomó.",
        })
    if bajos:
        out.append({
            "go": "inventario",
            "flag": "bajos",
            "n": bajos,
            "titulo": "Stock bajo",
            "detalle": "Pedir o contar antes de vender de más.",
        })
    if sin_sitio:
        out.append({
            "go": "inventario",
            "flag": "sitio",
            "n": sin_sitio,
            "titulo": "Sin ubicación",
            "detalle": "Están en el sistema, no se sabe en qué cajón.",
        })
    if red:
        out.append({
            "go": "compras",
            "n": red,
            "titulo": "Pedidos entre locales",
            "detalle": "Hay un trámite abierto con otro mostrador.",
        })
    return out
