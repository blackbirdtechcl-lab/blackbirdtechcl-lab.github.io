"""Escucha el parte de otras cajas. No es el mostrador. El cobro no pasa por acá."""
from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse

from edge import db as store
from edge import parte

ROOT = store.ROOT
WEB = ROOT / "web"

app = FastAPI(title="A10 centro", version="0.1.0")


@app.on_event("startup")
def _boot() -> None:
    store.init_db()


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"ok": True, "centro": True}


@app.post("/api/parte")
def post_parte(body: dict[str, Any], x_a10: str = Header(default="")) -> dict[str, Any]:
    tok = parte.clave()
    if tok and (x_a10 or "").strip() != tok:
        raise HTTPException(status_code=403, detail="esa caja no está autorizada")
    try:
        parte.guardar(body)
        return {"ok": True}
    except Exception as e:
        if isinstance(e, ValueError):
            raise HTTPException(status_code=400, detail=str(e)) from e
        raise HTTPException(status_code=500, detail=str(e)) from e


@app.get("/api/centro")
def get_centro() -> dict[str, Any]:
    return parte.panel()


@app.get("/centro")
def pagina() -> FileResponse:
    return FileResponse(WEB / "centro.html")


@app.get("/")
def raiz() -> FileResponse:
    return FileResponse(WEB / "centro.html")
