"""Escucha el parte de otras cajas. No es el mostrador. El cobro no pasa por acá."""
from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse

from edge import db as store
from edge import pago
from edge import parte

ROOT = store.ROOT
WEB = ROOT / "web"

app = FastAPI(title="A10 centro", version="0.1.0")


@app.on_event("startup")
def _boot() -> None:
    store.init_db()


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"ok": True, "centro": True}


@app.post("/api/parte")
def post_parte(request: Request, body: dict[str, Any], x_a10: str = Header(default="")) -> dict[str, Any]:
    tok = parte.clave()
    if tok and (x_a10 or "").strip() != tok:
        raise HTTPException(status_code=403, detail="esa caja no está autorizada")
    try:
        from edge import geoip

        visto = geoip.ip_pedido(
            request.headers, request.client.host if request.client else ""
        )
        parte.guardar(body, ip_visto=visto)
        return {
            "ok": True,
            "pago_url": pago.url(),
            "pago_hasta": pago.hasta_nodo(str(body.get("shop_code") or "")),
        }
    except Exception as e:
        if isinstance(e, ValueError):
            raise HTTPException(status_code=400, detail=str(e)) from e
        raise HTTPException(status_code=500, detail=str(e)) from e


@app.get("/api/pago")
def get_pago() -> dict[str, Any]:
    st = pago.estado()
    st["ok"] = True
    return st


@app.post("/api/pago/url")
def post_pago_url(body: dict[str, Any]) -> dict[str, Any]:
    try:
        u = pago.guardar_url(str(body.get("url") or ""))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    return {"ok": True, "url": u}


@app.post("/api/pago/mes")
def post_pago_mes(body: dict[str, Any]) -> dict[str, Any]:
    code = str((body or {}).get("shop_code") or "").strip()
    try:
        hasta = pago.marcar_nodo(code) if code else pago.marcar_mes()
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    return {"ok": True, "hasta": hasta}


@app.get("/api/centro")
def get_centro() -> dict[str, Any]:
    return parte.panel()


@app.get("/centro")
def pagina() -> FileResponse:
    return FileResponse(WEB / "centro.html")


@app.get("/")
def raiz() -> FileResponse:
    return FileResponse(WEB / "centro.html")
