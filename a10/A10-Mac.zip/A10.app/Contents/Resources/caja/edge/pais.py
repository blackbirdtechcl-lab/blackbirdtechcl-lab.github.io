"""País e idioma de esta caja. El comprobante sigue el formato local.

No se conecta a ningún SII, SUNAT, SAT, DIAN, AFIP ni SENIAT.
El PDF es un comprobante de prueba, no un documento tributario.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from edge import db as store

PAISES = {
    "CL": {
        "nombre": "Chile",
        "moneda": "CLP",
        "simbolo": "$",
        "id_fiscal": "RUT",
        "doc": "Comprobante de venta",
        "aviso": "No es boleta ni factura del SII. Queda en esta caja para la prueba.",
    },
    "PE": {
        "nombre": "Perú",
        "moneda": "PEN",
        "simbolo": "S/",
        "id_fiscal": "RUC",
        "doc": "Comprobante de venta",
        "aviso": "No es boleta ni factura de SUNAT. Queda en esta caja para la prueba.",
    },
    "CO": {
        "nombre": "Colombia",
        "moneda": "COP",
        "simbolo": "$",
        "id_fiscal": "NIT",
        "doc": "Comprobante de venta",
        "aviso": "No es factura electrónica de la DIAN. Queda en esta caja para la prueba.",
    },
    "MX": {
        "nombre": "México",
        "moneda": "MXN",
        "simbolo": "$",
        "id_fiscal": "RFC",
        "doc": "Comprobante de venta",
        "aviso": "No es CFDI ni factura del SAT. Queda en esta caja para la prueba.",
    },
    "AR": {
        "nombre": "Argentina",
        "moneda": "ARS",
        "simbolo": "$",
        "id_fiscal": "CUIT",
        "doc": "Comprobante de venta",
        "aviso": "No es factura de AFIP. Queda en esta caja para la prueba.",
    },
    "VE": {
        "nombre": "Venezuela",
        "moneda": "VES",
        "simbolo": "Bs.",
        "id_fiscal": "RIF",
        "doc": "Comprobante de venta",
        "aviso": "No es factura de SENIAT. Queda en esta caja para la prueba.",
    },
    "EC": {
        "nombre": "Ecuador",
        "moneda": "USD",
        "simbolo": "US$",
        "id_fiscal": "RUC",
        "doc": "Comprobante de venta",
        "aviso": "No es factura del SRI. Queda en esta caja para la prueba.",
    },
    "BO": {
        "nombre": "Bolivia",
        "moneda": "BOB",
        "simbolo": "Bs",
        "id_fiscal": "NIT",
        "doc": "Comprobante de venta",
        "aviso": "No es factura del SIAT. Queda en esta caja para la prueba.",
    },
    "PA": {
        "nombre": "Panamá",
        "moneda": "PAB",
        "simbolo": "B/.",
        "id_fiscal": "RUC",
        "doc": "Comprobante de venta",
        "aviso": "No es factura de la DGI. Queda en esta caja para la prueba.",
    },
    "BR": {
        "nombre": "Brasil",
        "moneda": "BRL",
        "simbolo": "R$",
        "id_fiscal": "CNPJ",
        "doc": "Comprovante de venda",
        "aviso": "Não é nota fiscal da SEFAZ. Fica nesta caixa para a prova.",
    },
}
IDIOMAS = {
    "es": "Español",
    "pt": "Português",
    "en": "English",
    "zh": "中文",
    "ar": "العربية",
}


def archivo() -> Path:
    return store.ROOT / "pais.json"


def normalizar(code: str) -> str:
    c = (code or "").strip().upper()
    return c if c in PAISES else "CL"


def idioma_ok(code: str) -> str:
    c = (code or "").strip().lower()
    return c if c in IDIOMAS else "es"


def pack(code: str | None = None) -> dict[str, Any]:
    p = PAISES[normalizar(code or actual().get("pais"))]
    return dict(p)


def actual() -> dict[str, Any]:
    loc = store.local()
    code = normalizar(loc.get("pais") or "")
    lang = idioma_ok(loc.get("idioma") or "")
    p = dict(PAISES[code])
    p["pais"] = code
    p["idioma"] = lang
    p["idioma_lbl"] = IDIOMAS[lang]
    p["tax_id"] = (loc.get("tax_id") or "").strip()
    return p


def dinero(n: int, code: str | None = None) -> str:
    p = pack(code)
    v = int(n or 0)
    cuerpo = f"{abs(v):,}".replace(",", ".")
    signo = "-" if v < 0 else ""
    return f"{signo}{p['simbolo']}{cuerpo}"


def leer_archivo() -> dict[str, str]:
    p = archivo()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {
        "pais": normalizar(str(data.get("pais") or "")),
        "idioma": idioma_ok(str(data.get("idioma") or "")),
    }


def escribir_archivo(pais: str, idioma: str) -> Path:
    dest = archivo()
    dest.write_text(
        json.dumps(
            {"pais": normalizar(pais), "idioma": idioma_ok(idioma)},
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return dest


def aplicar_archivo() -> None:
    got = leer_archivo()
    if not got:
        return
    store.set_local(pais=got["pais"], idioma=got["idioma"])
