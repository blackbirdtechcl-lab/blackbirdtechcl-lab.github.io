"""Parte de cada caja: se arma aquí y vuela en el check-in. El cobro no espera."""
from __future__ import annotations

import json
import logging
import os
import socket
import threading
import time
import urllib.error
import urllib.request
from typing import Any

from edge import cifras
from edge import clientes
from edge import db as store
from edge import geoip
from edge import red as redmod

log = logging.getLogger("a10.parte")

_lock = threading.Lock()
_accesos: dict[tuple[str, str], dict[str, Any]] = {}
_last_guardar = 0.0
_last_enviar = 0.0
_ip_pub = ""
_ip_pub_ts = 0.0

_SKIP = {
    "/api/health",
    "/api/pulso",
    "/favicon.ico",
    "/api/parte",
    "/api/centro",
    "/api/vida",
}
_VIDA = {"aviso", "pantalla", "cobro", "scan", "tapa", "ticket", "puerta"}


def _urls() -> list[str]:
    if "A10_CENTRO_URL" in os.environ:
        u = (os.environ.get("A10_CENTRO_URL") or "").strip().rstrip("/")
        return [u] if u else []
    found: list[str] = []
    p = store.ROOT / "CENTRO"
    if p.is_file():
        try:
            text = p.read_text(encoding="utf-8")
        except OSError:
            text = ""
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if not line.lower().startswith("http"):
                continue
            u = line.rstrip("/")
            if u not in found:
                found.append(u)
    loc = (store.local().get("centro_url") or "").strip().rstrip("/")
    if loc and loc not in found:
        found.append(loc)
    return found


def centro_url() -> str:
    urls = _urls()
    return urls[0] if urls else ""


def clave() -> str:
    if "A10_CENTRO_CLAVE" in os.environ:
        return (os.environ.get("A10_CENTRO_CLAVE") or "").strip()
    p = store.ROOT / "CENTRO.clave"
    try:
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                return line
    except OSError:
        return ""
    return ""


def anotar_vida(tipo: str, texto: str) -> dict[str, Any]:
    tipo = (tipo or "").strip().lower()
    if tipo not in _VIDA:
        raise ValueError("ese aviso no se anota")
    texto = (texto or "").strip()[:180]
    if not texto:
        raise ValueError("falta qué pasó")
    ts = store.now_iso()
    with store.db() as con:
        con.execute(
            "INSERT INTO vida (ts, tipo, texto) VALUES (?, ?, ?)",
            (ts, tipo, texto),
        )
        n = con.execute("SELECT COUNT(*) AS n FROM vida").fetchone()["n"]
        extra = int(n) - 80
        if extra > 0:
            con.execute(
                "DELETE FROM vida WHERE id IN (SELECT id FROM vida ORDER BY id ASC LIMIT ?)",
                (extra,),
            )
    return {"ts": ts, "tipo": tipo, "texto": texto}


def listar_vida(limite: int = 40) -> list[dict[str, Any]]:
    n = max(1, min(int(limite or 40), 80))
    with store.db() as con:
        rows = con.execute(
            "SELECT ts, tipo, texto FROM vida ORDER BY id DESC LIMIT ?", (n,)
        ).fetchall()
    return [store.row(r) for r in rows]


def notar(path: str, ip: str, ua: str) -> None:
    if not path or path.startswith("/static"):
        return
    if path in _SKIP:
        return
    ip = (ip or "").strip()
    if not ip or ip in ("127.0.0.1", "::1"):
        return
    ua = (ua or "").strip()[:120]
    key = (ip, ua)
    ahora = store.now_iso()
    with _lock:
        cur = _accesos.get(key)
        if cur is None:
            _accesos[key] = {"ip": ip, "ua": ua, "n": 1, "primero": ahora, "ultimo": ahora}
        else:
            cur["n"] = int(cur["n"]) + 1
            cur["ultimo"] = ahora


def dispositivos() -> list[dict[str, Any]]:
    with _lock:
        mem = list(_accesos.values())
    with store.db() as con:
        rows = [
            store.row(r)
            for r in con.execute(
                "SELECT ip, ua, n, primero, ultimo FROM accesos ORDER BY ultimo DESC LIMIT 40"
            )
        ]
    seen: set[tuple[str, str]] = set()
    out: list[dict[str, Any]] = []
    for d in sorted(mem, key=lambda x: x.get("ultimo") or "", reverse=True) + rows:
        key = (str(d.get("ip") or ""), str(d.get("ua") or ""))
        if key in seen:
            continue
        seen.add(key)
        out.append(d)
        if len(out) >= 24:
            break
    return out


def _volcar_accesos() -> None:
    with _lock:
        items = list(_accesos.values())
    if not items:
        return
    with store.db() as con:
        for d in items:
            con.execute(
                "INSERT INTO accesos (ip, ua, n, primero, ultimo) VALUES (?, ?, ?, ?, ?) "
                "ON CONFLICT(ip, ua) DO UPDATE SET "
                "n = accesos.n + excluded.n, ultimo = excluded.ultimo",
                (d["ip"], d["ua"], int(d["n"]), d["primero"], d["ultimo"]),
            )
    with _lock:
        _accesos.clear()


def ip_publica(timeout: float = 1.5) -> str:
    global _ip_pub, _ip_pub_ts
    if _ip_pub and (time.time() - _ip_pub_ts) < 600:
        return _ip_pub
    try:
        req = urllib.request.Request(
            "https://1.1.1.1/cdn-cgi/trace",
            headers={"User-Agent": "A10"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            text = r.read().decode("ascii", "replace")
        for line in text.splitlines():
            if line.startswith("ip="):
                _ip_pub = line[3:].strip()
                _ip_pub_ts = time.time()
                return _ip_pub
    except (OSError, urllib.error.URLError):
        return _ip_pub
    return _ip_pub


def _promedio(venta: int, n: int) -> int:
    if n <= 0:
        return 0
    return int(venta // n)


def snapshot(*, ping_pub: bool = False) -> dict[str, Any]:
    loc = store.local()
    c1 = cifras.snapshot(1)
    c7 = cifras.snapshot(7)
    c30 = cifras.snapshot(30)
    cli = clientes.listar()
    red = redmod.snapshot()
    visitas = sum(int(c.get("visitas") or 0) for c in cli)
    pub = ip_publica() if ping_pub else _ip_pub
    from edge import sistema

    loc_imp = loc.get("printer_name") or ""
    try:
        sis = sistema.informe()
        arriendo = sistema.estado_arriendo(ping=False)
    except Exception:
        sis = {"ok": True, "piezas": []}
        arriendo = {"piloto": store.es_instalado(), "expired": False}
    cuerpo = {
        "shop_code": loc.get("shop_code") or "",
        "name": loc.get("name") or "Mi local",
        "pais": loc.get("pais") or "CL",
        "idioma": loc.get("idioma") or "es",
        "version": store.version(),
        "piloto": store.es_instalado(),
        "visto": store.now_iso(),
        "host": socket.gethostname(),
        "geo": {
            "lat": loc.get("lat"),
            "lng": loc.get("lng"),
            "address": loc.get("address") or "",
            "city": loc.get("city") or "",
            "comuna": loc.get("comuna") or "",
        },
        "red": {
            "ip_lan": red.get("ip") or "",
            "ip_pub": pub or "",
            "host": red.get("host") or "",
            "puerto": red.get("port") or 0,
        },
        "hoy": c1.get("hoy") or {},
        "d7": {
            "ventas_n": c7.get("ventas_n") or 0,
            "ventas_clp": c7.get("ventas_clp") or 0,
            "margen_clp": c7.get("margen_clp") or 0,
            "por_pago": c7.get("por_pago") or {},
        },
        "d30": {
            "ventas_n": c30.get("ventas_n") or 0,
            "ventas_clp": c30.get("ventas_clp") or 0,
            "margen_clp": c30.get("margen_clp") or 0,
        },
        "inventario": c1.get("inventario") or {},
        "bajos": c1.get("bajos") or [],
        "taller": c1.get("taller") or {},
        "poblacion": {
            "clientes": len(cli),
            "visitas": visitas,
            "ticket_promedio": _promedio(int(c30.get("ventas_clp") or 0), int(c30.get("ventas_n") or 0)),
            "comuna": loc.get("comuna") or "",
            "city": loc.get("city") or "",
        },
        "dispositivos": dispositivos(),
        "atencion": c1.get("atencion") or [],
        "vida": listar_vida(40),
        "sistema": sis,
        "arriendo": {
            "piloto": bool(arriendo.get("piloto")),
            "expired": bool(arriendo.get("expired")),
            "quedan_s": arriendo.get("quedan_s"),
        },
        "impresora": loc_imp,
        "suscripcion": {
            "url": "",
            "hasta": "",
            "quedan_d": None,
            "vencido": False,
        },
    }
    try:
        from edge import pago

        cuerpo["suscripcion"] = pago.estado(piloto=store.es_instalado())
    except Exception:
        pass
    return cuerpo


def guardar(parte: dict[str, Any], ip_visto: str = "") -> None:
    code = (parte.get("shop_code") or "").strip()
    if not code:
        raise ValueError("falta el código del local")
    parte = geoip.marcar(parte, ip_visto)
    geo = parte.get("geo") or {}
    red = parte.get("red") or {}
    blob = json.dumps(parte, ensure_ascii=False)
    sub = parte.get("suscripcion") or {}
    hasta = (sub.get("hasta") or "").strip()
    with store.db() as con:
        con.execute(
            "INSERT INTO nodos (shop_code, name, address, city, comuna, lat, lng, "
            "ip_lan, ip_pub, version, visto, parte, pago_hasta) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(shop_code) DO UPDATE SET "
            "name = excluded.name, address = excluded.address, city = excluded.city, "
            "comuna = excluded.comuna, lat = excluded.lat, lng = excluded.lng, "
            "ip_lan = excluded.ip_lan, ip_pub = excluded.ip_pub, "
            "version = excluded.version, visto = excluded.visto, parte = excluded.parte, "
            "pago_hasta = CASE WHEN excluded.pago_hasta != '' THEN excluded.pago_hasta "
            "ELSE nodos.pago_hasta END",
            (
                code,
                (parte.get("name") or "")[:80],
                (geo.get("address") or "")[:160],
                (geo.get("city") or "")[:80],
                (geo.get("comuna") or "")[:80],
                geo.get("lat"),
                geo.get("lng"),
                (red.get("ip_lan") or "")[:64],
                (red.get("ip_pub") or "")[:64],
                (parte.get("version") or "")[:20],
                parte.get("visto") or store.now_iso(),
                blob,
                hasta,
            ),
        )


def listar() -> list[dict[str, Any]]:
    with store.db() as con:
        rows = con.execute(
            "SELECT shop_code, name, address, city, comuna, lat, lng, "
            "ip_lan, ip_pub, version, visto, parte, pago_hasta FROM nodos ORDER BY visto DESC"
        ).fetchall()
    out: list[dict[str, Any]] = []
    for r in rows:
        d = store.row(r)
        raw = d.pop("parte", "") or ""
        try:
            cuerpo = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            cuerpo = {}
        if isinstance(cuerpo, dict) and cuerpo:
            cuerpo.setdefault("shop_code", d["shop_code"])
            sub = cuerpo.get("suscripcion") if isinstance(cuerpo.get("suscripcion"), dict) else {}
            if d.get("pago_hasta"):
                sub = dict(sub or {})
                sub["hasta"] = d["pago_hasta"]
                cuerpo["suscripcion"] = sub
            out.append(geoip.marcar(cuerpo, str(d.get("ip_pub") or "")))
        else:
            out.append(d)
    return out


def enviar(parte: dict[str, Any]) -> bool:
    ok = False
    body = json.dumps(parte, ensure_ascii=False).encode("utf-8")
    for url in _urls():
        dest = url if url.endswith("/api/parte") else url + "/api/parte"
        headers = {"Content-Type": "application/json", "User-Agent": "A10"}
        tok = clave()
        if tok:
            headers["X-A10"] = tok
        req = urllib.request.Request(
            dest,
            data=body,
            method="POST",
            headers=headers,
        )
        try:
            with urllib.request.urlopen(req, timeout=2.5) as r:
                if 200 <= r.status < 300:
                    ok = True
                    try:
                        resp = json.loads(r.read().decode("utf-8") or "{}")
                    except Exception:
                        resp = {}
                    if isinstance(resp, dict):
                        _aplicar_respuesta(resp)
        except (OSError, urllib.error.URLError):
            continue
    return ok


def _aplicar_respuesta(resp: dict[str, Any]) -> None:
    try:
        from edge import pago
    except Exception:
        return
    hasta = (resp.get("pago_hasta") or "").strip()
    if hasta:
        try:
            pago.aplicar_hasta(hasta)
        except Exception:
            pass
    u = (resp.get("pago_url") or "").strip()
    if u:
        try:
            pago.guardar_url(u)
        except Exception:
            pass


def avisar(*, forzar: bool = False) -> None:
    t = threading.Thread(target=_avisar, args=(forzar,), daemon=True)
    t.start()


def _avisar(forzar: bool) -> None:
    global _last_guardar, _last_enviar
    now = time.time()
    try:
        _volcar_accesos()
        if not forzar and (now - _last_guardar) < 25:
            return
        snap = snapshot(ping_pub=True)
        guardar(snap)
        _last_guardar = now
        espera = 20 if store.es_instalado() else 180
        if (now - _last_enviar) < espera and not forzar:
            return
        if enviar(snap):
            _last_enviar = now
    except Exception:
        log.exception("el parte no salió; el cobro sigue")


def panel() -> dict[str, Any]:
    pub = ip_publica()
    este = snapshot(ping_pub=False)
    if pub:
        red = dict(este.get("red") or {})
        red["ip_pub"] = pub
        este["red"] = red
    este = geoip.marcar(este, pub)
    locales = listar()
    code = este.get("shop_code") or ""
    otros = [n for n in locales if (n.get("shop_code") or "") != code]
    pago_url = ""
    try:
        from edge import pago

        pago_url = pago.url()
    except Exception:
        pass
    return {
        "ok": True,
        "este": este,
        "locales": [este, *otros],
        "n": 1 + len(otros),
        "centro_url": centro_url(),
        "pago_url": pago_url,
    }
