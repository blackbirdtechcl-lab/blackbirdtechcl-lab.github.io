"""Venta en el mostrador. No espera a nadie."""
from __future__ import annotations

import re
from typing import Any

from edge import catalog
from edge import db as store

_IMEI = re.compile(r"^\d{15}$")


def _clean_imei(raw: str, required: bool) -> str:
    digits = re.sub(r"\D", "", raw or "")
    if required:
        if not _IMEI.match(digits):
            raise ValueError("el celular pide IMEI de 15 dígitos")
        return digits
    return digits[:15]


def _exigir_arriendo() -> None:
    from edge import sistema

    if not sistema.arriendo_vencido():
        return
    st = sistema.estado_arriendo(ping=True)
    if st.get("expired"):
        raise ValueError(
            "conecta a internet para seguir cobrando."
        )


def checkout(items: list[dict[str, Any]], pay_method: str, note: str = "") -> dict[str, Any]:
    _exigir_arriendo()
    if pay_method not in store.PAY_METHODS:
        raise ValueError("elige cómo pagan: efectivo, débito, crédito o transferencia")
    if not items:
        raise ValueError("no hay nada en el carrito")
    note = (note or "").strip()[:200]
    with store.db() as con:
        lines: list[tuple] = []
        total = 0
        names: list[str] = []
        vistos: set[str] = set()
        for raw in items:
            pid = int(raw.get("product_id") or 0)
            qty = int(raw.get("qty") or 0)
            if pid <= 0 or qty <= 0:
                raise ValueError("hay una línea mal armada")
            p = con.execute(
                "SELECT id, name, price_clp, stock, imei_required, active "
                "FROM products WHERE id = ?",
                (pid,),
            ).fetchone()
            if p is None or not p["active"]:
                raise ValueError("ese producto ya no está")
            if p["stock"] < qty:
                raise ValueError(f"no alcanza el stock de {p['name']}")
            imei = _clean_imei(str(raw.get("imei") or ""), bool(p["imei_required"]))
            if p["imei_required"] and qty != 1:
                raise ValueError("un celular se vende de a uno, con su IMEI")
            if imei:
                if imei in vistos:
                    raise ValueError("ese IMEI ya está en esta venta")
                vistos.add(imei)
            price = int(p["price_clp"])
            total += price * qty
            lines.append((p["id"], p["name"], qty, price, imei))
            names.append(p["name"] if qty == 1 else f"{p['name']} ×{qty}")
            con.execute(
                "UPDATE products SET stock = stock - ? WHERE id = ?",
                (qty, pid),
            )
            after = con.execute("SELECT stock FROM products WHERE id = ?", (pid,)).fetchone()["stock"]
            catalog.registrar_movimiento(con, pid, -qty, int(after), "venta", p["name"])
        ts = store.now_iso()
        cur = con.execute(
            "INSERT INTO sales (ts, total_clp, pay_method, note, order_id) "
            "VALUES (?, ?, ?, ?, NULL)",
            (ts, total, pay_method, note),
        )
        sale_id = cur.lastrowid
        for pid, name, qty, price, imei in lines:
            con.execute(
                "INSERT INTO sale_items (sale_id, product_id, name, qty, price_clp, imei) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (sale_id, pid, name, qty, price, imei),
            )
        store.event(con, f"Venta #{sale_id} · {', '.join(names)} · ${total:,}".replace(",", "."))
        return _sale(con, sale_id)


def checkout_service(order_id: int, pay_method: str) -> dict[str, Any]:
    _exigir_arriendo()
    if pay_method not in store.PAY_METHODS:
        raise ValueError("elige cómo pagan: efectivo, débito, crédito o transferencia")
    with store.db() as con:
        o = con.execute(
            "SELECT id, device, price_clp, status FROM service_orders WHERE id = ?",
            (order_id,),
        ).fetchone()
        if o is None:
            raise KeyError("esa orden no está")
        if o["status"] != "listo":
            raise ValueError("solo se cobra una orden lista")
        if int(o["price_clp"]) <= 0:
            raise ValueError("esta orden no tiene precio de cobro")
        ts = store.now_iso()
        total = int(o["price_clp"])
        name = f"Reparación {o['device']}"
        cur = con.execute(
            "INSERT INTO sales (ts, total_clp, pay_method, note, order_id) "
            "VALUES (?, ?, ?, ?, ?)",
            (ts, total, pay_method, f"orden {order_id}", order_id),
        )
        sale_id = cur.lastrowid
        con.execute(
            "INSERT INTO sale_items (sale_id, product_id, name, qty, price_clp, imei) "
            "VALUES (?, NULL, ?, 1, ?, '')",
            (sale_id, name, total),
        )
        con.execute(
            "UPDATE service_orders SET status = 'entregado', delivered_at = ?, updated_at = ? "
            "WHERE id = ?",
            (ts, ts, order_id),
        )
        store.event(con, f"Orden #{order_id} cobrada y entregada · ${total:,}".replace(",", "."))
        return _sale(con, sale_id)


def void_sale(sale_id: int) -> dict[str, Any]:
    day = store.today()
    with store.db() as con:
        s = con.execute(
            "SELECT id, ts, order_id, COALESCE(voided, 0) AS voided FROM sales WHERE id = ?",
            (int(sale_id),),
        ).fetchone()
        if s is None:
            raise KeyError("esa venta no está")
        if s["order_id"]:
            raise ValueError("esa venta es de una orden de taller")
        if int(s["voided"] or 0):
            raise ValueError("esa venta ya está anulada")
        if not str(s["ts"] or "").startswith(day):
            raise ValueError("solo se anula una venta de hoy")
        items = con.execute(
            "SELECT product_id, name, qty FROM sale_items WHERE sale_id = ?",
            (int(sale_id),),
        ).fetchall()
        for it in items:
            pid = it["product_id"]
            if not pid:
                continue
            qty = int(it["qty"])
            con.execute("UPDATE products SET stock = stock + ? WHERE id = ?", (qty, pid))
            after = con.execute("SELECT stock FROM products WHERE id = ?", (pid,)).fetchone()["stock"]
            catalog.registrar_movimiento(con, pid, qty, int(after), "anula", it["name"])
        con.execute("UPDATE sales SET voided = 1 WHERE id = ?", (int(sale_id),))
        store.event(con, f"Venta #{sale_id} anulada")
        return _sale(con, sale_id)


def get(sale_id: int) -> dict[str, Any]:
    with store.db() as con:
        return _sale(con, sale_id)


def _sale(con, sale_id: int) -> dict[str, Any]:
    s = store.row(
        con.execute(
            "SELECT id, ts, total_clp, pay_method, note, order_id, "
            "COALESCE(voided, 0) AS voided FROM sales WHERE id = ?",
            (sale_id,),
        ).fetchone()
    )
    if s is None:
        raise KeyError("esa venta no está")
    items = [
        store.row(r)
        for r in con.execute(
            "SELECT id, product_id, name, qty, price_clp, imei FROM sale_items WHERE sale_id = ?",
            (sale_id,),
        )
    ]
    s["items"] = items
    return s


def today_sales() -> list[dict[str, Any]]:
    day = store.today()
    with store.db() as con:
        rows = con.execute(
            "SELECT id, ts, total_clp, pay_method, note, order_id, "
            "COALESCE(voided, 0) AS voided FROM sales "
            "WHERE ts LIKE ? ORDER BY id DESC",
            (f"{day}%",),
        ).fetchall()
        out = []
        for r in rows:
            s = store.row(r)
            s["items"] = [
                store.row(i)
                for i in con.execute(
                    "SELECT name, qty, price_clp, imei FROM sale_items WHERE sale_id = ?",
                    (s["id"],),
                )
            ]
            out.append(s)
        return out
