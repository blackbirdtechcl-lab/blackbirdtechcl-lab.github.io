"""PDF del comprobante de una venta. No es documento tributario."""
from __future__ import annotations

from typing import Any

from edge import pais as paismod


def armar(sale: dict[str, Any], local: dict[str, Any]) -> bytes:
    p = paismod.actual()
    loc = local or {}
    lineas: list[str] = []
    lineas.append(p["doc"].upper())
    lineas.append(str(loc.get("name") or "Mi local"))
    if loc.get("address"):
        lineas.append(str(loc["address"]))
    ciudad = " ".join(x for x in (loc.get("comuna"), loc.get("city")) if x)
    if ciudad:
        lineas.append(ciudad)
    tax = (loc.get("tax_id") or "").strip()
    if tax:
        lineas.append(f"{p['id_fiscal']}: {tax}")
    lineas.append(f"Nº {sale.get('id') or '—'}")
    lineas.append(str(sale.get("ts") or ""))
    lineas.append("-" * 32)
    for it in sale.get("items") or []:
        qty = int(it.get("qty") or 1)
        nombre = str(it.get("name") or "")
        if qty > 1:
            nombre = f"{nombre} x{qty}"
        precio = paismod.dinero(int(it.get("price_clp") or 0) * qty)
        lineas.append(nombre[:28])
        lineas.append(f"  {precio}")
        if it.get("imei"):
            lineas.append(f"  IMEI {it['imei']}")
    lineas.append("-" * 32)
    lineas.append(f"Total  {paismod.dinero(int(sale.get('total_clp') or 0))}")
    lineas.append(str(sale.get("pay_method") or ""))
    if loc.get("ticket_footer"):
        lineas.append(str(loc["ticket_footer"]))
    lineas.append(p["aviso"])
    return _pdf(lineas)


def _esc(s: str) -> str:
    out = []
    for ch in s or "":
        o = ord(ch)
        if ch in "\\()":
            out.append("\\" + ch)
        elif o < 128:
            out.append(ch)
        elif o < 256:
            out.append("\\%03o" % o)
        else:
            out.append("?")
    return "".join(out)


def _pdf(lineas: list[str]) -> bytes:
    y = 800
    cmds = ["BT", "/F1 11 Tf"]
    for raw in lineas:
        cmds.append(f"1 0 0 1 40 {y} Tm ({_esc(raw)}) Tj")
        y -= 16
        if y < 40:
            break
    cmds.append("ET")
    stream = "\n".join(cmds).encode("latin-1", "replace")
    objs = []

    def add(body: bytes) -> int:
        objs.append(body)
        return len(objs)

    add(b"<< /Type /Catalog /Pages 2 0 R >>")
    add(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
    add(
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 842] "
        b"/Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>"
    )
    add(b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream")
    add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
    out = bytearray(b"%PDF-1.4\n")
    offs = [0]
    for i, body in enumerate(objs, start=1):
        offs.append(len(out))
        out += f"{i} 0 obj\n".encode("ascii") + body + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs)+1}\n".encode("ascii")
    out += b"0000000000 65535 f \n"
    for o in offs[1:]:
        out += f"{o:010d} 00000 n \n".encode("ascii")
    out += (
        f"trailer << /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n"
    ).encode("ascii")
    return bytes(out)
