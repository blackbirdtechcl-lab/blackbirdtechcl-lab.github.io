"""Foto de la etiqueta → código. El celular manda la foto, la caja la lee.

Safari en la wifi del local no abre la cámara en vivo (HTTP).
La foto sí llega. No es boleta ni factura.
"""
from __future__ import annotations

import re
from io import BytesIO

from PIL import Image, UnidentifiedImageError

MAX_BYTES = 8 * 1024 * 1024
_A10 = re.compile(r"A10-[A-Z]{3}-[A-Z0-9]{3}-\d{4}", re.I)
_DIG = re.compile(r"(?<!\d)(\d{8,14})(?!\d)")


def pick_code(text: str) -> str:
    raw = text or ""
    m = _A10.search(raw)
    if m:
        return m.group(0).upper()
    digits = _DIG.findall(raw)
    if not digits:
        return ""
    for n in (13, 12, 8):
        hit = next((d for d in digits if len(d) == n), "")
        if hit:
            return hit
    return max(digits, key=len)


def leer(raw: bytes) -> dict:
    if not raw:
        raise ValueError("manda una foto de la etiqueta")
    if len(raw) > MAX_BYTES:
        raise ValueError("esa foto pesa demasiado")
    try:
        im = Image.open(BytesIO(raw))
        im.load()
    except (UnidentifiedImageError, OSError, ValueError) as e:
        raise ValueError("esa foto no se entiende") from e
    code = _zxing(raw) or pick_code(_ocr_text(raw))
    if not code:
        raise ValueError("no vi un código en esa foto")
    return {"code": code}


def _zxing(raw: bytes) -> str:
    try:
        import zxingcpp
    except ImportError:
        return ""
    try:
        im = Image.open(BytesIO(raw)).convert("RGB")
        hits = zxingcpp.read_barcodes(im)
    except Exception:
        return ""
    for h in hits or []:
        text = str(getattr(h, "text", "") or "").strip()
        if text:
            return text
    return ""


def _ocr_text(raw: bytes) -> str:
    from edge import tapa

    return tapa._ocr(raw) or ""
