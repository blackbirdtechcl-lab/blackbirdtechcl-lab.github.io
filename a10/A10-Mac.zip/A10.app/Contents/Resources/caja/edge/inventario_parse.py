"""Lee una lista de inventario. El orden de las columnas no importa."""
from __future__ import annotations

import csv
import io
import re
import zipfile
from typing import Any
from xml.etree import ElementTree as ET

COL_NAME = re.compile(
    r"nombre|producto|descripci[oó]n|detalle|art[ií]culo|modelo|item",
    re.I,
)
COL_SKU = re.compile(r"^sku$|^c[oó]digo(\s*interno)?$|^cod$|^code$", re.I)
COL_BARCODE = re.compile(r"barra|barcode|ean|upc|gtin", re.I)
COL_BRAND = re.compile(r"^marca$|^brand$|^fabricante$", re.I)
COL_KIND = re.compile(r"^tipo$|^kind$|categor|rubro|familia", re.I)
COL_QTY = re.compile(r"^cant|^qty|cantidad|stock|unidades|^uds?$|^u$", re.I)
COL_COST = re.compile(
    r"costo|compra|neto|cost|precio\s*cost|p\.?\s*cost|p\.?\s*compra",
    re.I,
)
COL_PRICE = re.compile(
    r"precio\s*venta|pvp|venta|publico|p\.?\s*venta|precio\s*final|precio",
    re.I,
)
COL_TOTAL = re.compile(r"^total$|^monto$|^importe$|^subtotal$", re.I)
COL_SKIP = re.compile(r"total|monto|importe|iva|rut|folio|proveedor", re.I)
CODE_IN_NAME = re.compile(r"\(([A-Za-z0-9][A-Za-z0-9._\s/-]{0,28})\)$")
JUNK = re.compile(
    r"^(producto|nombre|marca|tipo|sku|codigo|cantidad|stock|precio|costo|"
    r"lista|inventario|detalle|item)$",
    re.I,
)
PHONE = re.compile(
    r"iphone|galaxy|redmi|xiaomi|motorola|pixel|honor|huawei|nokia|oppo|"
    r"vivo|realme|tecno|infinix|\biph\b|\ba1\d\b|\ba2\d\b|\ba3\d\b|\ba5\d\b|\bs2[0-9]\b",
    re.I,
)
PART = re.compile(
    r"pantalla|bateria|bater[ií]a|flex|tapa|pin\s*de\s*carga|c[aá]mara|"
    r"modulo|placa|conector|repuesto",
    re.I,
)
ACC = re.compile(
    r"funda|vidrio|cable|cargador|auricular|power\s*bank|parlante|soporte|"
    r"protector|mica|templado|accesorio|carcasa|cover|case|mouse|headset|"
    r"pila|pendrive|micro\s*sd|\bsd\b|hdmi|teclado|keyboard|transmisor|"
    r"aud[ií]fono|adaptador|adapter|\bnail\b|wipes|acrylic|builder\s*gel",
    re.I,
)
GENERIC_RE = re.compile(
    r"\bgeneri[ck][oa]s?\b|\bgen[eé]ric[oa]s?\b|\buniversal(es)?\b|"
    r"\bsin\s*marca\b|\bno[\s-]?name\b|\bsinmarca\b",
    re.I,
)
BRAND_MARKS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\biphone|\bipad\b|\bapple\b|\bairpods|\bmacbook|\bip\s*1[1-7]\b", re.I), "Apple"),
    (re.compile(r"\bsamsung\b|\bgalaxy\b", re.I), "Samsung"),
    (re.compile(r"\bxiaomi\b|\bredmi\b|\bpoco\b|\bmi\s*(?:note|11|12|13|14)\b", re.I), "Xiaomi"),
    (re.compile(r"\bmotorola\b|\bmoto\s*[egc]\w*", re.I), "Motorola"),
    (re.compile(r"\bhuawei\b", re.I), "Huawei"),
    (re.compile(r"\bhonor\b", re.I), "Honor"),
    (re.compile(r"\boppo\b", re.I), "Oppo"),
    (re.compile(r"\bvivo\b", re.I), "Vivo"),
    (re.compile(r"\brealme\b", re.I), "Realme"),
    (re.compile(r"\bnokia\b", re.I), "Nokia"),
    (re.compile(r"\bpixel\b|\bgoogle\b", re.I), "Google"),
    (re.compile(r"\boneplus\b", re.I), "OnePlus"),
    (re.compile(r"\bnothing\b", re.I), "Nothing"),
    (re.compile(r"\btecno\b", re.I), "Tecno"),
    (re.compile(r"\binfinix\b", re.I), "Infinix"),
    (re.compile(r"\bbelkin\b", re.I), "Belkin"),
    (re.compile(r"\banker\b", re.I), "Anker"),
    (re.compile(r"\bbaseus\b", re.I), "Baseus"),
    (re.compile(r"\bspigen\b", re.I), "Spigen"),
    (re.compile(r"\bjbl\b", re.I), "JBL"),
    (re.compile(r"\bsony\b", re.I), "Sony"),
    (re.compile(r"\blg\b", re.I), "LG"),
    (re.compile(r"\bmia\s*secret\b", re.I), "Mia Secret"),
    (re.compile(r"\btecmaster\b", re.I), "Tecmaster"),
    (re.compile(r"\benergizer\b", re.I), "Energizer"),
    (re.compile(r"\btrust\b", re.I), "Trust"),
    (re.compile(r"\badata\b", re.I), "Adata"),
]
MODEL_BRAND: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\ba(?:1[0-9]|2[0-9]|3[0-6]|5[0-6])(?:\s|$|[a-z])", re.I), "Samsung"),
    (re.compile(r"\bs2[0-6](?:\s|$|[a-z])", re.I), "Samsung"),
    (re.compile(r"\bnote\s*1[0-4]\b", re.I), "Xiaomi"),
    (re.compile(r"\bmoto\b", re.I), "Motorola"),
]


def fold(s: str) -> str:
    return (
        str(s or "")
        .lower()
        .strip()
        .replace("á", "a")
        .replace("é", "e")
        .replace("í", "i")
        .replace("ó", "o")
        .replace("ú", "u")
        .replace("ü", "u")
        .replace("ñ", "n")
    )


def parse_clp(raw: Any) -> int | None:
    """Solo un monto que está escrito. No inventa."""
    if raw is None or isinstance(raw, bool):
        return None
    if isinstance(raw, int):
        return raw if 100 <= raw <= 9_999_999 else None
    if isinstance(raw, float):
        n = int(round(raw))
        return n if 100 <= n <= 9_999_999 else None
    s = str(raw).strip().upper()
    s = s.replace("CLP", "").replace("PESOS", "").replace(".-", "")
    s = s.replace("$", "").replace(" ", "").replace("\u00a0", "")
    if not s:
        return None
    if re.fullmatch(r"\d{1,3}(\.\d{3})+", s):
        n = int(s.replace(".", ""))
    elif re.fullmatch(r"\d{1,3}(,\d{3})+", s):
        n = int(s.replace(",", ""))
    elif re.fullmatch(r"\d{3,7}", s):
        n = int(s)
    elif re.fullmatch(r"\d+\.\d+", s):
        n = int(round(float(s)))
    else:
        return None
    return n if 100 <= n <= 9_999_999 else None


def parse_qty(raw: Any) -> int | None:
    if raw is None or isinstance(raw, bool):
        return None
    if isinstance(raw, int):
        return raw if 0 < raw <= 20_000 else None
    if isinstance(raw, float):
        if abs(raw - round(raw)) > 1e-6:
            return None
        n = int(round(raw))
        return n if 0 < n <= 20_000 else None
    s = str(raw).strip().replace("\u00a0", " ")
    if parse_clp(s) and re.fullmatch(r"\d{1,3}(\.\d{3})+", s.replace(" ", "").replace("$", "")):
        return None
    s = s.replace(",", ".").replace("u.", "").replace("un.", "").strip()
    if not re.fullmatch(r"\d{1,5}(?:\.0+)?", s):
        return None
    n = int(float(s))
    return n if 0 < n <= 20_000 else None


def es_generico(text: str) -> bool:
    return bool(GENERIC_RE.search(text or ""))


def guess_brand(name: str, brand: str = "", kind: str = "") -> str:
    given = (brand or "").strip()
    if given and not JUNK.match(given):
        canon = _canon_brand(given)
        if canon:
            return canon
        return given[:40]
    blob = name or ""
    for pat, label in BRAND_MARKS:
        if pat.search(blob):
            return label
    if not es_generico(blob):
        for pat, label in MODEL_BRAND:
            if pat.search(blob):
                return label
    if es_generico(blob) or kind in ("accesorio", "repuesto"):
        return "Genérico"
    return ""


def _canon_brand(raw: str) -> str:
    s = (raw or "").strip()
    if not s:
        return ""
    f = fold(s)
    if f in {"generico", "generic", "universal", "sin marca", "sinmarca"}:
        return "Genérico"
    if PART.search(s) or ACC.search(s):
        return ""
    if len(f.split()) > 2:
        return ""
    for pat, label in BRAND_MARKS:
        if pat.search(s):
            return label
    if fold(s) == fold("Genérico") or GENERIC_RE.fullmatch(s):
        return "Genérico"
    return ""


def guess_kind(name: str, brand: str = "", hint: str = "") -> str:
    blob = f"{hint} {name} {brand}"
    f = fold(blob)
    if "celular" in f or "telefono" in f or "smartphone" in f:
        return "celular"
    if "repuesto" in f or "pieza" in f:
        return "repuesto"
    if "accesorio" in f:
        return "accesorio"
    if PART.search(blob):
        return "repuesto"
    if ACC.search(blob):
        return "accesorio"
    if PHONE.search(blob) and not PART.search(blob) and not ACC.search(blob):
        return "celular"
    return "accesorio"


def peel_numbers(text: str) -> tuple[str, list[int], list[int]]:
    """Saca montos y cantidades al final de una línea corrida."""
    parts = [p for p in re.split(r"\s+", (text or "").strip()) if p]
    money: list[int] = []
    qty: list[int] = []
    while parts:
        n = parse_clp(parts[-1])
        if n is not None and n >= 1000:
            money.append(n)
            parts.pop()
            continue
        break
    if money and parts:
        n = parse_clp(parts[-1])
        if n is not None and 100 <= n < 1000:
            money.append(n)
            parts.pop()
    if parts:
        q = parse_qty(parts[-1])
        if q is not None and q <= 200:
            left = fold(" ".join(parts[:-1] + [parts[-1]]))
            modelo = bool(re.search(r"iphone|galaxy|redmi|note|iph\b", left))
            if money or not modelo:
                qty.append(q)
                parts.pop()
    money.reverse()
    name = " ".join(parts).strip(" -–|,;")
    return name, qty, money


def enrich(item: dict[str, Any]) -> dict[str, Any]:
    name = str(item.get("name") or "").strip()
    kind = guess_kind(name, str(item.get("brand") or ""), str(item.get("kind") or ""))
    brand = guess_brand(name, str(item.get("brand") or ""), kind)
    note = str(item.get("note") or "").strip()
    if es_generico(name) and "generico" not in fold(note):
        note = (note + " genérico").strip()
    out = dict(item)
    out["name"] = name[:120]
    out["kind"] = kind
    out["brand"] = brand[:40]
    out["note"] = note[:240]
    if out.get("qty") is None and (out.get("cost_clp") is not None or out.get("price_clp") is not None):
        out["qty"] = 1
    return out


def _cell(row: list[str], idx: int | None) -> str:
    if idx is None or idx < 0 or idx >= len(row):
        return ""
    return str(row[idx] or "").strip()


def _roles_from_header(row: list[str]) -> dict[str, int]:
    picks: dict[str, tuple[int, int]] = {}

    def take(role: str, idx: int, score: int) -> None:
        cur = picks.get(role)
        if not cur or score > cur[0]:
            picks[role] = (score, idx)

    for i, cell in enumerate(row):
        f = fold(cell)
        if not f:
            continue
        if COL_BARCODE.search(f):
            take("barcode", i, 4)
            continue
        if COL_SKU.search(f):
            take("sku", i, 3)
            continue
        if COL_BRAND.search(f):
            take("brand", i, 3)
            continue
        if COL_KIND.search(f):
            take("kind", i, 3)
            continue
        if COL_TOTAL.search(f):
            take("total", i, 4)
            continue
        if COL_QTY.search(f):
            take("qty", i, 3)
            continue
        if COL_COST.search(f):
            take("cost", i, 4)
            continue
        if COL_PRICE.search(f) and "costo" not in f and "compra" not in f:
            score = 2
            if "vitrina" in f or "sugerido" in f:
                score = 6
            elif "venta" in f or "pvp" in f or "publico" in f:
                score = 4
            take("price", i, score)
            continue
        if COL_NAME.search(f) and not COL_SKIP.search(f):
            take("name", i, 3 if "nombre" in f or "producto" in f else 1)
    roles = {k: v[1] for k, v in picks.items()}
    return roles if "name" in roles or "sku" in roles else {}


def _roles_from_values(rows: list[list[str]]) -> dict[str, int]:
    if not rows:
        return {}
    width = max(len(r) for r in rows)
    scores = [{"name": 0, "qty": 0, "cost": 0, "price": 0, "brand": 0} for _ in range(width)]
    body = rows[1:] if len(rows) > 1 else rows
    for row in body[:80]:
        nums: list[tuple[int, int]] = []
        for i in range(width):
            cell = row[i] if i < len(row) else ""
            if not cell:
                continue
            money = parse_clp(cell)
            qty = parse_qty(cell)
            if money is not None:
                nums.append((i, money))
                scores[i]["price"] += 1
                if money < 80_000:
                    scores[i]["cost"] += 1
            elif qty is not None and qty <= 200:
                scores[i]["qty"] += 2
            elif _canon_brand(cell):
                scores[i]["brand"] += 3
            elif len(cell) >= 4 and not JUNK.match(cell) and not parse_clp(cell):
                scores[i]["name"] += 2 + min(3, len(cell) // 12)
                if PHONE.search(cell) or PART.search(cell) or ACC.search(cell):
                    scores[i]["name"] += 2
        if len(nums) >= 2:
            lo, hi = sorted(nums, key=lambda x: x[1])[:2]
            scores[lo[0]]["cost"] += 3
            scores[hi[0]]["price"] += 3
    roles: dict[str, int] = {}
    used: set[int] = set()
    for role in ("name", "brand", "price", "cost", "qty"):
        best = max(range(width), key=lambda i: scores[i][role] if i not in used else -1)
        if best not in used and scores[best][role] > 0:
            roles[role] = best
            used.add(best)
    return roles if "name" in roles else {}


def _looks_header(row: list[str]) -> bool:
    hits = 0
    for c in row:
        f = fold(c)
        if COL_NAME.search(f) or COL_QTY.search(f) or COL_COST.search(f) or COL_PRICE.search(f):
            hits += 1
    return hits >= 2


def _es_total_linea(n: int, qty: int | None, unit: int | None) -> bool:
    if not qty or qty <= 1 or not unit or unit <= 0:
        return False
    return abs(n - qty * unit) <= max(1, qty)


def _sku_desde_nombre(name: str) -> str:
    m = CODE_IN_NAME.search((name or "").strip())
    return (m.group(1) if m else "").strip()


def _row_item(row: list[str], roles: dict[str, int]) -> dict[str, Any] | None:
    name = _cell(row, roles.get("name"))
    sku = _cell(row, roles.get("sku")).upper()
    barcode = re.sub(r"\s+", "", _cell(row, roles.get("barcode")))
    brand = _cell(row, roles.get("brand"))
    kind_hint = _cell(row, roles.get("kind"))
    if not name and sku:
        name = sku
    if not name or JUNK.match(name):
        return None
    if parse_clp(name) and len(name) < 8:
        return None
    if not sku:
        sku = _sku_desde_nombre(name).upper()
    qty = parse_qty(_cell(row, roles.get("qty")))
    cost = parse_clp(_cell(row, roles.get("cost")))
    price = parse_clp(_cell(row, roles.get("price")))
    total = parse_clp(_cell(row, roles.get("total")))
    pedido = "total" in roles and "qty" in roles and "price" in roles and "cost" not in roles
    if pedido and price is not None and cost is None:
        cost, price = price, None
    if cost is None or price is None:
        leftovers: list[int] = []
        used = {
            roles.get("cost"),
            roles.get("price"),
            roles.get("qty"),
            roles.get("name"),
            roles.get("sku"),
            roles.get("total"),
        }
        for i, cell in enumerate(row):
            if i in used:
                continue
            n = parse_clp(cell)
            if not n:
                continue
            if _es_total_linea(n, qty, cost) or _es_total_linea(n, qty, price):
                continue
            leftovers.append(n)
        leftovers.sort()
        if cost is None and leftovers:
            cost = leftovers[0]
            leftovers = leftovers[1:]
        if price is None and leftovers:
            cand = leftovers[-1]
            if not _es_total_linea(cand, qty, cost):
                price = cand
    if total is not None and cost is None and price is not None and _es_total_linea(total, qty, price):
        cost, price = price, None
    if total is not None and price is None and cost is not None and _es_total_linea(total, qty, cost):
        pass
    if qty is None:
        for i, cell in enumerate(row):
            if i in {roles.get("cost"), roles.get("price"), roles.get("name")}:
                continue
            q = parse_qty(cell)
            if q is not None and q <= 500:
                qty = q
                break
    if qty is None or cost is None or price is None:
        peeled, qtys, money = peel_numbers(name)
        if peeled and (qtys or money) and peeled != name:
            name = peeled
            if qty is None and qtys:
                qty = qtys[0]
            if cost is None and len(money) >= 2:
                cost = money[0]
            if price is None and money:
                price = money[-1]
    if qty is None and cost is None and price is None:
        loose = _item_from_blob(" ".join(c for c in row if str(c or "").strip()))
        if loose:
            return loose
        return None
    if cost is not None and price is not None and cost > price:
        cost, price = price, cost
    return enrich(
        {
            "name": name,
            "sku": sku[:48],
            "barcode": barcode[:48],
            "brand": brand,
            "kind": kind_hint,
            "qty": qty,
            "cost_clp": cost,
            "price_clp": price,
        }
    )


def _item_from_blob(blob: str) -> dict[str, Any] | None:
    name, qtys, money = peel_numbers(blob)
    if not name or JUNK.match(name) or parse_clp(name):
        return None
    if not qtys and not money:
        return None
    cost = money[0] if len(money) >= 2 else None
    price = money[-1] if money else None
    if cost is not None and price is not None and cost > price:
        cost, price = price, cost
    return enrich(
        {
            "name": name,
            "sku": "",
            "barcode": "",
            "brand": "",
            "kind": "",
            "qty": qtys[0] if qtys else None,
            "cost_clp": cost,
            "price_clp": price,
        }
    )


def parse_grid(rows: list[list[str]]) -> dict[str, Any]:
    clean = [[str(c or "").strip() for c in row] for row in rows if any(str(c or "").strip() for c in row)]
    warn: list[str] = []
    if not clean:
        return {"lines": [], "warnings": ["la hoja vino vacía"], "method": "vacio"}
    header_i = next((i for i, r in enumerate(clean[:25]) if _looks_header(r)), -1)
    roles: dict[str, int] = {}
    body = clean
    method = "valores"
    if header_i >= 0:
        roles = _roles_from_header(clean[header_i])
        if roles:
            body = clean[header_i + 1 :]
            method = "encabezado"
    if not roles:
        roles = _roles_from_values(clean)
        method = "valores"
        warn.append("No había encabezado claro. Armé las columnas por lo que había en cada celda.")
    if not roles:
        loose = [_item_from_blob(" ".join(c for c in row if c)) for row in clean]
        lines = [x for x in loose if x]
        if lines:
            return {
                "lines": lines,
                "warnings": ["La lista venía corrida. Separé nombre, cantidad y precios de cada línea."],
                "method": "linea",
            }
        return {"lines": [], "warnings": ["no entendí las columnas"], "method": "ninguno"}
    lines: list[dict[str, Any]] = []
    for row in body:
        item = _row_item(row, roles)
        if item:
            lines.append(item)
    if not lines:
        loose = [_item_from_blob(" ".join(c for c in row if c)) for row in body]
        lines = [x for x in loose if x]
        if lines:
            method = "linea"
            warn.append("La lista venía corrida. Separé nombre, cantidad y precios al final de cada línea.")
    if not lines:
        warn.append("No saqué filas con producto, cantidad o precio.")
    return {"lines": lines, "warnings": warn, "method": method, "roles": roles}


def parse_csv(text: str) -> dict[str, Any]:
    sample = text[:4000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
        if sample.count(";") > sample.count(","):
            dialect.delimiter = ";"
    rows = list(csv.reader(io.StringIO(text), dialect))
    out = parse_grid(rows)
    out["source"] = "csv"
    return out


FOLIO_RE = re.compile(
    r"(?:folio|n[°ºo]\.?\s*(?:factura|doc(?:umento)?)|factura\s*n[°ºo]?)\s*[:#]?\s*([A-Za-z0-9][A-Za-z0-9./-]{1,18})",
    re.I,
)
PROV_RE = re.compile(r"(?:proveedor|raz[oó]n\s*social)\s*[:]\s*(.{2,80})", re.I)
FECHA_RE = re.compile(r"(?:fecha)\s*[:]\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})", re.I)


def extract_factura_meta(text: str) -> dict[str, str]:
    blob = (text or "").replace("\r\n", "\n")
    folio = ""
    proveedor = ""
    fecha = ""
    m = FOLIO_RE.search(blob)
    if m:
        folio = m.group(1).strip()
    m = PROV_RE.search(blob)
    if m:
        proveedor = re.sub(r"\s+", " ", m.group(1)).strip(" .,-")
    m = FECHA_RE.search(blob)
    if m:
        fecha = _fecha_iso(m.group(1).strip())
    return {"proveedor": proveedor[:80], "folio": folio[:40], "fecha": fecha[:20]}


def _fecha_iso(raw: str) -> str:
    m = re.match(r"(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})$", (raw or "").strip())
    if not m:
        return (raw or "").strip()[:20]
    d, mo, y = m.groups()
    if len(y) == 2:
        y = "20" + y
    return f"{int(y):04d}-{int(mo):02d}-{int(d):02d}"


def _meta_desde_filas(rows: list[list[str]]) -> dict[str, str]:
    text = "\n".join(" ".join(str(c) for c in row if c) for row in (rows or [])[:30])
    return extract_factura_meta(text)


def parse_text(text: str) -> dict[str, Any]:
    text = (text or "").replace("\r\n", "\n").strip()
    if not text:
        return {
            "lines": [],
            "warnings": ["no hay texto"],
            "method": "vacio",
            "source": "texto",
            **extract_factura_meta(""),
        }
    if "," in text or ";" in text or "\t" in text:
        out = parse_csv(text)
    else:
        rows = [re.split(r"\s{2,}|\t+", ln.strip()) for ln in text.splitlines() if ln.strip()]
        out = parse_grid(rows)
        out["source"] = "texto"
    out.update(extract_factura_meta(text))
    return out


def _xlsx_number(raw: str) -> str:
    s = (raw or "").strip()
    if not s:
        return ""
    if re.fullmatch(r"-?\d{1,3}(\.\d{3})+", s):
        return s
    if re.fullmatch(r"-?\d+\.\d+", s):
        try:
            n = float(s)
        except ValueError:
            return s
        if abs(n - round(n)) < 1e-6:
            return str(int(round(n)))
        if abs(n) >= 40:
            return str(int(round(n)))
    return s


def xlsx_sheets(data: bytes) -> list[tuple[str, list[list[str]]]]:
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        ss: list[str] = []
        if "xl/sharedStrings.xml" in z.namelist():
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall("m:si", ns):
                ss.append("".join((t.text or "") for t in si.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")))
        sheets: list[tuple[str, list[list[str]]]] = []
        for name in z.namelist():
            if not name.startswith("xl/worksheets/sheet") or not name.endswith(".xml"):
                continue
            root = ET.fromstring(z.read(name))
            grid: list[list[str]] = []
            for row in root.findall(".//m:sheetData/m:row", ns):
                cells: dict[int, str] = {}
                max_c = 0
                for c in row.findall("m:c", ns):
                    ref = c.get("r") or "A1"
                    col = 0
                    for ch in ref:
                        if ch.isalpha():
                            col = col * 26 + (ord(ch.upper()) - 64)
                        else:
                            break
                    col -= 1
                    v = c.find("m:v", ns)
                    raw = v.text if v is not None else ""
                    if c.get("t") == "s" and raw.isdigit() and int(raw) < len(ss):
                        val = ss[int(raw)]
                    else:
                        val = _xlsx_number(raw or "")
                    cells[col] = val
                    max_c = max(max_c, col)
                if cells:
                    grid.append([cells.get(i, "") for i in range(max_c + 1)])
            sheets.append((name, grid))
    return sheets


def parse_xlsx(data: bytes) -> dict[str, Any]:
    sheets = xlsx_sheets(data)
    best: dict[str, Any] | None = None
    for _name, rows in sheets:
        pack = parse_grid(rows)
        if best is None or len(pack.get("lines") or []) > len(best.get("lines") or []):
            best = pack
    out = best or {"lines": [], "warnings": ["excel vacío"], "method": "vacio"}
    out["source"] = "excel"
    blob: list[list[str]] = []
    for _name, rows in sheets:
        blob.extend(rows[:20])
    out.update(_meta_desde_filas(blob))
    return out


def _es_foto(filename: str, data: bytes) -> bool:
    name = (filename or "").lower()
    if name.endswith((".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff", ".heic", ".heif")):
        return True
    if data[:3] == b"\xff\xd8\xff":
        return True
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return True
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return True
    return False


def parse_foto(data: bytes) -> dict[str, Any]:
    from edge import tapa

    text = tapa._ocr(data)
    if not (text or "").strip():
        return {
            "lines": [],
            "warnings": ["no pude leer esa foto. Prueba más luz o un Excel."],
            "method": "foto",
            "source": "foto",
            "proveedor": "",
            "folio": "",
            "fecha": "",
        }
    pack = parse_text(text)
    pack.update(extract_factura_meta(text))
    pack["source"] = "foto"
    pack["method"] = pack.get("method") or "foto"
    if not pack.get("lines"):
        pack.setdefault("warnings", []).append(
            "leí la foto pero no saqué productos. Revisa que se vean nombre, cantidad y precio."
        )
    return pack


def read_upload(filename: str, data: bytes) -> dict[str, Any]:
    name = (filename or "").lower()
    if not data:
        raise ValueError("el archivo vino vacío")
    if _es_foto(name, data):
        return parse_foto(data)
    zippy = data[:2] == b"PK"
    old_xls = name.endswith(".xls") and not name.endswith(".xlsx")
    if old_xls and not zippy:
        raise ValueError("ese Excel es del formato viejo (.xls). Guárdalo como .xlsx o como CSV")
    if name.endswith((".xlsx", ".xlsm", ".xls")) or zippy:
        try:
            return parse_xlsx(data)
        except ValueError:
            raise
        except Exception as e:
            raise ValueError("no pude leer el Excel. Prueba guardarlo como CSV") from e
    if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
        return parse_text(data.decode("utf-16"))
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = data.decode("latin-1")
    return parse_text(text)
