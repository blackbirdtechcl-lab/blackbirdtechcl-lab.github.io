"""Catálogo de celulares, accesorios y repuestos."""
from __future__ import annotations

import re
from typing import Any

from edge import codigo
from edge import db as store

COLS = (
    "id, sku, name, kind, brand, price_clp, cost_clp, stock, imei_required, active, "
    "market_on, market_price_clp, market_show_stock, market_fulfill, market_eta_min, "
    "photo, barcode, note, ref_code, ubicacion"
)


def clean_sku(raw: str) -> str:
    """Arregla códigos de proveedor: espacios, tildes, barras."""
    s = (raw or "").strip().upper()
    s = s.replace(" ", "-").replace("/", "-").replace("\\", "-")
    s = re.sub(r"[^A-Z0-9._-]+", "-", s)
    s = re.sub(r"-{2,}", "-", s).strip("-._")
    return s[:47]


def _ref_de(sku: str, ref_code: str) -> str:
    ref = clean_sku(ref_code)
    if ref:
        return ref
    sku = clean_sku(sku)
    if sku and not codigo.es_codigo_a10(sku):
        return sku
    return ""


def registrar_movimiento(
    con: Any,
    product_id: int,
    qty: int,
    stock_after: int,
    reason: str,
    detail: str = "",
) -> None:
    con.execute(
        "INSERT INTO inventory_moves (ts, product_id, qty, stock_after, reason, detail) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (store.now_iso(), int(product_id), int(qty), int(stock_after), reason[:40], (detail or "")[:160]),
    )


def movimientos(product_id: int, limit: int = 16) -> list[dict[str, Any]]:
    with store.db() as con:
        return [
            store.row(r)
            for r in con.execute(
                "SELECT ts, qty, stock_after, reason, detail FROM inventory_moves "
                "WHERE product_id = ? ORDER BY id DESC LIMIT ?",
                (product_id, limit),
            )
        ]


def asegurar_codigos_a10(con: Any) -> int:
    rows = list(
        con.execute(
            "SELECT id, sku, kind, brand, ref_code FROM products WHERE active = 1"
        )
    )
    n = 0
    for r in rows:
        sku = str(r["sku"] or "")
        if codigo.es_codigo_a10(sku):
            continue
        ref = str(r["ref_code"] or "").strip() or clean_sku(sku)
        nuevo = codigo.siguiente(con, r["kind"], r["brand"])
        con.execute(
            "UPDATE products SET sku = ?, ref_code = ? WHERE id = ?",
            (nuevo, ref, r["id"]),
        )
        n += 1
    return n


def list_products(q: str = "", kind: str = "") -> list[dict[str, Any]]:
    q = (q or "").strip().lower()
    kind = (kind or "").strip()
    sql = f"SELECT {COLS} FROM products WHERE active = 1"
    args: list[Any] = []
    if kind in store.KINDS:
        sql += " AND kind = ?"
        args.append(kind)
    sql += " ORDER BY kind DESC, brand, name"
    with store.db() as con:
        rows = [store.row(r) for r in con.execute(sql, args)]
    if not q:
        return rows
    exact: list[dict[str, Any]] = []
    rest: list[dict[str, Any]] = []
    for r in rows:
        blob = codigo.blob(r)
        if q == str(r.get("sku") or "").lower() or q == str(r.get("ref_code") or "").lower() or q == str(
            r.get("barcode") or ""
        ).lower():
            exact.append(r)
        elif q in blob:
            rest.append(r)
    return exact + rest


def add_product(
    name: str,
    kind: str,
    price_clp: int,
    stock: int = 0,
    brand: str = "",
    sku: str = "",
    cost_clp: int = 0,
    barcode: str = "",
    note: str = "",
    ref_code: str = "",
    ubicacion: str = "",
    reason: str = "alta",
    detail: str = "",
) -> dict[str, Any]:
    name = (name or "").strip()
    brand = (brand or "").strip()
    kind = (kind or "").strip()
    barcode = re.sub(r"\s+", "", barcode or "")
    note = (note or "").strip()[:240]
    ubicacion = (ubicacion or "").strip()[:40]
    ref = _ref_de(sku, ref_code)
    if not name:
        raise ValueError("el producto necesita un nombre")
    if kind not in store.KINDS:
        raise ValueError("el tipo es celular, accesorio o repuesto")
    if price_clp < 0:
        raise ValueError("el precio no puede ser negativo")
    if cost_clp < 0:
        raise ValueError("el costo no puede ser negativo")
    if stock < 0:
        raise ValueError("el stock no puede ser negativo")
    imei_required = 1 if kind == "celular" else 0
    with store.db() as con:
        a10 = (sku or "").strip().upper() if codigo.es_codigo_a10(sku) else codigo.siguiente(con, kind, brand)
        taken = con.execute("SELECT id FROM products WHERE sku = ?", (a10,)).fetchone()
        if taken:
            a10 = codigo.siguiente(con, kind, brand)
        cur = con.execute(
            "INSERT INTO products "
            "(sku, name, kind, brand, price_clp, cost_clp, stock, imei_required, active, created_at, "
            "market_on, market_price_clp, market_show_stock, market_fulfill, market_eta_min, "
            "barcode, note, ref_code, ubicacion) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 0, 0, 0, 'retiro', 30, ?, ?, ?, ?)",
            (
                a10,
                name,
                kind,
                brand,
                int(price_clp),
                int(cost_clp),
                int(stock),
                imei_required,
                store.now_iso(),
                barcode[:48],
                note,
                ref,
                ubicacion,
            ),
        )
        pid = cur.lastrowid
        if int(stock) > 0:
            registrar_movimiento(
                con, pid, int(stock), int(stock), reason or "alta", detail or ref or name
            )
        store.event(con, f"{a10} · {name} en el inventario.")
        r = con.execute(f"SELECT {COLS} FROM products WHERE id = ?", (pid,)).fetchone()
        return store.row(r)


def update_product(
    product_id: int,
    name: str,
    kind: str,
    price_clp: int,
    stock: int,
    brand: str = "",
    sku: str = "",
    cost_clp: int = 0,
    barcode: str = "",
    note: str = "",
    ref_code: str = "",
    ubicacion: str = "",
) -> dict[str, Any]:
    name = (name or "").strip()
    brand = (brand or "").strip()
    kind = (kind or "").strip()
    barcode = re.sub(r"\s+", "", barcode or "")
    note = (note or "").strip()[:240]
    ubicacion = (ubicacion or "").strip()[:40]
    ref = clean_sku(ref_code)
    if not name:
        raise ValueError("el producto necesita un nombre")
    if kind not in store.KINDS:
        raise ValueError("el tipo es celular, accesorio o repuesto")
    if price_clp < 0:
        raise ValueError("el precio no puede ser negativo")
    if cost_clp < 0:
        raise ValueError("el costo no puede ser negativo")
    if stock < 0:
        raise ValueError("el stock no puede ser negativo")
    imei_required = 1 if kind == "celular" else 0
    with store.db() as con:
        row = con.execute(
            "SELECT id, sku, stock, ref_code FROM products WHERE id = ?", (product_id,)
        ).fetchone()
        if row is None:
            raise KeyError("ese producto no está")
        keep = row["sku"]
        if not ref:
            ref = row["ref_code"] or ""
        before = int(row["stock"])
        con.execute(
            "UPDATE products SET name = ?, kind = ?, brand = ?, barcode = ?, "
            "price_clp = ?, cost_clp = ?, stock = ?, note = ?, imei_required = ?, "
            "ref_code = ?, ubicacion = ? WHERE id = ?",
            (
                name,
                kind,
                brand,
                barcode[:48],
                int(price_clp),
                int(cost_clp),
                int(stock),
                note,
                imei_required,
                ref,
                ubicacion,
                product_id,
            ),
        )
        delta = int(stock) - before
        if delta:
            registrar_movimiento(con, product_id, delta, int(stock), "ficha", name)
        store.event(con, f"{keep} · {name} actualizado.")
        r = con.execute(f"SELECT {COLS} FROM products WHERE id = ?", (product_id,)).fetchone()
        return store.row(r)


def ajustar_stock(product_id: int, stock: int, reason: str = "conteo") -> dict[str, Any]:
    if stock < 0:
        raise ValueError("el stock no puede ser negativo")
    why = (reason or "conteo").strip()[:40] or "conteo"
    with store.db() as con:
        row = con.execute(
            f"SELECT {COLS} FROM products WHERE id = ? AND active = 1", (product_id,)
        ).fetchone()
        if row is None:
            raise KeyError("ese producto no está")
        before = int(row["stock"])
        if before == int(stock):
            return store.row(row)
        con.execute("UPDATE products SET stock = ? WHERE id = ?", (int(stock), product_id))
        registrar_movimiento(
            con, product_id, int(stock) - before, int(stock), why, row["name"] or ""
        )
        store.event(con, f"{row['sku']} · recuento {before} → {int(stock)}.")
        r = con.execute(f"SELECT {COLS} FROM products WHERE id = ?", (product_id,)).fetchone()
        return store.row(r)


def hide_product(product_id: int) -> dict[str, Any]:
    with store.db() as con:
        row = con.execute("SELECT id, name, sku FROM products WHERE id = ?", (product_id,)).fetchone()
        if row is None:
            raise KeyError("ese producto no está")
        con.execute("UPDATE products SET active = 0 WHERE id = ?", (product_id,))
        store.event(con, f"{row['sku']} · {row['name']} fuera del inventario.")
        return {"ok": True, "id": product_id}
