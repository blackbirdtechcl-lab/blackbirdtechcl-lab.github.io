"""Ciudad según la IP pública. No cree la calle que escribe el local."""
from __future__ import annotations

import ipaddress
import json
import os
import time
import urllib.error
import urllib.request
from typing import Any

_cache: dict[str, tuple[float, dict[str, Any] | None]] = {}
_TTL = 24 * 3600


def es_publica(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address((ip or "").strip())
    except ValueError:
        return False
    return not (
        addr.is_private
        or addr.is_loopback
        or addr.is_link_local
        or addr.is_multicast
        or addr.is_reserved
        or addr.is_unspecified
    )


def elige(*ips: str) -> str:
    for raw in ips:
        ip = (raw or "").strip()
        if es_publica(ip):
            return ip
    return ""


def ip_pedido(headers: Any, client: str = "") -> str:
    get = headers.get if headers is not None else lambda _k, _d="": ""
    for key in ("cf-connecting-ip", "CF-Connecting-IP", "x-real-ip", "X-Real-IP"):
        got = elige(str(get(key, "") or ""))
        if got:
            return got
    xff = str(get("x-forwarded-for", "") or get("X-Forwarded-For", "") or "")
    first = xff.split(",")[0].strip() if xff else ""
    return elige(first, client)


def _fetch(ip: str) -> dict[str, Any] | None:
    url = (
        f"https://ipwho.is/{ip}"
        "?fields=success,ip,city,region,country,country_code,latitude,longitude"
    )
    req = urllib.request.Request(url, headers={"User-Agent": "A10"})
    with urllib.request.urlopen(req, timeout=2.0) as r:
        body = json.loads(r.read().decode("utf-8") or "{}")
    if not isinstance(body, dict) or not body.get("success"):
        return None
    lat = body.get("latitude")
    lng = body.get("longitude")
    try:
        lat_f = float(lat)
        lng_f = float(lng)
    except (TypeError, ValueError):
        return None
    if not (-90 <= lat_f <= 90 and -180 <= lng_f <= 180):
        return None
    city = str(body.get("city") or "").strip()
    region = str(body.get("region") or "").strip()
    country = str(body.get("country") or "").strip()
    code = str(body.get("country_code") or "").strip().upper()
    return {
        "ip": ip,
        "lat": lat_f,
        "lng": lng_f,
        "city": city,
        "region": region,
        "country": country,
        "country_code": code,
    }


def lookup(ip: str) -> dict[str, Any] | None:
    if (os.environ.get("A10_GEOIP") or "1").strip().lower() in ("0", "off", "no"):
        return None
    ip = elige(ip)
    if not ip:
        return None
    now = time.time()
    hit = _cache.get(ip)
    if hit and (now - hit[0]) < _TTL:
        return dict(hit[1]) if hit[1] else None
    try:
        got = _fetch(ip)
    except (OSError, urllib.error.URLError, json.JSONDecodeError, TimeoutError, ValueError):
        got = None
    _cache[ip] = (now, dict(got) if got else None)
    return dict(got) if got else None


def marcar(cuerpo: dict[str, Any], ip_visto: str = "") -> dict[str, Any]:
    """Pone geo_ip en el parte. No toca la dirección que escribió el local."""
    out = dict(cuerpo or {})
    red = out.get("red") if isinstance(out.get("red"), dict) else {}
    ya = out.get("geo_ip") if isinstance(out.get("geo_ip"), dict) else {}
    ip = elige(ip_visto, str(ya.get("ip") or ""), str(red.get("ip_pub") or ""))
    if not ip:
        return out
    if ya.get("ip") == ip and ya.get("lat") is not None:
        out["ip_visto"] = ip
        return out
    got = lookup(ip)
    if got:
        out["geo_ip"] = got
        out["ip_visto"] = ip
    return out
