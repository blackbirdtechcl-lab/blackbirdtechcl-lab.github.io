PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;

CREATE TABLE IF NOT EXISTS local (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  name TEXT NOT NULL,
  address TEXT NOT NULL DEFAULT '',
  lat REAL,
  lng REAL,
  ticket_footer TEXT NOT NULL DEFAULT '',
  margin_pct REAL NOT NULL DEFAULT 100,
  stock_alert INTEGER NOT NULL DEFAULT 2,
  shop_code TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL DEFAULT '',
  comuna TEXT NOT NULL DEFAULT '',
  whatsapp TEXT NOT NULL DEFAULT '',
  instagram TEXT NOT NULL DEFAULT '',
  facebook TEXT NOT NULL DEFAULT '',
  website TEXT NOT NULL DEFAULT '',
  printer_name TEXT NOT NULL DEFAULT '',
  printer_paper TEXT NOT NULL DEFAULT '80',
  printer_copies INTEGER NOT NULL DEFAULT 1,
  printer_cut INTEGER NOT NULL DEFAULT 1,
  ticket_header TEXT NOT NULL DEFAULT '',
  logo TEXT NOT NULL DEFAULT '',
  pais TEXT NOT NULL DEFAULT 'CL',
  idioma TEXT NOT NULL DEFAULT 'es',
  tax_id TEXT NOT NULL DEFAULT '',
  tutorial_visto INTEGER NOT NULL DEFAULT 0,
  pago_hasta TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sku TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('celular', 'accesorio', 'repuesto')),
  brand TEXT NOT NULL DEFAULT '',
  price_clp INTEGER NOT NULL CHECK (price_clp >= 0),
  cost_clp INTEGER NOT NULL DEFAULT 0 CHECK (cost_clp >= 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  imei_required INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  market_on INTEGER NOT NULL DEFAULT 0,
  market_price_clp INTEGER NOT NULL DEFAULT 0 CHECK (market_price_clp >= 0),
  market_show_stock INTEGER NOT NULL DEFAULT 0,
  market_fulfill TEXT NOT NULL DEFAULT 'retiro'
    CHECK (market_fulfill IN ('retiro', 'envio', 'ambos')),
  market_eta_min INTEGER NOT NULL DEFAULT 30 CHECK (market_eta_min >= 0),
  photo TEXT NOT NULL DEFAULT '',
  barcode TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT '',
  ref_code TEXT NOT NULL DEFAULT '',
  ubicacion TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS service_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  opened_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  delivered_at TEXT,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL DEFAULT '',
  device TEXT NOT NULL,
  imei TEXT NOT NULL DEFAULT '',
  marca TEXT NOT NULL DEFAULT '',
  serial TEXT NOT NULL DEFAULT '',
  color TEXT NOT NULL DEFAULT '',
  photo TEXT NOT NULL DEFAULT '',
  issue TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('llego', 'en_mesa', 'listo', 'entregado')),
  price_clp INTEGER NOT NULL DEFAULT 0 CHECK (price_clp >= 0),
  note TEXT NOT NULL DEFAULT '',
  bench_id INTEGER,
  tech_id INTEGER
);

CREATE TABLE IF NOT EXISTS technicians (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workbenches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  n INTEGER NOT NULL UNIQUE,
  name TEXT NOT NULL DEFAULT '',
  x REAL NOT NULL DEFAULT 0.1,
  y REAL NOT NULL DEFAULT 0.15,
  w REAL NOT NULL DEFAULT 0.16,
  h REAL NOT NULL DEFAULT 0.16,
  active INTEGER NOT NULL DEFAULT 1,
  tech_id INTEGER
);

CREATE TABLE IF NOT EXISTS bench_stock (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bench_id INTEGER NOT NULL REFERENCES workbenches(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  qty INTEGER NOT NULL DEFAULT 0 CHECK (qty >= 0),
  UNIQUE (bench_id, product_id)
);

CREATE TABLE IF NOT EXISTS bench_moves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  bench_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  qty INTEGER NOT NULL,
  reason TEXT NOT NULL DEFAULT '',
  detail TEXT NOT NULL DEFAULT '',
  tech_id INTEGER
);

CREATE TABLE IF NOT EXISTS sales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  total_clp INTEGER NOT NULL CHECK (total_clp >= 0),
  pay_method TEXT NOT NULL CHECK (
    pay_method IN ('efectivo', 'debito', 'credito', 'transferencia')
  ),
  note TEXT NOT NULL DEFAULT '',
  order_id INTEGER REFERENCES service_orders(id),
  voided INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS sale_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_id INTEGER NOT NULL REFERENCES sales(id),
  product_id INTEGER REFERENCES products(id),
  name TEXT NOT NULL,
  qty INTEGER NOT NULL CHECK (qty > 0),
  price_clp INTEGER NOT NULL,
  imei TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS inventory_moves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  product_id INTEGER NOT NULL REFERENCES products(id),
  qty INTEGER NOT NULL,
  stock_after INTEGER NOT NULL,
  reason TEXT NOT NULL DEFAULT '',
  detail TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  ok INTEGER NOT NULL DEFAULT 1,
  text TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS peers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  address TEXT NOT NULL DEFAULT '',
  lat REAL,
  lng REAL,
  phone TEXT NOT NULL DEFAULT '',
  last_seen TEXT
);

CREATE TABLE IF NOT EXISTS market_listings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  peer_id INTEGER NOT NULL REFERENCES peers(id),
  sku TEXT NOT NULL DEFAULT '',
  name TEXT NOT NULL,
  brand TEXT NOT NULL DEFAULT '',
  price_clp INTEGER NOT NULL CHECK (price_clp >= 0),
  stock INTEGER NOT NULL DEFAULT 0,
  show_stock INTEGER NOT NULL DEFAULT 0,
  fulfill TEXT NOT NULL DEFAULT 'retiro'
    CHECK (fulfill IN ('retiro', 'envio', 'ambos')),
  eta_min INTEGER NOT NULL DEFAULT 30,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS market_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  listing_key TEXT NOT NULL,
  peer_id INTEGER,
  product_id INTEGER,
  shop TEXT NOT NULL,
  name TEXT NOT NULL,
  qty INTEGER NOT NULL CHECK (qty > 0),
  price_clp INTEGER NOT NULL CHECK (price_clp >= 0),
  fulfill TEXT NOT NULL CHECK (fulfill IN ('retiro', 'envio')),
  eta_min INTEGER NOT NULL DEFAULT 0,
  backup INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL CHECK (
    status IN ('pedida', 'aceptada', 'en_camino', 'lista', 'recibida', 'cancelada')
  ),
  note TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS market_chats (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  listing_key TEXT NOT NULL UNIQUE,
  shop TEXT NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS market_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id INTEGER NOT NULL REFERENCES market_chats(id),
  mine INTEGER NOT NULL DEFAULT 1,
  text TEXT NOT NULL,
  ts TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS lecturas (
  id TEXT PRIMARY KEY,
  ts TEXT NOT NULL,
  photo TEXT NOT NULL,
  estado TEXT NOT NULL CHECK (estado IN ('leyendo', 'lista', 'fallo')),
  texto TEXT NOT NULL DEFAULT '',
  imei TEXT NOT NULL DEFAULT '',
  marca TEXT NOT NULL DEFAULT '',
  modelo TEXT NOT NULL DEFAULT '',
  serial TEXT NOT NULL DEFAULT '',
  color TEXT NOT NULL DEFAULT '',
  customer_name TEXT NOT NULL DEFAULT '',
  customer_phone TEXT NOT NULL DEFAULT '',
  capacidad TEXT NOT NULL DEFAULT '',
  avisos TEXT NOT NULL DEFAULT '[]'
);

CREATE INDEX IF NOT EXISTS idx_lecturas_ts ON lecturas(ts);
CREATE INDEX IF NOT EXISTS idx_sales_ts ON sales(ts);
CREATE INDEX IF NOT EXISTS idx_orders_status ON service_orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_bench ON service_orders(bench_id);
CREATE INDEX IF NOT EXISTS idx_tech_active ON technicians(active);
CREATE INDEX IF NOT EXISTS idx_products_kind ON products(kind, active);
CREATE INDEX IF NOT EXISTS idx_products_ref ON products(ref_code);
CREATE INDEX IF NOT EXISTS idx_products_bar ON products(barcode);
CREATE INDEX IF NOT EXISTS idx_inv_moves ON inventory_moves(product_id, id);
CREATE INDEX IF NOT EXISTS idx_market_on ON products(market_on);
CREATE INDEX IF NOT EXISTS idx_listings_peer ON market_listings(peer_id);
CREATE INDEX IF NOT EXISTS idx_morders_status ON market_orders(status);
CREATE INDEX IF NOT EXISTS idx_mchats_key ON market_chats(listing_key);
CREATE INDEX IF NOT EXISTS idx_mmsg_chat ON market_messages(chat_id, id);

CREATE TABLE IF NOT EXISTS nodos (
  shop_code TEXT PRIMARY KEY,
  name TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL DEFAULT '',
  comuna TEXT NOT NULL DEFAULT '',
  lat REAL,
  lng REAL,
  ip_lan TEXT NOT NULL DEFAULT '',
  ip_pub TEXT NOT NULL DEFAULT '',
  version TEXT NOT NULL DEFAULT '',
  visto TEXT NOT NULL DEFAULT '',
  parte TEXT NOT NULL DEFAULT '',
  pago_hasta TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS accesos (
  ip TEXT NOT NULL,
  ua TEXT NOT NULL DEFAULT '',
  n INTEGER NOT NULL DEFAULT 1,
  primero TEXT NOT NULL,
  ultimo TEXT NOT NULL,
  PRIMARY KEY (ip, ua)
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  clave TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('dueno', 'mostrador', 'tecnico')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sesiones (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS vida (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  tipo TEXT NOT NULL,
  texto TEXT NOT NULL DEFAULT ''
);
