"""Orden de servicio: llegó / en mesa / listo / entregado."""
from __future__ import annotations

import re
from typing import Any

from edge import db as store
from edge import piso

_PHONE = re.compile(r"^[\d\s+\-]{7,18}$")


def board() -> dict[str, list[dict[str, Any]]]:
    with store.db() as con:
        rows = [
            store.row(r)
            for r in con.execute(
                "SELECT o.id, o.opened_at, o.updated_at, o.delivered_at, o.customer_name, "
                "o.customer_phone, o.device, o.imei, o.marca, o.serial, o.color, o.photo, "
                "o.issue, o.status, o.price_clp, o.note, "
                "o.bench_id, o.tech_id, "
                "COALESCE(b.name, '') AS bench_name, COALESCE(b.n, 0) AS bench_n, "
                "COALESCE(t.name, '') AS tech_name "
                "FROM service_orders o "
                "LEFT JOIN workbenches b ON b.id = o.bench_id "
                "LEFT JOIN technicians t ON t.id = o.tech_id "
                "ORDER BY o.id DESC"
            )
        ]
    out = {s: [] for s in store.ORDER_STATUSES}
    for r in rows:
        out[r["status"]].append(r)
    return out


def open_order(
    customer_name: str,
    device: str,
    issue: str,
    customer_phone: str = "",
    imei: str = "",
    price_clp: int = 0,
    note: str = "",
    bench_id: int | None = None,
    tech_id: int | None = None,
    marca: str = "",
    serial: str = "",
    color: str = "",
    photo: str = "",
) -> dict[str, Any]:
    customer_name = (customer_name or "").strip()
    device = (device or "").strip()
    issue = (issue or "").strip()
    customer_phone = (customer_phone or "").strip()
    imei_digits = re.sub(r"\D", "", imei or "")
    note = (note or "").strip()[:240]
    marca = (marca or "").strip()[:40]
    serial = re.sub(r"[^A-Za-z0-9]", "", serial or "")[:14].upper()
    color = (color or "").strip()[:24]
    photo = (photo or "").strip()
    if photo:
        from edge import tapa

        tapa.resolve(photo)
    if not customer_name:
        raise ValueError("falta el nombre de quien deja el equipo")
    if not device:
        raise ValueError("falta el modelo del equipo")
    if not issue:
        raise ValueError("falta lo que le pasa")
    if customer_phone and not _PHONE.match(customer_phone):
        raise ValueError("el teléfono no se entiende")
    if imei_digits and len(imei_digits) != 15:
        raise ValueError("el IMEI, si va, son 15 dígitos")
    if price_clp < 0:
        raise ValueError("el presupuesto no puede ser negativo")
    ts = store.now_iso()
    with store.db() as con:
        bid = _valid_bench(con, bench_id)
        tid = _valid_tech(con, tech_id)
        cur = con.execute(
            "INSERT INTO service_orders "
            "(opened_at, updated_at, delivered_at, customer_name, customer_phone, "
            "device, imei, marca, serial, color, photo, issue, status, price_clp, note, bench_id, tech_id) "
            "VALUES (?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'llego', ?, ?, ?, ?)",
            (
                ts,
                ts,
                customer_name,
                customer_phone,
                device,
                imei_digits,
                marca,
                serial,
                color,
                photo,
                issue,
                int(price_clp),
                note,
                bid,
                tid,
            ),
        )
        oid = cur.lastrowid
        store.event(con, f"Orden #{oid} · {device} de {customer_name} · llegó")
        return _one(con, oid)


def move(
    order_id: int,
    status: str,
    bench_id: int | None = None,
    tech_id: int | None = None,
) -> dict[str, Any]:
    if status not in store.ORDER_STATUSES:
        raise ValueError("el estado no existe")
    ts = store.now_iso()
    with store.db() as con:
        o = con.execute(
            "SELECT id, status, bench_id, tech_id FROM service_orders WHERE id = ?",
            (order_id,),
        ).fetchone()
        if o is None:
            raise KeyError("esa orden no está")
        current = o["status"]
        if current == "entregado":
            raise ValueError("ya se entregó")
        bid = _valid_bench(con, bench_id) if bench_id is not None else o["bench_id"]
        tid = _valid_tech(con, tech_id) if tech_id is not None else o["tech_id"]
        if status == "en_mesa" and not bid:
            bid = piso.first_free_bench(con)
        if status == current and bench_id is None and tech_id is None:
            return _one(con, order_id)
        if status != current:
            allowed = store.NEXT_STATUS.get(current)
            if status != allowed:
                raise ValueError(f"de {label(current)} se pasa a {label(allowed or current)}")
        delivered = ts if status == "entregado" else None
        if status == "entregado":
            bid = None
        con.execute(
            "UPDATE service_orders SET status = ?, updated_at = ?, delivered_at = ?, "
            "bench_id = ?, tech_id = ? WHERE id = ?",
            (status, ts, delivered, bid, tid, order_id),
        )
        store.event(con, f"Orden #{order_id} · {label(status)}")
        return _one(con, order_id)


def counts() -> dict[str, int]:
    with store.db() as con:
        rows = con.execute(
            "SELECT status, COUNT(*) AS n FROM service_orders GROUP BY status"
        ).fetchall()
    out = {s: 0 for s in store.ORDER_STATUSES}
    for r in rows:
        out[r["status"]] = r["n"]
    return out


def label(status: str) -> str:
    return {
        "llego": "llegó",
        "en_mesa": "en mesa",
        "listo": "listo",
        "entregado": "entregado",
    }.get(status, status)


def _valid_bench(con, bench_id: int | None) -> int | None:
    if not bench_id:
        return None
    r = con.execute(
        "SELECT id FROM workbenches WHERE id = ? AND active = 1", (int(bench_id),)
    ).fetchone()
    if r is None:
        raise ValueError("esa mesa no está")
    return int(r["id"])


def _valid_tech(con, tech_id: int | None) -> int | None:
    if not tech_id:
        return None
    r = con.execute(
        "SELECT id FROM technicians WHERE id = ? AND active = 1", (int(tech_id),)
    ).fetchone()
    if r is None:
        raise ValueError("ese técnico no está")
    return int(r["id"])


def _one(con, order_id: int) -> dict[str, Any]:
    r = con.execute(
        "SELECT o.id, o.opened_at, o.updated_at, o.delivered_at, o.customer_name, "
        "o.customer_phone, o.device, o.imei, o.marca, o.serial, o.color, o.photo, "
        "o.issue, o.status, o.price_clp, o.note, "
        "o.bench_id, o.tech_id, "
        "COALESCE(b.name, '') AS bench_name, COALESCE(b.n, 0) AS bench_n, "
        "COALESCE(t.name, '') AS tech_name "
        "FROM service_orders o "
        "LEFT JOIN workbenches b ON b.id = o.bench_id "
        "LEFT JOIN technicians t ON t.id = o.tech_id "
        "WHERE o.id = ?",
        (order_id,),
    ).fetchone()
    return store.row(r)
