"""SQLite de esta caja. Una base, en el local."""
from __future__ import annotations

import os
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Iterator

ROOT = Path(__file__).resolve().parents[1]
_env_db = (os.environ.get("A10_DB") or "").strip()
DB_PATH = Path(_env_db) if _env_db else ROOT / "data" / "a10.db"
SCHEMA = Path(__file__).with_name("schema.sql")

PAY_METHODS = ("efectivo", "debito", "credito", "transferencia")
ORDER_STATUSES = ("llego", "en_mesa", "listo", "entregado")
NEXT_STATUS = {
    "llego": "en_mesa",
    "en_mesa": "listo",
    "listo": "entregado",
}
KINDS = ("celular", "accesorio", "repuesto")
FULFILL = ("retiro", "envio", "ambos")
DEFAULT_LAT = -33.4308
DEFAULT_LNG = -70.6472

SEED = (
    ("CEL-IP13-128", "iPhone 13 128 GB", "celular", "Apple", 449990, 2, 1),
    ("CEL-A55-128", "Galaxy A55 128 GB", "celular", "Samsung", 319990, 3, 1),
    ("CEL-RN13-256", "Redmi Note 13 256 GB", "celular", "Xiaomi", 179990, 4, 1),
    ("CEL-G54-256", "Moto G54 256 GB", "celular", "Motorola", 159990, 3, 1),
    ("ACC-VID-UNIV", "Vidrio templado", "accesorio", "Genérico", 5990, 24, 0),
    ("ACC-FUN-SIL", "Funda silicona", "accesorio", "Genérico", 7990, 18, 0),
    ("ACC-CAB-USBC", "Cable USB-C 1 m", "accesorio", "Genérico", 4990, 20, 0),
    ("ACC-CHG-25W", "Cargador 25 W", "accesorio", "Genérico", 12990, 12, 0),
    ("ACC-AUR-INO", "Auriculares in-ear", "accesorio", "Genérico", 8990, 10, 0),
    ("ACC-PWB-10K", "Power bank 10.000 mAh", "accesorio", "Genérico", 14990, 8, 0),
    ("REP-PAN-A54", "Pantalla Galaxy A54", "repuesto", "Samsung", 45990, 3, 0),
    ("REP-BAT-IP12", "Batería iPhone 12", "repuesto", "Apple", 28990, 4, 0),
    ("REP-FLX-A14", "Flex carga A14", "repuesto", "Samsung", 8990, 6, 0),
)

PEERS = (
    ("Local Meiggs", "Barrio Meiggs, Estación Central", -33.4525, -70.6790, ""),
    ("Local San Diego", "San Diego 120, Santiago", -33.4508, -70.6505, ""),
    ("Local Recoleta", "Av. Recoleta 820, Recoleta", -33.4195, -70.6418, ""),
)

PEER_LISTINGS = {
    "Local Meiggs": (
        ("Pantalla iPhone 11", "Apple", 38000, 2, 1, "retiro", 15),
        ("Batería Galaxy A54", "Samsung", 18000, 3, 0, "ambos", 40),
    ),
    "Local San Diego": (
        ("Flex carga iPhone 12", "Apple", 9000, 4, 1, "envio", 90),
    ),
    "Local Recoleta": (
        ("Pantalla Redmi Note 13", "Xiaomi", 32000, 1, 1, "retiro", 20),
        ("Tapa Galaxy A55", "Samsung", 12000, 3, 1, "ambos", 25),
    ),
}


def now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


def today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH), timeout=15)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA busy_timeout = 5000")
    con.execute("PRAGMA journal_mode = WAL")
    con.execute("PRAGMA synchronous = NORMAL")
    return con


@contextmanager
def db() -> Iterator[sqlite3.Connection]:
    con = connect()
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def _cols(con: sqlite3.Connection, table: str) -> set[str]:
    return {r[1] for r in con.execute(f"PRAGMA table_info({table})")}


def _ensure_col(con: sqlite3.Connection, table: str, name: str, spec: str) -> None:
    if name not in _cols(con, table):
        con.execute(f"ALTER TABLE {table} ADD COLUMN {name} {spec}")


def _rebuild_products(con: sqlite3.Connection) -> None:
    con.execute("PRAGMA foreign_keys = OFF")
    con.execute(
        """
        CREATE TABLE products_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          sku TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          kind TEXT NOT NULL CHECK (kind IN ('celular', 'accesorio', 'repuesto')),
          brand TEXT NOT NULL DEFAULT '',
          price_clp INTEGER NOT NULL CHECK (price_clp >= 0),
          stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
          imei_required INTEGER NOT NULL DEFAULT 0,
          active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL,
          market_on INTEGER NOT NULL DEFAULT 0,
          market_price_clp INTEGER NOT NULL DEFAULT 0 CHECK (market_price_clp >= 0),
          market_show_stock INTEGER NOT NULL DEFAULT 0,
          market_fulfill TEXT NOT NULL DEFAULT 'retiro',
          market_eta_min INTEGER NOT NULL DEFAULT 30
        )
        """
    )
    old = _cols(con, "products")
    fields = [
        "id",
        "sku",
        "name",
        "kind",
        "brand",
        "price_clp",
        "stock",
        "imei_required",
        "active",
        "created_at",
    ]
    extra = []
    for col in (
        "market_on",
        "market_price_clp",
        "market_show_stock",
        "market_fulfill",
        "market_eta_min",
    ):
        if col in old:
            extra.append(col)
    sel = ", ".join(fields + extra)
    con.execute(f"INSERT INTO products_new ({sel}) SELECT {sel} FROM products")
    con.execute("DROP TABLE products")
    con.execute("ALTER TABLE products_new RENAME TO products")
    con.execute("CREATE INDEX IF NOT EXISTS idx_products_kind ON products(kind, active)")
    con.execute("CREATE INDEX IF NOT EXISTS idx_market_on ON products(market_on)")
    con.execute("PRAGMA foreign_keys = ON")


def _migrate(con: sqlite3.Connection) -> None:
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    if "products" in tables and "market_on" not in _cols(con, "products"):
        _rebuild_products(con)
    if "service_orders" in tables:
        _ensure_col(con, "service_orders", "bench_id", "INTEGER")
        _ensure_col(con, "service_orders", "tech_id", "INTEGER")
        _ensure_col(con, "service_orders", "marca", "TEXT NOT NULL DEFAULT ''")
        _ensure_col(con, "service_orders", "serial", "TEXT NOT NULL DEFAULT ''")
        _ensure_col(con, "service_orders", "color", "TEXT NOT NULL DEFAULT ''")
        _ensure_col(con, "service_orders", "photo", "TEXT NOT NULL DEFAULT ''")
    if "workbenches" in tables:
        _ensure_col(con, "workbenches", "tech_id", "INTEGER")
    if "products" in tables:
        _ensure_col(con, "products", "photo", "TEXT NOT NULL DEFAULT ''")
        _ensure_col(con, "products", "cost_clp", "INTEGER NOT NULL DEFAULT 0")
        _ensure_col(con, "products", "barcode", "TEXT NOT NULL DEFAULT ''")
        _ensure_col(con, "products", "note", "TEXT NOT NULL DEFAULT ''")
        _ensure_col(con, "products", "ref_code", "TEXT NOT NULL DEFAULT ''")
        _ensure_col(con, "products", "ubicacion", "TEXT NOT NULL DEFAULT ''")
    con.executescript(SCHEMA.read_text(encoding="utf-8"))
    _ensure_col(con, "local", "address", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "lat", "REAL")
    _ensure_col(con, "local", "lng", "REAL")
    _ensure_col(con, "local", "ticket_footer", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "margin_pct", "REAL NOT NULL DEFAULT 100")
    _ensure_col(con, "local", "stock_alert", "INTEGER NOT NULL DEFAULT 2")
    _ensure_col(con, "local", "shop_code", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "phone", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "email", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "city", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "comuna", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "whatsapp", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "instagram", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "facebook", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "website", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "printer_name", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "printer_paper", "TEXT NOT NULL DEFAULT '80'")
    _ensure_col(con, "local", "printer_copies", "INTEGER NOT NULL DEFAULT 1")
    _ensure_col(con, "local", "printer_cut", "INTEGER NOT NULL DEFAULT 1")
    _ensure_col(con, "local", "ticket_header", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "logo", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "lease_until", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "last_checkin", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "centro_url", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "pais", "TEXT NOT NULL DEFAULT 'CL'")
    _ensure_col(con, "local", "idioma", "TEXT NOT NULL DEFAULT 'es'")
    _ensure_col(con, "local", "tax_id", "TEXT NOT NULL DEFAULT ''")
    _ensure_col(con, "local", "tutorial_visto", "INTEGER NOT NULL DEFAULT 1")
    _ensure_col(con, "sales", "voided", "INTEGER NOT NULL DEFAULT 0")
    _ensure_shop_code(con)


def _seed_peers(con: sqlite3.Connection) -> None:
    n = con.execute("SELECT COUNT(*) AS n FROM peers").fetchone()["n"]
    if n:
        return
    ts = now_iso()
    for name, address, lat, lng, phone in PEERS:
        cur = con.execute(
            "INSERT INTO peers (name, address, lat, lng, phone, last_seen) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (name, address, lat, lng, phone, ts),
        )
        pid = cur.lastrowid
        for item in PEER_LISTINGS.get(name, ()):
            title, brand, price, stock, show, fulfill, eta = item
            con.execute(
                "INSERT INTO market_listings "
                "(peer_id, sku, name, brand, price_clp, stock, show_stock, fulfill, eta_min, updated_at) "
                "VALUES (?, '', ?, ?, ?, ?, ?, ?, ?, ?)",
                (pid, title, brand, price, stock, show, fulfill, eta, ts),
            )


def _seed_repuestos(con: sqlite3.Connection) -> None:
    n = con.execute(
        "SELECT COUNT(*) AS n FROM products WHERE kind = 'repuesto'"
    ).fetchone()["n"]
    if n:
        return
    ts = now_iso()
    for sku, name, kind, brand, price, stock, imei in SEED:
        if kind != "repuesto":
            continue
        exists = con.execute("SELECT id FROM products WHERE sku = ?", (sku,)).fetchone()
        if exists:
            continue
        con.execute(
            "INSERT INTO products "
            "(sku, name, kind, brand, price_clp, stock, imei_required, active, created_at, "
            "market_on, market_price_clp, market_show_stock, market_fulfill, market_eta_min) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, 0, 0, 0, 'retiro', 30)",
            (sku, name, kind, brand, price, stock, imei, ts),
        )


def es_instalado() -> bool:
    flag = (os.environ.get("A10_PILOTO") or "").strip()
    if flag == "1":
        return True
    if flag == "0":
        return False
    if (os.environ.get("A10_DB") or "").strip():
        return False
    return (ROOT / "instalado.txt").is_file()


def version() -> str:
    p = ROOT / "VERSION"
    try:
        return p.read_text(encoding="utf-8").strip() or "0.1.0"
    except OSError:
        return "0.1.0"


def backup_to(path: Path) -> Path:
    dest = Path(path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not DB_PATH.is_file():
        raise FileNotFoundError("todavía no hay caja para copiar")
    with sqlite3.connect(str(DB_PATH)) as src:
        with sqlite3.connect(str(dest)) as dst:
            src.backup(dst)
    return dest


def init_db() -> None:
    piloto = es_instalado()
    with db() as con:
        _migrate(con)
        row = con.execute("SELECT id FROM local WHERE id = 1").fetchone()
        if row is None:
            direccion = "" if piloto else "Patronato, Recoleta"
            con.execute(
                "INSERT INTO local (id, name, address, lat, lng, updated_at) "
                "VALUES (1, 'Mi local', ?, ?, ?, ?)",
                (direccion, DEFAULT_LAT, DEFAULT_LNG, now_iso()),
            )
            event(con, "Caja lista." if piloto else "Caja lista. Catálogo de prueba cargado.")
            if piloto:
                hasta = (datetime.now() + timedelta(hours=6)).strftime("%Y-%m-%dT%H:%M:%S")
                con.execute(
                    "UPDATE local SET lease_until = ?, last_checkin = ?, tutorial_visto = 0 WHERE id = 1",
                    (hasta, now_iso()),
                )
        else:
            loc = con.execute("SELECT lat, lng, address FROM local WHERE id = 1").fetchone()
            if loc and loc["lat"] is None and not piloto:
                con.execute(
                    "UPDATE local SET address = COALESCE(NULLIF(address, ''), ?), "
                    "lat = ?, lng = ? WHERE id = 1",
                    ("Patronato, Recoleta", DEFAULT_LAT, DEFAULT_LNG),
                )
        dest = default_centro_url()
        if dest:
            con.execute(
                "UPDATE local SET centro_url = ? WHERE id = 1 AND TRIM(COALESCE(centro_url, '')) = ''",
                (dest,),
            )
        n = con.execute("SELECT COUNT(*) AS n FROM products").fetchone()["n"]
        if n == 0 and not piloto:
            ts = now_iso()
            con.executemany(
                "INSERT INTO products "
                "(sku, name, kind, brand, price_clp, stock, imei_required, active, created_at, "
                "market_on, market_price_clp, market_show_stock, market_fulfill, market_eta_min) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, 0, 0, 0, 'retiro', 30)",
                [(*item, ts) for item in SEED],
            )
        elif n and not piloto:
            _seed_repuestos(con)
        if not piloto:
            _seed_peers(con)
        from edge import catalog
        from edge import piso

        piso.seed(con)
        catalog.asegurar_codigos_a10(con)
        _ensure_shop_code(con)
    from edge import pais

    pais.aplicar_archivo()


def event(con: sqlite3.Connection, text: str, ok: bool = True) -> None:
    con.execute(
        "INSERT INTO events (ts, ok, text) VALUES (?, ?, ?)",
        (now_iso(), 1 if ok else 0, text),
    )


def default_centro_url() -> str:
    p = ROOT / "CENTRO"
    try:
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                return line.rstrip("/")
    except OSError:
        return ""
    return ""


def new_shop_code() -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "M10-" + "".join(secrets.choice(alphabet) for _ in range(6))


def _ensure_shop_code(con: sqlite3.Connection) -> None:
    row = con.execute("SELECT shop_code FROM local WHERE id = 1").fetchone()
    if row is None:
        return
    if str(row["shop_code"] or "").strip():
        return
    con.execute("UPDATE local SET shop_code = ? WHERE id = 1", (new_shop_code(),))


def row(r: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(r) if r is not None else None


def local() -> dict[str, Any]:
    with db() as con:
        r = con.execute("SELECT * FROM local WHERE id = 1").fetchone()
        data = row(r) or {
            "name": "Mi local",
            "address": "Patronato, Recoleta",
            "lat": DEFAULT_LAT,
            "lng": DEFAULT_LNG,
            "ticket_footer": "",
            "margin_pct": 100,
            "stock_alert": 2,
            "updated_at": now_iso(),
        }
        data.pop("id", None)
        if data.get("lat") is None:
            data["lat"] = DEFAULT_LAT
            data["lng"] = DEFAULT_LNG
        if data.get("ticket_footer") is None:
            data["ticket_footer"] = ""
        if data.get("margin_pct") is None:
            data["margin_pct"] = 100
        if data.get("stock_alert") is None:
            data["stock_alert"] = 2
        if not data.get("printer_paper"):
            data["printer_paper"] = "80"
        if not data.get("printer_copies"):
            data["printer_copies"] = 1
        if data.get("printer_cut") is None:
            data["printer_cut"] = 1
        if data.get("logo") is None:
            data["logo"] = ""
        if not data.get("pais"):
            data["pais"] = "CL"
        if not data.get("idioma"):
            data["idioma"] = "es"
        if data.get("tax_id") is None:
            data["tax_id"] = ""
        if data.get("tutorial_visto") is None:
            data["tutorial_visto"] = 1
        return data


def set_local(
    name: str | None = None,
    address: str | None = None,
    lat: float | None = None,
    lng: float | None = None,
    ticket_footer: str | None = None,
    margin_pct: float | None = None,
    stock_alert: int | None = None,
    phone: str | None = None,
    email: str | None = None,
    city: str | None = None,
    comuna: str | None = None,
    whatsapp: str | None = None,
    instagram: str | None = None,
    facebook: str | None = None,
    website: str | None = None,
    printer_name: str | None = None,
    printer_paper: str | None = None,
    printer_copies: int | None = None,
    printer_cut: int | None = None,
    ticket_header: str | None = None,
    pais: str | None = None,
    idioma: str | None = None,
    tax_id: str | None = None,
    tutorial_visto: int | None = None,
) -> dict[str, Any]:
    cur = local()
    if name is not None:
        name = name.strip()
        if not name:
            raise ValueError("el local necesita un nombre")
        cur["name"] = name[:80]
    if address is not None:
        cur["address"] = address.strip()[:160]
    if lat is not None:
        if not (-90 <= lat <= 90):
            raise ValueError("la latitud no sirve")
        cur["lat"] = lat
    if lng is not None:
        if not (-180 <= lng <= 180):
            raise ValueError("la longitud no sirve")
        cur["lng"] = lng
    if ticket_footer is not None:
        cur["ticket_footer"] = ticket_footer.strip()[:200]
    if ticket_header is not None:
        cur["ticket_header"] = ticket_header.strip()[:200]
    if margin_pct is not None:
        if not (0 <= float(margin_pct) <= 900):
            raise ValueError("el margen no sirve")
        cur["margin_pct"] = float(margin_pct)
    if stock_alert is not None:
        if not (0 <= int(stock_alert) <= 99):
            raise ValueError("el umbral de stock no sirve")
        cur["stock_alert"] = int(stock_alert)
    if phone is not None:
        cur["phone"] = phone.strip()[:40]
    if email is not None:
        cur["email"] = email.strip()[:120]
    if city is not None:
        cur["city"] = city.strip()[:80]
    if comuna is not None:
        cur["comuna"] = comuna.strip()[:80]
    if whatsapp is not None:
        cur["whatsapp"] = whatsapp.strip()[:40]
    if instagram is not None:
        cur["instagram"] = instagram.strip().lstrip("@")[:80]
    if facebook is not None:
        cur["facebook"] = facebook.strip()[:160]
    if website is not None:
        cur["website"] = website.strip()[:160]
    if printer_name is not None:
        cur["printer_name"] = printer_name.strip()[:80]
    if printer_paper is not None:
        paper = str(printer_paper).strip()
        if paper not in ("58", "80"):
            raise ValueError("el papel de la impresora es 58 o 80 mm")
        cur["printer_paper"] = paper
    if printer_copies is not None:
        n = int(printer_copies)
        if n < 1 or n > 3:
            raise ValueError("las copias del ticket son 1, 2 o 3")
        cur["printer_copies"] = n
    if printer_cut is not None:
        cur["printer_cut"] = 1 if int(printer_cut) else 0
    if pais is not None:
        from edge import pais as paismod

        cur["pais"] = paismod.normalizar(pais)
    if idioma is not None:
        from edge import pais as paismod

        cur["idioma"] = paismod.idioma_ok(idioma)
    if tax_id is not None:
        cur["tax_id"] = tax_id.strip()[:32]
    if tutorial_visto is not None:
        cur["tutorial_visto"] = 1 if int(tutorial_visto) else 0
    with db() as con:
        con.execute(
            "UPDATE local SET name = ?, address = ?, lat = ?, lng = ?, "
            "ticket_footer = ?, ticket_header = ?, margin_pct = ?, stock_alert = ?, "
            "phone = ?, email = ?, city = ?, comuna = ?, whatsapp = ?, instagram = ?, "
            "facebook = ?, website = ?, printer_name = ?, printer_paper = ?, "
            "printer_copies = ?, printer_cut = ?, pais = ?, idioma = ?, tax_id = ?, "
            "tutorial_visto = ?, "
            "updated_at = ? WHERE id = 1",
            (
                cur["name"],
                cur["address"],
                cur["lat"],
                cur["lng"],
                cur.get("ticket_footer") or "",
                cur.get("ticket_header") or "",
                float(cur.get("margin_pct") or 100),
                int(cur.get("stock_alert") or 2),
                cur.get("phone") or "",
                cur.get("email") or "",
                cur.get("city") or "",
                cur.get("comuna") or "",
                cur.get("whatsapp") or "",
                cur.get("instagram") or "",
                cur.get("facebook") or "",
                cur.get("website") or "",
                cur.get("printer_name") or "",
                cur.get("printer_paper") or "80",
                int(cur.get("printer_copies") or 1),
                int(cur.get("printer_cut") if cur.get("printer_cut") is not None else 1),
                cur.get("pais") or "CL",
                cur.get("idioma") or "es",
                cur.get("tax_id") or "",
                int(cur.get("tutorial_visto") if cur.get("tutorial_visto") is not None else 1),
                now_iso(),
            ),
        )
    return local()
