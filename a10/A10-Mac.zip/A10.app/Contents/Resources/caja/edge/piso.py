"""Mesas del taller y técnicos. El semáforo sale de lo que hay encima."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from edge import db as store

COLS_JOB = (
    "id, opened_at, updated_at, delivered_at, customer_name, customer_phone, "
    "device, imei, issue, status, price_clp, note, bench_id, tech_id"
)
OPEN = ("llego", "en_mesa", "listo")
ON_BENCH = ("en_mesa", "listo")
MAX_BENCHES = 16
MAX_TECHS = 20


def seed(con=None) -> None:
    def _go(c) -> None:
        if c.execute("SELECT COUNT(*) AS n FROM workbenches").fetchone()["n"] == 0:
            _layout(c, 4)
        if c.execute("SELECT COUNT(*) AS n FROM technicians").fetchone()["n"] == 0:
            ts = store.now_iso()
            for name in ("Técnico 1", "Técnico 2"):
                c.execute(
                    "INSERT INTO technicians (name, active, created_at) VALUES (?, 1, ?)",
                    (name, ts),
                )

    if con is not None:
        _go(con)
        return
    with store.db() as c:
        _go(c)


def _slots(n: int) -> list[tuple[float, float]]:
    n = max(1, min(MAX_BENCHES, n))
    cols = 4 if n > 6 else (3 if n > 3 else n)
    out = []
    for i in range(n):
        c = i % cols
        r = i // cols
        rows = (n + cols - 1) // cols
        x = 0.06 + c * (0.88 / cols)
        y = 0.12 + r * (0.78 / max(1, rows))
        out.append((round(x, 3), round(y, 3)))
    return out


def _layout(con, n: int) -> None:
    slots = _slots(n)
    have = [
        store.row(r)
        for r in con.execute("SELECT id, n FROM workbenches ORDER BY n")
    ]
    for i, (x, y) in enumerate(slots, start=1):
        found = next((h for h in have if h["n"] == i), None)
        if found:
            con.execute(
                "UPDATE workbenches SET active = 1, x = ?, y = ?, w = 0.16, h = 0.16, "
                "name = CASE WHEN name = '' THEN ? ELSE name END WHERE id = ?",
                (x, y, f"Mesa {i}", found["id"]),
            )
        else:
            con.execute(
                "INSERT INTO workbenches (n, name, x, y, w, h, active) "
                "VALUES (?, ?, ?, ?, 0.16, 0.16, 1)",
                (i, f"Mesa {i}", x, y),
            )
    con.execute("UPDATE workbenches SET active = 0 WHERE n > ?", (n,))


def set_benches(n: int) -> dict[str, Any]:
    n = int(n)
    if n < 1 or n > MAX_BENCHES:
        raise ValueError(f"las mesas van de 1 a {MAX_BENCHES}")
    with store.db() as con:
        _layout(con, n)
        store.event(con, f"Taller: {n} mesas")
    return snapshot()


def move_bench(bench_id: int, x: float, y: float, name: str | None = None) -> dict[str, Any]:
    x = min(0.84, max(0.0, float(x)))
    y = min(0.82, max(0.0, float(y)))
    with store.db() as con:
        row = con.execute("SELECT id FROM workbenches WHERE id = ?", (bench_id,)).fetchone()
        if row is None:
            raise KeyError("esa mesa no está")
        if name is not None:
            name = name.strip()[:24]
            con.execute(
                "UPDATE workbenches SET x = ?, y = ?, name = ? WHERE id = ?",
                (x, y, name or f"Mesa {bench_id}", bench_id),
            )
        else:
            con.execute("UPDATE workbenches SET x = ?, y = ? WHERE id = ?", (x, y, bench_id))
    return snapshot()


def techs() -> list[dict[str, Any]]:
    with store.db() as con:
        return [
            store.row(r)
            for r in con.execute(
                "SELECT id, name, active, created_at FROM technicians ORDER BY id"
            )
        ]


def add_tech(name: str) -> dict[str, Any]:
    name = (name or "").strip()
    if not name:
        raise ValueError("el técnico necesita un nombre")
    with store.db() as con:
        n = con.execute(
            "SELECT COUNT(*) AS n FROM technicians WHERE active = 1"
        ).fetchone()["n"]
        if n >= MAX_TECHS:
            raise ValueError("ya hay demasiados técnicos")
        cur = con.execute(
            "INSERT INTO technicians (name, active, created_at) VALUES (?, 1, ?)",
            (name[:40], store.now_iso()),
        )
        store.event(con, f"Técnico {name} en el taller")
        return store.row(
            con.execute(
                "SELECT id, name, active, created_at FROM technicians WHERE id = ?",
                (cur.lastrowid,),
            ).fetchone()
        )


def set_tech(tech_id: int, name: str | None = None, active: bool | None = None) -> dict[str, Any]:
    with store.db() as con:
        row = con.execute(
            "SELECT id, name, active FROM technicians WHERE id = ?", (tech_id,)
        ).fetchone()
        if row is None:
            raise KeyError("ese técnico no está")
        new_name = row["name"] if name is None else (name.strip()[:40] or row["name"])
        new_act = row["active"] if active is None else (1 if active else 0)
        con.execute(
            "UPDATE technicians SET name = ?, active = ? WHERE id = ?",
            (new_name, new_act, tech_id),
        )
        return store.row(
            con.execute(
                "SELECT id, name, active, created_at FROM technicians WHERE id = ?",
                (tech_id,),
            ).fetchone()
        )


def _minutes(ts: str) -> int:
    try:
        t = datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S")
        return max(0, int((datetime.now() - t).total_seconds() // 60))
    except ValueError:
        return 0


def _light(jobs: list[dict[str, Any]]) -> str:
    on = [j for j in jobs if j["status"] in ON_BENCH]
    if not on:
        return "verde"
    if len(on) >= 2:
        return "rojo"
    j = on[0]
    if j["status"] == "en_mesa" and _minutes(j.get("updated_at") or "") >= 240:
        return "rojo"
    if j["status"] == "listo":
        return "cyan"
    return "amarillo"


def first_free_bench(con=None) -> int | None:
    def _pick(c) -> int | None:
        benches = [
            store.row(r)
            for r in c.execute("SELECT id FROM workbenches WHERE active = 1 ORDER BY n")
        ]
        used = {
            r["bench_id"]
            for r in c.execute(
                "SELECT bench_id FROM service_orders "
                "WHERE status IN ('en_mesa','listo') AND bench_id IS NOT NULL"
            )
        }
        for b in benches:
            if b["id"] not in used:
                return b["id"]
        return benches[0]["id"] if benches else None

    if con is not None:
        return _pick(con)
    with store.db() as c:
        return _pick(c)


def snapshot() -> dict[str, Any]:
    seed()
    with store.db() as con:
        benches = [
            store.row(r)
            for r in con.execute(
                "SELECT id, n, name, x, y, w, h, active, tech_id FROM workbenches ORDER BY n"
            )
        ]
        stocks = [
            store.row(r)
            for r in con.execute(
                "SELECT bs.bench_id, bs.product_id, bs.qty, p.name, p.sku, p.cost_clp, p.price_clp "
                "FROM bench_stock bs JOIN products p ON p.id = bs.product_id "
                "WHERE bs.qty > 0 ORDER BY p.name"
            )
        ]
        people = [
            store.row(r)
            for r in con.execute(
                "SELECT id, name, active FROM technicians ORDER BY id"
            )
        ]
        jobs = [
            store.row(r)
            for r in con.execute(
                f"SELECT {COLS_JOB} FROM service_orders WHERE status IN ('llego','en_mesa','listo') "
                "ORDER BY id"
            )
        ]
    names = {t["id"]: t["name"] for t in people}
    for j in jobs:
        j["tech_name"] = names.get(j.get("tech_id")) or ""
        j["minutes"] = _minutes(j.get("updated_at") or j.get("opened_at") or "")
    by_bench: dict[int, list] = {}
    for row in stocks:
        by_bench.setdefault(int(row["bench_id"]), []).append(row)
    for b in benches:
        mine = [j for j in jobs if j.get("bench_id") == b["id"] and j["status"] in ON_BENCH]
        b["jobs"] = mine
        b["light"] = _light(mine) if b["active"] else "apagado"
        b["label"] = b["name"] or f"Mesa {b['n']}"
        b["tech_name"] = names.get(b.get("tech_id")) or ""
        inv = by_bench.get(b["id"], [])
        b["stock"] = inv
        b["stock_n"] = sum(int(x["qty"]) for x in inv)
        b["stock_cost"] = sum(int(x["qty"]) * int(x["cost_clp"] or 0) for x in inv)
    lights = {"verde": 0, "amarillo": 0, "cyan": 0, "rojo": 0}
    for b in benches:
        if b["active"] and b["light"] in lights:
            lights[b["light"]] += 1
    return {
        "benches": benches,
        "techs": people,
        "cola": [j for j in jobs if j["status"] == "llego"],
        "lights": lights,
        "n_benches": sum(1 for b in benches if b["active"]),
        "n_techs": sum(1 for t in people if t["active"]),
    }


def assign_tech(bench_id: int, tech_id: int | None) -> dict[str, Any]:
    with store.db() as con:
        if con.execute("SELECT id FROM workbenches WHERE id = ?", (bench_id,)).fetchone() is None:
            raise KeyError("esa mesa no está")
        tid = None if not tech_id else int(tech_id)
        if tid:
            t = con.execute(
                "SELECT id FROM technicians WHERE id = ? AND active = 1", (tid,)
            ).fetchone()
            if t is None:
                raise ValueError("ese técnico no está")
        con.execute("UPDATE workbenches SET tech_id = ? WHERE id = ?", (tid, bench_id))
        store.event(con, f"Mesa {bench_id}: técnico asignado" if tid else f"Mesa {bench_id}: sin técnico")
    return snapshot()


def mover_stock(bench_id: int, product_id: int, qty: int, reason: str = "carga") -> dict[str, Any]:
    qty = int(qty)
    if qty < 1:
        raise ValueError("di cuántas unidades")
    reason = "uso" if reason == "uso" else "carga"
    from edge import catalog

    with store.db() as con:
        bench = con.execute(
            "SELECT id, name, n, tech_id FROM workbenches WHERE id = ? AND active = 1",
            (bench_id,),
        ).fetchone()
        if bench is None:
            raise KeyError("esa mesa no está")
        prod = con.execute(
            "SELECT id, name, stock FROM products WHERE id = ? AND active = 1",
            (product_id,),
        ).fetchone()
        if prod is None:
            raise KeyError("ese producto no está")
        have_row = con.execute(
            "SELECT qty FROM bench_stock WHERE bench_id = ? AND product_id = ?",
            (bench_id, product_id),
        ).fetchone()
        have = int(have_row["qty"]) if have_row else 0
        mesa = bench["name"] or f"Mesa {bench['n']}"
        if reason == "carga":
            if int(prod["stock"]) < qty:
                raise ValueError("no hay tanto en el inventario")
            after = int(prod["stock"]) - qty
            con.execute("UPDATE products SET stock = ? WHERE id = ?", (after, product_id))
            catalog.registrar_movimiento(con, product_id, -qty, after, "mesa", mesa)
            new_bench = have + qty
            signed = qty
        else:
            if have < qty:
                raise ValueError("en esta mesa no hay tanto")
            new_bench = have - qty
            signed = -qty
        if have_row:
            con.execute(
                "UPDATE bench_stock SET qty = ? WHERE bench_id = ? AND product_id = ?",
                (new_bench, bench_id, product_id),
            )
        else:
            con.execute(
                "INSERT INTO bench_stock (bench_id, product_id, qty) VALUES (?, ?, ?)",
                (bench_id, product_id, new_bench),
            )
        con.execute(
            "INSERT INTO bench_moves (ts, bench_id, product_id, qty, reason, detail, tech_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (store.now_iso(), bench_id, product_id, signed, reason, prod["name"], bench["tech_id"]),
        )
    return snapshot()
