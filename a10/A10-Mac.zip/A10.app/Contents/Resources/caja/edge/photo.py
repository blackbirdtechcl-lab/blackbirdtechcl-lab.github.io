"""Foto de catálogo: un recuadro, siempre el mismo."""
from __future__ import annotations

import re
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageOps, UnidentifiedImageError

from edge import db as store

SIDE = 800
BG = (21, 26, 33)
LOGO_BG = (255, 255, 255)
LOGO_MAX_W = 900
LOGO_MAX_H = 360
LOGO_NAME = "logo.jpg"
MAX_BYTES = 8 * 1024 * 1024
FOTOS = store.ROOT / "data" / "fotos"
_NAME = re.compile(r"^(p\d+|logo)\.jpg$")


def dir_fotos() -> Path:
    FOTOS.mkdir(parents=True, exist_ok=True)
    return FOTOS


def path_for(product_id: int) -> Path:
    return dir_fotos() / f"p{product_id}.jpg"


def normalize(raw: bytes) -> bytes:
    if not raw:
        raise ValueError("no hay foto")
    if len(raw) > MAX_BYTES:
        raise ValueError("la foto pesa más de 8 MB")
    try:
        im = Image.open(BytesIO(raw))
        im = ImageOps.exif_transpose(im)
    except (UnidentifiedImageError, OSError) as e:
        raise ValueError("ese archivo no es una foto") from e
    if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
        rgba = im.convert("RGBA")
        bg = Image.new("RGB", rgba.size, BG)
        bg.paste(rgba, mask=rgba.split()[-1])
        im = bg
    else:
        im = im.convert("RGB")
    w, h = im.size
    if w < 40 or h < 40:
        raise ValueError("la foto es demasiado chica")
    side = min(w, h)
    left = (w - side) // 2
    top = (h - side) // 2
    im = im.crop((left, top, left + side, top + side))
    im = im.resize((SIDE, SIDE), Image.Resampling.LANCZOS)
    out = BytesIO()
    im.save(out, format="JPEG", quality=86, optimize=True, progressive=True)
    return out.getvalue()


def save(product_id: int, raw: bytes) -> str:
    data = normalize(raw)
    dest = path_for(product_id)
    dest.write_bytes(data)
    name = dest.name
    with store.db() as con:
        p = con.execute(
            "SELECT id, name FROM products WHERE id = ? AND active = 1",
            (product_id,),
        ).fetchone()
        if p is None:
            dest.unlink(missing_ok=True)
            raise KeyError("ese producto ya no está")
        con.execute("UPDATE products SET photo = ? WHERE id = ?", (name, product_id))
        store.event(con, f"Foto de {p['name']}")
    return name


def resolve(name: str) -> Path:
    name = (name or "").strip()
    if not _NAME.match(name):
        raise KeyError("esa foto no está")
    path = dir_fotos() / name
    if not path.is_file():
        raise KeyError("esa foto no está")
    return path


def _abrir(raw: bytes) -> Image.Image:
    if not raw:
        raise ValueError("no hay foto")
    if len(raw) > MAX_BYTES:
        raise ValueError("la foto pesa más de 8 MB")
    try:
        im = Image.open(BytesIO(raw))
        im = ImageOps.exif_transpose(im)
    except (UnidentifiedImageError, OSError) as e:
        raise ValueError("ese archivo no es una foto") from e
    return im


def normalize_logo(raw: bytes) -> bytes:
    im = _abrir(raw)
    if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
        rgba = im.convert("RGBA")
        bg = Image.new("RGB", rgba.size, LOGO_BG)
        bg.paste(rgba, mask=rgba.split()[-1])
        im = bg
    else:
        im = im.convert("RGB")
    w, h = im.size
    if w < 40 or h < 20:
        raise ValueError("el logo es demasiado chico")
    scale = min(LOGO_MAX_W / w, LOGO_MAX_H / h, 1.0)
    if scale < 1:
        im = im.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.Resampling.LANCZOS)
    out = BytesIO()
    im.save(out, format="JPEG", quality=88, optimize=True, progressive=True)
    return out.getvalue()


def save_logo(raw: bytes) -> str:
    data = normalize_logo(raw)
    dest = dir_fotos() / LOGO_NAME
    dest.write_bytes(data)
    with store.db() as con:
        con.execute("UPDATE local SET logo = ? WHERE id = 1", (LOGO_NAME,))
        store.event(con, "Logo de la tienda para el ticket")
    return LOGO_NAME


def clear_logo() -> None:
    dest = dir_fotos() / LOGO_NAME
    dest.unlink(missing_ok=True)
    with store.db() as con:
        con.execute("UPDATE local SET logo = '' WHERE id = 1")
        store.event(con, "Logo de la tienda quitado")
