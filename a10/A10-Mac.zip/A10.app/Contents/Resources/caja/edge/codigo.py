"""Código interno A10. El del proveedor se guarda aparte."""
from __future__ import annotations

import re
import sqlite3

from edge.inventario_parse import fold

KIND_TAG = {"celular": "CEL", "accesorio": "ACC", "repuesto": "REP"}
BRAND_TAG = {
    "apple": "APL",
    "samsung": "SAM",
    "xiaomi": "XIA",
    "motorola": "MOT",
    "huawei": "HUA",
    "honor": "HON",
    "oppo": "OPP",
    "vivo": "VIV",
    "realme": "REA",
    "nokia": "NOK",
    "google": "GOO",
    "mia secret": "MIA",
    "tecmaster": "TEC",
    "energizer": "ENE",
    "trust": "TRU",
    "adata": "ADA",
    "belkin": "BEL",
    "anker": "ANK",
    "genérico": "GEN",
    "generico": "GEN",
}
_A10 = re.compile(r"^A10-([A-Z]{3})-([A-Z0-9]{3})-(\d{4})$")


def es_codigo_a10(sku: str) -> bool:
    return bool(_A10.match((sku or "").strip().upper()))


def tag_kind(kind: str) -> str:
    return KIND_TAG.get((kind or "").strip(), "ITM")


def tag_brand(brand: str) -> str:
    f = fold(brand or "")
    if f in BRAND_TAG:
        return BRAND_TAG[f]
    letters = re.sub(r"[^A-Z0-9]", "", (brand or "").upper())
    return (letters[:3] or "GEN").ljust(3, "X")


def prefijo(kind: str, brand: str) -> str:
    return f"A10-{tag_kind(kind)}-{tag_brand(brand)}"


def siguiente(con: sqlite3.Connection, kind: str, brand: str) -> str:
    pre = prefijo(kind, brand)
    n = 0
    for (sku,) in con.execute(
        "SELECT sku FROM products WHERE sku LIKE ?", (pre + "-%",)
    ):
        m = _A10.match(str(sku or ""))
        if m and m.group(1) == tag_kind(kind) and m.group(2) == tag_brand(brand):
            n = max(n, int(m.group(3)))
    for _ in range(20):
        n += 1
        cand = f"{pre}-{n:04d}"
        taken = con.execute("SELECT id FROM products WHERE sku = ?", (cand,)).fetchone()
        if taken is None:
            return cand
    return f"{pre}-{n:04d}-{int(n * 7) % 99:02d}"


def blob(p: dict) -> str:
    return " ".join(
        str(p.get(k) or "")
        for k in ("sku", "ref_code", "barcode", "name", "brand", "ubicacion", "note")
    ).lower()
