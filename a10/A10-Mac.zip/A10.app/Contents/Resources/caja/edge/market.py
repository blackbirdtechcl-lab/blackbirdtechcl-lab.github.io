"""Red entre locales. No cobra comisión. Si no hay red, el mostrador sigue."""
from __future__ import annotations

import math
import sqlite3
from typing import Any

from edge import db as store

NEXT_ORDER = {
    "pedida": "aceptada",
    "aceptada": None,  # depende del fulfill
    "en_camino": "lista",
    "lista": "recibida",
}
PRODUCT_COLS = (
    "id, sku, name, kind, brand, price_clp, stock, imei_required, active, "
    "market_on, market_price_clp, market_show_stock, market_fulfill, market_eta_min"
)


def _km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(min(1.0, a)))


def _bearing(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lng2 - lng1)
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360) % 360


def _walk_min(km: float, eta: int) -> int:
    walk = int(round(km * 12))  # ~5 km/h
    return max(eta, walk)


def publish(
    product_id: int,
    on: bool,
    price_clp: int,
    show_stock: bool,
    fulfill: str,
    eta_min: int,
) -> dict[str, Any]:
    if fulfill not in store.FULFILL:
        raise ValueError("el envío es retiro, envío o ambos")
    if price_clp < 0:
        raise ValueError("el precio de red no puede ser negativo")
    if eta_min < 0:
        raise ValueError("el tiempo no puede ser negativo")
    with store.db() as con:
        p = con.execute(
            f"SELECT {PRODUCT_COLS} FROM products WHERE id = ?",
            (product_id,),
        ).fetchone()
        if p is None or not p["active"]:
            raise KeyError("ese producto ya no está")
        price = int(price_clp) if price_clp else int(p["price_clp"])
        con.execute(
            "UPDATE products SET market_on = ?, market_price_clp = ?, "
            "market_show_stock = ?, market_fulfill = ?, market_eta_min = ? WHERE id = ?",
            (1 if on else 0, price, 1 if show_stock else 0, fulfill, int(eta_min), product_id),
        )
        if on:
            store.event(con, f"{p['name']} en la red · ${price:,}".replace(",", "."))
        else:
            store.event(con, f"{p['name']} salió de la red")
        return store.row(
            con.execute(f"SELECT {PRODUCT_COLS} FROM products WHERE id = ?", (product_id,)).fetchone()
        )


def _inventory() -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]], dict[str, Any]]:
    loc = store.local()
    here_lat = float(loc["lat"])
    here_lng = float(loc["lng"])
    items: list[dict[str, Any]] = []
    shops: dict[str, dict[str, Any]] = {}

    with store.db() as con:
        for p in con.execute(
            f"SELECT {PRODUCT_COLS} FROM products WHERE active = 1 AND market_on = 1"
        ):
            item = _from_local(p, loc, here_lat, here_lng)
            items.append(item)
            shops.setdefault(
                "local",
                {
                    "key": "local",
                    "name": loc["name"],
                    "address": loc.get("address") or "",
                    "phone": "",
                    "lat": here_lat,
                    "lng": here_lng,
                    "km": 0.0,
                    "bearing": 0.0,
                    "mine": True,
                    "n": 0,
                },
            )
            shops["local"]["n"] += 1
        peers = [
            store.row(r)
            for r in con.execute("SELECT id, name, address, lat, lng, phone FROM peers")
        ]
        for peer in peers:
            plat, plng = float(peer["lat"]), float(peer["lng"])
            km = round(_km(here_lat, here_lng, plat, plng), 2)
            shop_key = f"peer:{peer['id']}"
            rows = list(
                con.execute(
                    "SELECT id, peer_id, name, brand, price_clp, stock, show_stock, fulfill, eta_min "
                    "FROM market_listings WHERE peer_id = ?",
                    (peer["id"],),
                )
            )
            if not rows:
                continue
            shops[shop_key] = {
                "key": shop_key,
                "name": peer["name"],
                "address": peer["address"],
                "phone": peer.get("phone") or "",
                "lat": plat,
                "lng": plng,
                "km": km,
                "bearing": round(_bearing(here_lat, here_lng, plat, plng), 1),
                "mine": False,
                "n": 0,
            }
            for r in rows:
                item = _from_peer(store.row(r), peer, km, here_lat)
                items.append(item)
                shops[shop_key]["n"] += 1
    return items, shops, loc


def feed(q: str = "", fulfill: str = "") -> dict[str, Any]:
    q = (q or "").strip()
    fulfill = (fulfill or "").strip()
    asked = len(q) >= 2
    loc = store.local()
    empty = {
        "local": loc,
        "q": q,
        "asked": asked,
        "fee_clp": 0,
        "items": [],
        "shops": [],
        "pedidos_abiertos": open_count(),
        "chats_abiertos": chat_count(),
    }
    if not asked:
        return empty
    needle = q.lower()
    items, shops, loc = _inventory()
    items = [i for i in items if needle in f"{i['name']} {i['brand']}".lower()]
    if fulfill in ("retiro", "envio"):
        items = [i for i in items if i["fulfill"] in (fulfill, "ambos")]
    items.sort(key=lambda i: (i["km"], i["name"]))
    keys = {i["shop_key"] for i in items}
    shop_list = sorted(
        (s for k, s in shops.items() if k in keys),
        key=lambda s: (not s["mine"], s["km"]),
    )
    for s in shop_list:
        s["n"] = sum(1 for i in items if i["shop_key"] == s["key"])
    return {
        "local": loc,
        "q": q,
        "asked": True,
        "fee_clp": 0,
        "items": items,
        "shops": shop_list,
        "pedidos_abiertos": open_count(),
        "chats_abiertos": chat_count(),
    }


def _from_local(p: sqlite3.Row, loc: dict[str, Any], lat: float, lng: float) -> dict[str, Any]:
    show = bool(p["market_show_stock"])
    return {
        "key": f"local:{p['id']}",
        "shop_key": "local",
        "mine": True,
        "product_id": p["id"],
        "listing_id": None,
        "peer_id": None,
        "shop": loc["name"],
        "phone": "",
        "address": loc.get("address") or "",
        "name": p["name"],
        "brand": p["brand"],
        "price_clp": int(p["market_price_clp"] or p["price_clp"]),
        "stock": int(p["stock"]) if show else None,
        "show_stock": show,
        "fulfill": p["market_fulfill"],
        "eta_min": int(p["market_eta_min"]),
        "walk_min": int(p["market_eta_min"]),
        "km": 0.0,
        "lat": lat,
        "lng": lng,
    }


def _from_peer(r: dict[str, Any], peer: dict[str, Any], km: float, _lat: float) -> dict[str, Any]:
    show = bool(r["show_stock"])
    eta = int(r["eta_min"])
    return {
        "key": f"peer:{r['id']}",
        "shop_key": f"peer:{peer['id']}",
        "mine": False,
        "product_id": None,
        "listing_id": r["id"],
        "peer_id": peer["id"],
        "shop": peer["name"],
        "phone": peer.get("phone") or "",
        "address": peer["address"],
        "name": r["name"],
        "brand": r["brand"],
        "price_clp": int(r["price_clp"]),
        "stock": int(r["stock"]) if show else None,
        "show_stock": show,
        "fulfill": r["fulfill"],
        "eta_min": eta,
        "walk_min": _walk_min(km, eta),
        "km": km,
        "lat": float(peer["lat"]),
        "lng": float(peer["lng"]),
    }


def _lookup(key: str) -> dict[str, Any]:
    items, _shops, _loc = _inventory()
    for item in items:
        if item["key"] == key:
            return item
    raise KeyError("esa pieza no está en la red")


def chat_count() -> int:
    with store.db() as con:
        return con.execute("SELECT COUNT(*) AS n FROM market_chats").fetchone()["n"]


def _thread(con: sqlite3.Connection, key: str) -> dict[str, Any] | None:
    row = con.execute(
        "SELECT id, listing_key, shop, name, created_at, updated_at "
        "FROM market_chats WHERE listing_key = ?",
        (key,),
    ).fetchone()
    if row is None:
        return None
    chat = store.row(row)
    chat["messages"] = [
        store.row(m)
        for m in con.execute(
            "SELECT id, mine, text, ts FROM market_messages WHERE chat_id = ? ORDER BY id",
            (chat["id"],),
        )
    ]
    return chat


def thread(key: str) -> dict[str, Any]:
    item = _lookup(key)
    with store.db() as con:
        chat = _thread(con, key)
    if chat is None:
        return {
            "id": None,
            "listing_key": key,
            "shop": item["shop"],
            "name": item["name"],
            "mine": item["mine"],
            "price_clp": item["price_clp"],
            "address": item.get("address") or "",
            "phone": item.get("phone") or "",
            "km": item["km"],
            "messages": [],
        }
    chat["mine"] = item["mine"]
    chat["price_clp"] = item["price_clp"]
    chat["address"] = item.get("address") or ""
    chat["phone"] = item.get("phone") or ""
    chat["km"] = item["km"]
    return chat


def say(key: str, text: str) -> dict[str, Any]:
    text = (text or "").strip()
    if not text:
        raise ValueError("escribe algo")
    if len(text) > 400:
        raise ValueError("el mensaje es muy largo")
    item = _lookup(key)
    if item["mine"]:
        raise ValueError("eso es de esta caja")
    ts = store.now_iso()
    with store.db() as con:
        row = con.execute(
            "SELECT id FROM market_chats WHERE listing_key = ?", (key,)
        ).fetchone()
        if row is None:
            cur = con.execute(
                "INSERT INTO market_chats (listing_key, shop, name, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (key, item["shop"], item["name"], ts, ts),
            )
            cid = cur.lastrowid
            first = True
        else:
            cid = row["id"]
            first = False
            con.execute("UPDATE market_chats SET updated_at = ? WHERE id = ?", (ts, cid))
        con.execute(
            "INSERT INTO market_messages (chat_id, mine, text, ts) VALUES (?, 1, ?, ?)",
            (cid, text, ts),
        )
        if first or "?" in text:
            reply = _reply(item, text, first)
            con.execute(
                "INSERT INTO market_messages (chat_id, mine, text, ts) VALUES (?, 0, ?, ?)",
                (cid, reply, ts),
            )
        store.event(con, f"Chat · {item['name']} con {item['shop']}")
        out = _thread(con, key)
    out["mine"] = False
    out["price_clp"] = item["price_clp"]
    out["address"] = item.get("address") or ""
    out["phone"] = item.get("phone") or ""
    out["km"] = item["km"]
    return out


def _reply(item: dict[str, Any], text: str, first: bool) -> str:
    lugar = item.get("address") or item["shop"]
    precio = f"${int(item['price_clp']):,}".replace(",", ".")
    low = text.lower()
    if first:
        if item["fulfill"] == "envio":
            return f"Sí, la tengo a {precio}. La mando desde {lugar}."
        return f"Sí, la tengo a {precio}. Podés pasar a {lugar}."
    if "precio" in low or "cuánto" in low or "cuanto" in low:
        return f"Queda en {precio}. Sin comisión de por medio."
    if "retiro" in low or "pasar" in low:
        return f"Sí, retiro en {lugar}."
    if "envío" in low or "envio" in low or "mand" in low:
        if item["fulfill"] in ("envio", "ambos"):
            return "Sí, te la mando. Decime a dónde."
        return "Acá solo retiro."
    return f"Ok. Si la apartás, avisame. Estoy en {lugar}."


def ask(key: str, qty: int, fulfill: str, backup: bool = False, note: str = "") -> dict[str, Any]:
    if qty <= 0:
        raise ValueError("falta la cantidad")
    if fulfill not in ("retiro", "envio"):
        raise ValueError("elige retiro o envío")
    item = _lookup(key)
    if item["mine"]:
        raise ValueError("eso ya es de esta caja")
    if item["fulfill"] not in (fulfill, "ambos"):
        raise ValueError("ese local no ofrece esa forma")
    if item["show_stock"] and item["stock"] is not None and item["stock"] < qty:
        raise ValueError("no alcanza lo que publicaron")
    note = (note or "").strip()[:200]
    ts = store.now_iso()
    with store.db() as con:
        cur = con.execute(
            "INSERT INTO market_orders "
            "(ts, updated_at, listing_key, peer_id, product_id, shop, name, qty, "
            "price_clp, fulfill, eta_min, backup, status, note) "
            "VALUES (?, ?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, 'pedida', ?)",
            (
                ts,
                ts,
                key,
                item["peer_id"],
                item["shop"],
                item["name"],
                qty,
                item["price_clp"],
                fulfill,
                item["walk_min"] if fulfill == "retiro" else item["eta_min"],
                1 if backup else 0,
                note,
            ),
        )
        oid = cur.lastrowid
        store.event(con, f"Pedido red #{oid} · {item['name']} en {item['shop']}")
        return _one(con, oid)


def move(order_id: int, status: str) -> dict[str, Any]:
    allowed = ("pedida", "aceptada", "en_camino", "lista", "recibida", "cancelada")
    if status not in allowed:
        raise ValueError("el estado no existe")
    ts = store.now_iso()
    with store.db() as con:
        o = con.execute(
            "SELECT id, status, fulfill FROM market_orders WHERE id = ?",
            (order_id,),
        ).fetchone()
        if o is None:
            raise KeyError("ese pedido no está")
        current = o["status"]
        if current in ("recibida", "cancelada"):
            raise ValueError("ese pedido ya cerró")
        if status == "cancelada":
            nxt = "cancelada"
        elif current == "aceptada":
            nxt = "en_camino" if o["fulfill"] == "envio" else "lista"
            if status != nxt:
                raise ValueError(f"de aceptada se pasa a {label(nxt)}")
        else:
            nxt = NEXT_ORDER.get(current)
            if status != nxt:
                raise ValueError(f"de {label(current)} se pasa a {label(nxt or current)}")
        con.execute(
            "UPDATE market_orders SET status = ?, updated_at = ? WHERE id = ?",
            (nxt, ts, order_id),
        )
        store.event(con, f"Pedido red #{order_id} · {label(nxt)}")
        return _one(con, oid=order_id)


def orders() -> list[dict[str, Any]]:
    with store.db() as con:
        return [
            store.row(r)
            for r in con.execute(
                "SELECT id, ts, updated_at, listing_key, peer_id, shop, name, qty, "
                "price_clp, fulfill, eta_min, backup, status, note "
                "FROM market_orders ORDER BY id DESC"
            )
        ]


def open_count() -> int:
    with store.db() as con:
        return con.execute(
            "SELECT COUNT(*) AS n FROM market_orders "
            "WHERE status NOT IN ('recibida', 'cancelada')"
        ).fetchone()["n"]


def label(status: str) -> str:
    return {
        "pedida": "pedida",
        "aceptada": "aceptada",
        "en_camino": "en camino",
        "lista": "lista",
        "recibida": "recibida",
        "cancelada": "cancelada",
    }.get(status, status)


def _one(con, oid: int) -> dict[str, Any]:
    return store.row(
        con.execute(
            "SELECT id, ts, updated_at, listing_key, peer_id, shop, name, qty, "
            "price_clp, fulfill, eta_min, backup, status, note "
            "FROM market_orders WHERE id = ?",
            (oid,),
        ).fetchone()
    )
