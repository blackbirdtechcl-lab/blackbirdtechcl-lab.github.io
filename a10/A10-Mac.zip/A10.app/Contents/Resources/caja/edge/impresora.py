"""Impresoras y puertos que este PC ya ve. A10 no instala drivers: las reconoce y las deja listas."""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import time
from typing import Any

from edge import db as store

CREATE_NO_WINDOW = 0x08000000
_CACHE: list[dict[str, Any]] | None = None
_CACHE_AT = 0.0
_CACHE_S = 20.0

ESTADOS = {
    "0": "otra",
    "1": "desconocida",
    "2": "lista",
    "3": "imprimiendo",
    "4": "calentando",
    "5": "parada",
    "6": "aviso",
    "7": "fuera de línea",
    "normal": "lista",
    "idle": "lista",
    "printing": "imprimiendo",
    "offline": "fuera de línea",
    "error": "error",
    "paperout": "sin papel",
    "paperjam": "papel atascado",
    "notoner": "sin tinta",
    "dooropen": "tapa abierta",
    "paused": "en pausa",
}


def _run(args: list[str], timeout: float = 8) -> str:
    flags = CREATE_NO_WINDOW if sys.platform == "win32" else 0
    r = subprocess.run(
        args,
        capture_output=True,
        timeout=timeout,
        creationflags=flags,
    )
    out = (r.stdout or b"") + (r.stderr or b"")
    return out.decode("utf-8", "replace")


def _json(raw: str) -> list[dict[str, Any]]:
    raw = (raw or "").strip()
    if not raw or raw.startswith("Get-") or "Cmdlet" in raw:
        return []
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return []
    if data is None:
        return []
    if isinstance(data, dict):
        return [data]
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]
    return []


def _estado(raw: Any) -> str:
    s = str(raw or "").strip()
    if not s:
        return "lista"
    return ESTADOS.get(s.lower(), s)


def _windows() -> list[dict[str, Any]]:
    ps = shutil.which("powershell") or shutil.which("pwsh")
    if not ps:
        return []
    script = (
        "Get-Printer | Select-Object Name, PrinterStatus, PortName, Default | "
        "ConvertTo-Json -Compress"
    )
    rows = _json(_run([ps, "-NoProfile", "-Command", script]))
    out: list[dict[str, Any]] = []
    for p in rows:
        name = str(p.get("Name") or "").strip()
        if not name:
            continue
        status = _estado(p.get("PrinterStatus"))
        out.append(
            {
                "name": name,
                "port": str(p.get("PortName") or "").strip(),
                "estado": status,
                "predeterminada": bool(p.get("Default")),
                "ok": status not in {"fuera de línea", "error", "papel atascado"},
            }
        )
    return out


def _unix() -> list[dict[str, Any]]:
    if not shutil.which("lpstat"):
        return []
    raw = _run(["lpstat", "-p", "-d", "-v"])
    dest = ""
    ports: dict[str, str] = {}
    names: list[str] = []
    idle: dict[str, bool] = {}
    for line in raw.splitlines():
        line = line.strip()
        low = line.lower()
        if low.startswith("system default destination:"):
            dest = line.split(":", 1)[-1].strip()
        elif low.startswith("device for "):
            try:
                izq, der = line.split(":", 1)
                nom = izq.split("for", 1)[-1].strip()
                ports[nom] = der.strip()
            except ValueError:
                pass
        elif low.startswith("printer "):
            parts = line.split()
            if len(parts) >= 2:
                nom = parts[1]
                names.append(nom)
                idle[nom] = "idle" in low or "enabled" in low
    out = []
    for name in names:
        out.append(
            {
                "name": name,
                "port": ports.get(name, ""),
                "estado": "lista" if idle.get(name) else "ocupada",
                "predeterminada": name == dest,
                "ok": True,
            }
        )
    return out


def _puertos_win() -> list[dict[str, str]]:
    ps = shutil.which("powershell") or shutil.which("pwsh")
    if not ps:
        return []
    script = (
        "Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | "
        "Where-Object { $_.Class -in @('Printer','Ports','USB') -and "
        "$_.FriendlyName -match 'COM|LPT|USB|Print|POS|Ticket|Thermal|Serial' } | "
        "Select-Object FriendlyName, Status, InstanceId | ConvertTo-Json -Compress"
    )
    rows = _json(_run([ps, "-NoProfile", "-Command", script], timeout=10))
    out: list[dict[str, str]] = []
    vistos: set[str] = set()
    for p in rows:
        name = str(p.get("FriendlyName") or "").strip()
        if not name or name in vistos:
            continue
        vistos.add(name)
        out.append(
            {
                "name": name,
                "port": str(p.get("InstanceId") or "").strip()[:80],
                "estado": _estado(p.get("Status")),
            }
        )
    return out[:12]


def _puertos_unix() -> list[dict[str, str]]:
    if not shutil.which("lpstat"):
        return []
    raw = _run(["lpstat", "-v"])
    out: list[dict[str, str]] = []
    for line in raw.splitlines():
        if ":" not in line:
            continue
        izq, der = line.split(":", 1)
        nom = izq.split("for", 1)[-1].strip() if "for" in izq.lower() else izq.strip()
        if nom:
            out.append({"name": nom, "port": der.strip(), "estado": "visto"})
    return out[:12]


def puertos() -> list[dict[str, str]]:
    try:
        if sys.platform == "win32":
            return _puertos_win()
        return _puertos_unix()
    except (OSError, subprocess.TimeoutExpired):
        return []


def _descubrir() -> list[dict[str, Any]]:
    try:
        if sys.platform == "win32":
            return _windows()
        return _unix()
    except (OSError, subprocess.TimeoutExpired):
        return []


def _es_virtual(p: dict[str, Any]) -> bool:
    name = (p.get("name") or "").lower()
    port = (p.get("port") or "").lower()
    if "pdf" in name or "onenote" in name or "fax" in name or "xps" in name:
        return True
    if "portprompt" in port or port in {"nul:", "nul"}:
        return True
    return False


def listar(*, fresco: bool = False) -> list[dict[str, Any]]:
    global _CACHE, _CACHE_AT
    now = time.time()
    if fresco or _CACHE is None or now - _CACHE_AT > _CACHE_S:
        _CACHE = _descubrir()
        _CACHE_AT = now
    found = [dict(p) for p in _CACHE]
    loc = store.local()
    actual = (loc.get("printer_name") or "").strip()
    if not actual:
        reales = [p for p in found if not _es_virtual(p)]
        pick = next((p["name"] for p in reales if p.get("predeterminada")), "")
        if not pick and len(reales) == 1:
            pick = reales[0]["name"]
        if pick:
            store.set_local(printer_name=pick)
            actual = pick
            marcar_predeterminada(pick)
    for p in found:
        p["usada"] = p["name"] == actual
        p["virtual"] = _es_virtual(p)
    return found


def marcar_predeterminada(name: str) -> bool:
    name = (name or "").strip()
    if not name:
        return False
    try:
        if sys.platform == "win32":
            ps = shutil.which("powershell") or shutil.which("pwsh")
            if not ps:
                return False
            safe = name.replace("'", "''")
            script = (
                f"$p = Get-CimInstance Win32_Printer -Filter \"Name='{safe}'\" "
                "-ErrorAction SilentlyContinue; "
                "if ($p) { Invoke-CimMethod -InputObject $p -MethodName SetDefaultPrinter | Out-Null }"
            )
            _run([ps, "-NoProfile", "-Command", script])
            return True
        if shutil.which("lpoptions"):
            _run(["lpoptions", "-d", name])
            return True
    except (OSError, subprocess.TimeoutExpired):
        return False
    return False


def usar(name: str, paper: str = "80", copies: int = 1, cut: bool = True) -> dict[str, Any]:
    name = (name or "").strip()[:80]
    found = [p["name"] for p in listar(fresco=True)]
    if name and found and name not in found:
        raise ValueError("esa impresora no está conectada a este PC")
    copies = max(1, min(3, int(copies or 1)))
    loc = store.set_local(
        printer_name=name,
        printer_paper=paper,
        printer_copies=copies,
        printer_cut=1 if cut else 0,
    )
    if name:
        marcar_predeterminada(name)
    return loc


def snapshot(*, fresco: bool = False) -> dict[str, Any]:
    impresoras = listar(fresco=fresco)
    loc = store.local()
    return {
        "impresoras": impresoras,
        "puertos": puertos() if fresco or not impresoras else [],
        "usada": loc.get("printer_name") or "",
        "papel": loc.get("printer_paper") or "80",
        "copias": int(loc.get("printer_copies") or 1),
        "corte": bool(int(loc.get("printer_cut") if loc.get("printer_cut") is not None else 1)),
        "n": len(impresoras),
    }
