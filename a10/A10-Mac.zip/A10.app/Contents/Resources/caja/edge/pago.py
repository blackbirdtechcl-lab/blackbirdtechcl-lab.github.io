"""Suscripción mensual. El cobro no espera al banco."""
from __future__ import annotations

import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from edge import db as store

MES_DIAS = 30
DESCARGAR_URL = "https://blackbirdtech.cl/a10"


def _archivo() -> Path:
    env = (os.environ.get("A10_PAGO") or "").strip()
    if env:
        return Path(env)
    db = (os.environ.get("A10_DB") or "").strip()
    if db:
        return Path(db).with_name("PAGO")
    return store.ROOT / "PAGO"


ARCHIVO = _archivo()


def _parse_ts(raw: str) -> datetime | None:
    s = (raw or "").strip()
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "")[:19])
    except ValueError:
        return None


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S")


def url() -> str:
    env = (os.environ.get("A10_PAGO_URL") or "").strip()
    if env.lower().startswith("http"):
        return env.rstrip("/")
    try:
        text = ARCHIVO.read_text(encoding="utf-8")
    except OSError:
        return ""
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.lower().startswith("http"):
            return line.rstrip("/")
    return ""


def guardar_url(raw: str) -> str:
    u = (raw or "").strip()
    if not u:
        try:
            ARCHIVO.unlink()
        except OSError:
            pass
        return ""
    if not u.lower().startswith("https://"):
        raise ValueError("el link de pago tiene que empezar con https://")
    if any(ch.isspace() for ch in u):
        raise ValueError("ese link no sirve")
    ARCHIVO.write_text(
        "# Link de pago de Banco de Chile. El cobro de la caja no espera esto.\n" + u + "\n",
        encoding="utf-8",
    )
    return u.rstrip("/")


def hasta_local() -> str:
    return ((store.local() or {}).get("pago_hasta") or "").strip()


def aplicar_hasta(raw: str) -> str:
    dt = _parse_ts(raw)
    if dt is None:
        raise ValueError("esa fecha del mes no sirve")
    iso = _iso(dt)
    with store.db() as con:
        con.execute("UPDATE local SET pago_hasta = ? WHERE id = 1", (iso,))
    return iso


def marcar_mes(*, desde: str = "") -> str:
    ahora = datetime.now()
    base = _parse_ts(desde) or _parse_ts(hasta_local()) or ahora
    if base < ahora:
        base = ahora
    return aplicar_hasta(_iso(base + timedelta(days=MES_DIAS)))


def estado(*, piloto: bool | None = None) -> dict[str, Any]:
    if piloto is None:
        piloto = store.es_instalado()
    u = url()
    hasta = hasta_local()
    dt = _parse_ts(hasta)
    if dt is None:
        quedan = None
        vencido = False
    else:
        quedan = int((dt - datetime.now()).total_seconds() // 86400)
        vencido = quedan < 0
    mostrar = bool(piloto) and (bool(u) or vencido or (quedan is not None and quedan <= 7))
    return {
        "url": u,
        "hasta": hasta,
        "quedan_d": quedan,
        "vencido": vencido,
        "mostrar": mostrar,
        "descargar": DESCARGAR_URL,
        "mes_dias": MES_DIAS,
    }


def hasta_nodo(shop_code: str) -> str:
    code = (shop_code or "").strip()
    if not code:
        return ""
    with store.db() as con:
        row = con.execute(
            "SELECT pago_hasta FROM nodos WHERE shop_code = ?", (code,)
        ).fetchone()
    if not row:
        return ""
    return (row["pago_hasta"] if "pago_hasta" in row.keys() else "") or ""


def marcar_nodo(shop_code: str) -> str:
    code = (shop_code or "").strip()
    if not code:
        raise ValueError("falta el código del local")
    ahora = datetime.now()
    base = _parse_ts(hasta_nodo(code)) or ahora
    if base < ahora:
        base = ahora
    iso = _iso(base + timedelta(days=MES_DIAS))
    with store.db() as con:
        existe = con.execute(
            "SELECT shop_code FROM nodos WHERE shop_code = ?", (code,)
        ).fetchone()
        if existe:
            con.execute(
                "UPDATE nodos SET pago_hasta = ? WHERE shop_code = ?", (iso, code)
            )
        else:
            con.execute(
                "INSERT INTO nodos (shop_code, name, pago_hasta, visto) VALUES (?, '', ?, ?)",
                (code, iso, store.now_iso()),
            )
    return iso
