"""El iPhone cobra en la misma caja, misma wifi. No es boleta del SII."""
from __future__ import annotations

from io import BytesIO
from typing import Any

from edge import red as redmod


def enlace() -> dict[str, Any]:
    red = redmod.snapshot()
    ip = (red.get("ip") or "").strip()
    port = int(red.get("port") or 5050)
    lan = bool(ip) and not ip.startswith("127.")
    url = f"http://{ip}:{port}/" if ip else ""
    return {
        "url": url,
        "ip": ip,
        "port": port,
        "host": red.get("host") or "a10.local",
        "lan": lan,
        "anunciada": bool(red.get("anunciada")),
    }


def qr_png(url: str | None = None) -> bytes | None:
    data = (url or enlace().get("url") or "").strip()
    if not data:
        return None
    try:
        import qrcode
        import qrcode.constants
    except ImportError:
        return None
    qr = qrcode.QRCode(border=2, box_size=8, error_correction=qrcode.constants.ERROR_CORRECT_M)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buf = BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()
