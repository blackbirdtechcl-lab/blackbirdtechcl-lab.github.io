"""Informe de esta caja: qué está vivo. El cobro no espera esto."""
from __future__ import annotations

import socket
from datetime import datetime, timedelta
from typing import Any

from edge import db as store
from edge import market
from edge import red as redmod
from edge import taller

LEASE_HORAS = 6


def hay_internet(timeout: float = 1.5) -> bool:
    try:
        socket.create_connection(("1.1.1.1", 443), timeout=timeout).close()
        return True
    except OSError:
        return False


def _parse_ts(raw: str) -> datetime | None:
    s = (raw or "").strip()
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", ""))
    except ValueError:
        return None


def extender_arriendo() -> str:
    hasta = (datetime.now() + timedelta(hours=LEASE_HORAS)).strftime("%Y-%m-%dT%H:%M:%S")
    with store.db() as con:
        con.execute(
            "UPDATE local SET lease_until = ?, last_checkin = ? WHERE id = 1",
            (hasta, store.now_iso()),
        )
    return hasta


def _tope(row: Any) -> datetime | None:
    until = _parse_ts((row["lease_until"] if row else "") or "")
    check = _parse_ts((row["last_checkin"] if row else "") or "")
    if check is not None:
        cap = check + timedelta(hours=LEASE_HORAS)
        if until is None or until > cap:
            until = cap
    return until


def arriendo_vencido() -> bool:
    if not store.es_instalado():
        return False
    with store.db() as con:
        row = con.execute(
            "SELECT lease_until, last_checkin FROM local WHERE id = 1"
        ).fetchone()
    until = _tope(row)
    if until is None:
        return True
    return datetime.now() >= until


def estado_arriendo(*, ping: bool = False) -> dict[str, Any]:
    if not store.es_instalado():
        return {
            "piloto": False,
            "internet": True,
            "expired": False,
            "quedan_s": None,
            "lease_until": "",
        }
    net = hay_internet() if ping else False
    if net:
        hasta = extender_arriendo()
        return {
            "piloto": True,
            "internet": True,
            "expired": False,
            "quedan_s": LEASE_HORAS * 3600,
            "lease_until": hasta,
        }
    with store.db() as con:
        row = con.execute(
            "SELECT lease_until, last_checkin FROM local WHERE id = 1"
        ).fetchone()
    until = _tope(row)
    if until is None:
        quedan = 0
    else:
        quedan = int((until - datetime.now()).total_seconds())
    expired = quedan <= 0
    return {
        "piloto": True,
        "internet": False,
        "expired": expired,
        "quedan_s": max(0, min(quedan, LEASE_HORAS * 3600)),
        "lease_until": until.strftime("%Y-%m-%dT%H:%M:%S") if until else "",
    }


def _pieza(clave: str, titulo: str, ok: bool, detalle: str) -> dict[str, Any]:
    return {"id": clave, "titulo": titulo, "ok": bool(ok), "detalle": detalle}


def informe() -> dict[str, Any]:
    piezas: list[dict[str, Any]] = []
    dbp = store.DB_PATH
    n_leyendo = 0
    try:
        with store.db() as con:
            con.execute("SELECT 1").fetchone()
            n_prod = con.execute("SELECT COUNT(*) AS n FROM products").fetchone()["n"]
            n_ventas = con.execute(
                "SELECT COUNT(*) AS n FROM sales WHERE COALESCE(voided, 0) = 0"
            ).fetchone()["n"]
            n_leyendo = 0
            tables = {
                r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
            }
            if "lecturas" in tables:
                n_leyendo = con.execute(
                    "SELECT COUNT(*) AS n FROM lecturas WHERE estado = 'leyendo'"
                ).fetchone()["n"]
        piezas.append(
            _pieza("base", "Base de este PC", True, f"{n_prod} productos · {n_ventas} ventas cobradas.")
        )
    except Exception:
        piezas.append(
            _pieza("base", "Base de este PC", False, "No pude abrir la base. No toques data/. Reabre A10.")
        )

    wal = dbp.with_suffix(dbp.suffix + "-wal")
    piezas.append(
        _pieza(
            "archivo",
            "Archivo de la caja",
            dbp.exists(),
            str(dbp) if dbp.exists() else "No está el archivo de la caja.",
        )
    )
    if wal.exists():
        piezas.append(_pieza("wal", "Escritura segura", True, "La caja guarda en marcha (WAL)."))

    fotos = store.ROOT / "data" / "fotos"
    try:
        fotos.mkdir(parents=True, exist_ok=True)
        n_fotos = len(list(fotos.glob("t*.jpg")))
        piezas.append(_pieza("fotos", "Fotos de equipos", True, f"{n_fotos} tapas o pantallas guardadas."))
    except Exception:
        piezas.append(_pieza("fotos", "Fotos de equipos", False, "No pude escribir en fotos."))

    if n_leyendo:
        piezas.append(
            _pieza("lectura", "Lectura de foto", True, f"{n_leyendo} foto(s) se están leyendo. Puedes seguir.")
        )

    try:
        counts = taller.counts()
        abiertos = int(counts.get("llego", 0)) + int(counts.get("en_mesa", 0)) + int(counts.get("listo", 0))
        piezas.append(
            _pieza("taller", "Servicio", True, f"{abiertos} equipos abiertos · {counts.get('listo', 0)} listos.")
        )
    except Exception:
        piezas.append(_pieza("taller", "Servicio", False, "El taller no respondió."))

    try:
        red = redmod.snapshot()
        piezas.append(
            _pieza(
                "red",
                "Aviso a la red",
                True,
                "La caja avisa si hay red. El cobro no lo necesita."
                if red
                else "Sin aviso a la red. Da igual para cobrar.",
            )
        )
    except Exception:
        piezas.append(_pieza("red", "Aviso a la red", True, "Sin aviso. El cobro sigue."))

    try:
        n_red = market.open_count()
        piezas.append(
            _pieza("market10", "Market10", True, f"{n_red} pedidos abiertos entre locales." if n_red else "Sin pedidos abiertos.")
        )
    except Exception:
        piezas.append(_pieza("market10", "Market10", True, "Market10 no está. El cobro sigue."))

    try:
        with store.db() as con:
            n_u = con.execute("SELECT COUNT(*) AS n FROM users WHERE active = 1").fetchone()["n"]
        piezas.append(
            _pieza(
                "acceso",
                "Quién entra",
                True,
                f"{n_u} personas con clave." if n_u else "Sin claves: entra quien está en este PC.",
            )
        )
    except Exception:
        piezas.append(_pieza("acceso", "Quién entra", True, "Sin claves todavía."))

    try:
        loc = store.local()
        usada = (loc.get("printer_name") or "").strip()
        papel = loc.get("printer_paper") or "80"
        piezas.append(
            _pieza(
                "impresora",
                "Impresora",
                True,
                f"{usada} · papel {papel} mm." if usada else "Ninguna elegida. Enchufa el ticket y búscalo en Ajustes.",
            )
        )
    except Exception:
        piezas.append(_pieza("impresora", "Impresora", True, "No pude ver la impresora."))

    ok = all(p["ok"] for p in piezas)
    return {"ok": ok, "piezas": piezas}
