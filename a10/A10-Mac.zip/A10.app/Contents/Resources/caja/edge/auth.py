"""Quién entra a esta caja. El cobro no espera internet."""
from __future__ import annotations

import hashlib
import hmac
import secrets
from datetime import datetime, timedelta
from typing import Any

from edge import db as store

ROLES = ("dueno", "mostrador", "tecnico")
COOKIE = "a10_sesion"
HORAS = 12
_ROUNDS = 120_000


def _ahora() -> datetime:
    return datetime.now()


def _hash(clave: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", clave.encode("utf-8"), salt, _ROUNDS)
    return salt.hex() + "$" + digest.hex()


def _check(clave: str, packed: str) -> bool:
    try:
        salt_hex, dig_hex = packed.split("$", 1)
        salt = bytes.fromhex(salt_hex)
        want = bytes.fromhex(dig_hex)
    except (ValueError, AttributeError):
        return False
    got = hashlib.pbkdf2_hmac("sha256", clave.encode("utf-8"), salt, _ROUNDS)
    return hmac.compare_digest(got, want)


def _limpia_clave(raw: str) -> str:
    clave = (raw or "").strip()
    if len(clave) < 4 or len(clave) > 40:
        raise ValueError("la clave tiene entre 4 y 40 caracteres")
    return clave


def _limpia_nombre(raw: str) -> str:
    name = " ".join((raw or "").split())
    if len(name) < 2:
        raise ValueError("pon el nombre de quien entra")
    return name[:40]


def hay_usuarios() -> bool:
    with store.db() as con:
        n = con.execute("SELECT COUNT(*) AS n FROM users WHERE active = 1").fetchone()["n"]
    return int(n) > 0


def listar() -> list[dict[str, Any]]:
    with store.db() as con:
        rows = con.execute(
            "SELECT id, name, role, active, created_at FROM users ORDER BY id"
        ).fetchall()
    return [store.row(r) for r in rows]


def crear(name: str, clave: str, role: str = "mostrador") -> dict[str, Any]:
    name = _limpia_nombre(name)
    clave = _limpia_clave(clave)
    role = (role or "mostrador").strip().lower()
    if role == "dueño":
        role = "dueno"
    if role not in ROLES:
        raise ValueError("el rol es dueño, mostrador o técnico")
    with store.db() as con:
        dup = con.execute(
            "SELECT id FROM users WHERE lower(name) = lower(?) AND active = 1",
            (name,),
        ).fetchone()
        if dup:
            raise ValueError("ese nombre ya entra")
        cur = con.execute(
            "INSERT INTO users (name, clave, role, active, created_at) VALUES (?, ?, ?, 1, ?)",
            (name, _hash(clave), role, store.now_iso()),
        )
        uid = int(cur.lastrowid)
    return {"id": uid, "name": name, "role": role, "active": 1}


def primero(name: str, clave: str) -> dict[str, Any]:
    if hay_usuarios():
        raise ValueError("ya hay quien entra. Pide al dueño.")
    return crear(name, clave, "dueno")


def entrar(name: str, clave: str) -> dict[str, Any]:
    name = _limpia_nombre(name)
    clave = (clave or "").strip()
    with store.db() as con:
        row = con.execute(
            "SELECT id, name, clave, role, active FROM users "
            "WHERE lower(name) = lower(?) AND active = 1",
            (name,),
        ).fetchone()
    if row is None or not _check(clave, row["clave"]):
        raise ValueError("nombre o clave no sirven")
    token = secrets.token_hex(24)
    exp = (_ahora() + timedelta(hours=HORAS)).strftime("%Y-%m-%dT%H:%M:%S")
    with store.db() as con:
        con.execute(
            "INSERT INTO sesiones (token, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
            (token, int(row["id"]), store.now_iso(), exp),
        )
    return {
        "token": token,
        "user": {"id": int(row["id"]), "name": row["name"], "role": row["role"]},
    }


def salir(token: str) -> None:
    if not token:
        return
    with store.db() as con:
        con.execute("DELETE FROM sesiones WHERE token = ?", (token,))


def quien(token: str) -> dict[str, Any] | None:
    if not token:
        return None
    with store.db() as con:
        row = con.execute(
            "SELECT u.id, u.name, u.role, u.active, s.expires_at "
            "FROM sesiones s JOIN users u ON u.id = s.user_id "
            "WHERE s.token = ?",
            (token,),
        ).fetchone()
    if row is None or not row["active"]:
        return None
    exp = store.row(row).get("expires_at") or ""
    try:
        if datetime.fromisoformat(str(exp).replace("Z", "")) < _ahora():
            salir(token)
            return None
    except ValueError:
        return None
    return {"id": int(row["id"]), "name": row["name"], "role": row["role"]}


def borrar(user_id: int, quien_id: int) -> None:
    if int(user_id) == int(quien_id):
        raise ValueError("no te puedes sacar a ti mismo")
    with store.db() as con:
        row = con.execute("SELECT id, role FROM users WHERE id = ?", (int(user_id),)).fetchone()
        if row is None:
            raise KeyError("esa persona no está")
        duenos = con.execute(
            "SELECT COUNT(*) AS n FROM users WHERE role = 'dueno' AND active = 1"
        ).fetchone()["n"]
        if row["role"] == "dueno" and int(duenos) <= 1:
            raise ValueError("tiene que quedar un dueño")
        con.execute("UPDATE users SET active = 0 WHERE id = ?", (int(user_id),))
        con.execute("DELETE FROM sesiones WHERE user_id = ?", (int(user_id),))


def puede(role: str | None, *roles: str) -> bool:
    if not hay_usuarios():
        return True
    if not role:
        return False
    if not roles:
        return True
    return role in roles
